const { withAndroidManifest } = require('expo/config-plugins');

/**
 * Android 11+ hides other apps unless the manifest says which ones the app
 * wants to see. UPI payment needs to see UPI apps (GPay, PhonePe, Paytm, ...),
 * which all answer to the upi://pay link.
 */
module.exports = function withUpiQueries(config) {
  return withAndroidManifest(config, (cfg) => {
    const manifest = cfg.modResults.manifest;
    manifest.queries = manifest.queries ?? [];
    const queries = manifest.queries[0] ?? (manifest.queries[0] = {});
    queries.intent = queries.intent ?? [];

    const already = queries.intent.some((i) =>
      (i.data ?? []).some((d) => d.$?.['android:scheme'] === 'upi')
    );
    if (!already) {
      queries.intent.push({
        action: [{ $: { 'android:name': 'android.intent.action.VIEW' } }],
        data: [{ $: { 'android:scheme': 'upi', 'android:host': 'pay' } }],
      });
    }
    return cfg;
  });
};
