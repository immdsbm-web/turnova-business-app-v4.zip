import React, { useEffect, useState } from 'react';
import { Platform, Pressable, Text, View } from 'react-native';
import { Stack } from 'expo-router';
import { DarkTheme, DefaultTheme, ThemeProvider } from '@react-navigation/native';
import * as NavigationBar from 'expo-navigation-bar';
import * as SystemUI from 'expo-system-ui';
import * as SplashScreen from 'expo-splash-screen';
import { useFonts } from 'expo-font';
import { Ionicons } from '@expo/vector-icons';
import { Inter_400Regular, Inter_500Medium, Inter_600SemiBold, Inter_700Bold } from '@expo-google-fonts/inter';
import { initialWindowMetrics, SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from '@/src/api/queryClient';
import { useSession } from '@/src/auth/session';
import { useTheme, ThemeModeProvider } from '@/src/theme';
import { ToastProvider } from '@/src/components/Toast';
import { OfflineScreen } from '@/src/components/OfflineScreen';
import { SplashOverlay } from '@/src/components/SplashOverlay';
import { fadeTransition } from '@/src/navigation/transitions';

// Keep the native splash up only until the branded JS splash has painted.
SplashScreen.preventAutoHideAsync().catch(() => undefined);

const READY_TIMEOUT_MS = 8000; // never leave someone stuck on the splash
const MIN_SPLASH_MS = 1800; // branded splash always shows briefly

function RootNavigation() {
  const hydrated = useSession((s) => s.hydrated);
  const hydrate = useSession((s) => s.hydrate);
  const { colors } = useTheme();

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  // Two separate font loads so a problem with one family can't take icons down too.
  const [iconFontLoaded, iconFontError] = useFonts({ ...Ionicons.font });
  const [brandFontsLoaded, brandFontsError] = useFonts({
    Inter_400Regular, Inter_500Medium, Inter_600SemiBold, Inter_700Bold,
  });
  const fontsSettled = (iconFontLoaded || Boolean(iconFontError)) && (brandFontsLoaded || Boolean(brandFontsError));

  const [timedOut, setTimedOut] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setTimedOut(true), READY_TIMEOUT_MS);
    return () => clearTimeout(t);
  }, []);
  const [minSplashElapsed, setMinSplashElapsed] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setMinSplashElapsed(true), MIN_SPLASH_MS);
    return () => clearTimeout(t);
  }, []);

  const ready = (hydrated && fontsSettled && minSplashElapsed) || timedOut;
  // Don't open the app before the saved sign-in was read (that would show Login to a signed-in person).
  if (timedOut && !hydrated) {
    return (
      <OfflineScreen
        title="Slow Internet Connection"
        subtitle="Your internet is slow or unstable. You are still signed in. Please wait or try again."
        onRetry={hydrate}
      />
    );
  }
  if (!ready) {
    return <SplashOverlay onReady={() => SplashScreen.hideAsync().catch(() => undefined)} />;
  }

  return (
    <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.background }, ...fadeTransition }}>
      <Stack.Screen name="index" />
      <Stack.Screen name="(auth)" />
      <Stack.Screen name="(app)" />
    </Stack>
  );
}

export default function RootLayout() {
  return (
    <ThemeModeProvider>
      <RootLayoutInner />
    </ThemeModeProvider>
  );
}

function RootLayoutInner() {
  const { isDark, colors } = useTheme();

  useEffect(() => {
    if (Platform.OS !== 'android') return;
    NavigationBar.setBackgroundColorAsync(colors.background).catch(() => undefined);
    NavigationBar.setButtonStyleAsync(isDark ? 'light' : 'dark').catch(() => undefined);
  }, [isDark, colors.background]);

  useEffect(() => {
    SystemUI.setBackgroundColorAsync(colors.background).catch(() => undefined);
  }, [colors.background]);

  const navTheme = {
    ...(isDark ? DarkTheme : DefaultTheme),
    colors: { ...(isDark ? DarkTheme : DefaultTheme).colors, background: colors.background },
  };

  return (
    <ThemeProvider value={navTheme}>
      <SafeAreaProvider initialWindowMetrics={initialWindowMetrics}>
        <QueryClientProvider client={queryClient}>
          <ToastProvider>
            <StatusBar style={isDark ? 'light' : 'dark'} />
            <RootNavigation />
          </ToastProvider>
        </QueryClientProvider>
      </SafeAreaProvider>
    </ThemeProvider>
  );
}

/**
 * Safety net: if any screen throws while drawing, show this instead of letting
 * the whole app close. (Rendered outside the app's providers, so it uses its own
 * plain colours.)
 */
export function ErrorBoundary({ error, retry }: { error: Error; retry: () => Promise<void> }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, backgroundColor: '#F8FAF9', gap: 12 }}>
      <Text style={{ fontSize: 20, fontWeight: '700', color: '#14252B', textAlign: 'center' }}>Something went wrong</Text>
      <Text style={{ fontSize: 14, color: '#718096', textAlign: 'center' }}>
        Please try again. If it keeps happening, tell support what you were doing.
      </Text>
      <Text style={{ fontSize: 11, color: '#718096', textAlign: 'center' }} numberOfLines={4}>{String(error?.message ?? '')}</Text>
      <Pressable onPress={() => retry()} style={{ backgroundColor: '#075E4B', paddingHorizontal: 28, paddingVertical: 12, borderRadius: 14 }} accessibilityRole="button">
        <Text style={{ color: '#FFFFFF', fontWeight: '700' }}>Try again</Text>
      </Pressable>
    </View>
  );
}
