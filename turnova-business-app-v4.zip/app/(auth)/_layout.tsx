import { Redirect, Stack } from 'expo-router';
import { useSession } from '@/src/auth/session';
import { useTheme } from '@/src/theme';
import { slideTransition } from '@/src/navigation/transitions';

export default function AuthLayout() {
  const token = useSession((s) => s.token);
  const me = useSession((s) => s.me);
  const { colors } = useTheme();

  // Already signed in: nothing to do on the login screens.
  if (token && me) {
    return <Redirect href={me.account.role === 'owner' ? '/home' : '/my-queue'} />;
  }

  return (
    <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.background }, ...slideTransition }}>
      <Stack.Screen name="login" />
      <Stack.Screen name="register" />
      <Stack.Screen name="pending-approval" />
    </Stack>
  );
}
