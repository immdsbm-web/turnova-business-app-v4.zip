import React from 'react';
import { Text, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/src/components/Button';
import { useTheme } from '@/src/theme';
import { Screen } from '@/src/components/Screen';
import { StatusIcon } from '@/src/components/BrandMark';
import { fetchRegistrationStatus } from '@/src/api/business';

const COPY: Record<string, { icon: keyof typeof Ionicons.glyphMap; title: string; text: string }> = {
  pending: { icon: 'hourglass-outline', title: 'Your business is under review', text: "We're checking your details. You can sign in once approved." },
  rejected: { icon: 'close-circle-outline', title: 'Your application was not approved', text: 'Contact support if this looks wrong.' },
  suspended: { icon: 'pause-circle-outline', title: 'Your business account is suspended', text: 'Contact support to restore access.' },
};

/** Shown after registering, and when someone signs in before their business is approved. */
export default function PendingApprovalScreen() {
  const { colors, typography, spacing } = useTheme();
  const router = useRouter();
  const params = useLocalSearchParams<{ business_id?: string; name?: string; status?: string; reason?: string }>();
  const businessId = Number(params.business_id ?? 0);

  const statusQuery = useQuery({
    queryKey: ['registration-status', businessId],
    queryFn: () => fetchRegistrationStatus(businessId),
    enabled: businessId > 0,
  });

  const business = statusQuery.data?.business;
  const status = business?.status ?? params.status ?? 'pending';
  const name = business?.name ?? params.name ?? '';
  const reason = business?.rejection_reason ?? business?.suspension_reason ?? params.reason ?? '';
  const copy = COPY[status] ?? COPY.pending;

  return (
    <Screen>
      <View style={{ alignItems: 'center', gap: spacing.md, marginTop: spacing.xxxl }}>
        <StatusIcon tint={status === 'pending' ? colors.primaryContainer : colors.dangerBg}>
          <Ionicons name={copy.icon} size={48} color={status === 'pending' ? colors.primary : colors.danger} />
        </StatusIcon>
        <Text style={[typography.h1, { color: colors.textPrimary, textAlign: 'center' }]}>{copy.title}</Text>
        {name ? <Text style={[typography.titleSmall, { color: colors.textSecondary }]}>{name}</Text> : null}
        <Text style={[typography.body, { color: colors.textSecondary, textAlign: 'center' }]}>{copy.text}</Text>
        {reason ? <Text style={[typography.body, { color: colors.danger, textAlign: 'center' }]}>Reason: {reason}</Text> : null}
      </View>
      {businessId > 0 && status === 'pending' ? (
        <Button label="Check status" variant="outline" icon="refresh-outline" loading={statusQuery.isFetching} onPress={() => statusQuery.refetch()} />
      ) : null}
      <Button label="Back to sign in" onPress={() => router.replace('/login')} />
    </Screen>
  );
}
