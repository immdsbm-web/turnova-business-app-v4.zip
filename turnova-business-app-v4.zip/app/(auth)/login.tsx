import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Constants from 'expo-constants';
import { BrandMark } from '@/src/components/BrandMark';
import { Button } from '@/src/components/Button';
import { TextField } from '@/src/components/TextField';
import { useTheme } from '@/src/theme';
import { login } from '@/src/api/business';
import { ApiError } from '@/src/api/types';
import { useSession } from '@/src/auth/session';

export default function LoginScreen() {
  const { colors, typography, spacing } = useTheme();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const signIn = useSession((s) => s.signIn);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [touched, setTouched] = useState(false);

  // Inline validation, shown after the first tap on Sign in.
  const emailError = touched && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()) ? 'Enter a valid email address' : null;
  const passwordError = touched && password.length === 0 ? 'Enter your password' : null;
  const canSubmit = !busy;

  const submit = async () => {
    setTouched(true);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()) || password.length === 0) return;
    setError(null);
    setBusy(true);
    try {
      const result = await login(email.trim(), password, `${Platform.OS} app ${Constants.expoConfig?.version ?? ''}`.trim());
      await signIn(result);
      router.replace('/');
    } catch (e) {
      if (e instanceof ApiError && e.code === 'BUSINESS_NOT_APPROVED') {
        const b = e.details?.business ?? {};
        router.replace({
          pathname: '/pending-approval',
          params: { name: b.name ?? '', status: b.status ?? 'pending', reason: b.rejection_reason ?? b.suspension_reason ?? '' },
        });
        return;
      }
      setError(e instanceof ApiError ? e.message : 'Something went wrong. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={{ height: insets.top }} />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={{ flexGrow: 1, padding: spacing.xl, gap: spacing.lg }} keyboardShouldPersistTaps="handled">
          <View style={{ alignItems: 'center', marginTop: spacing.xxxl, marginBottom: spacing.xl, gap: spacing.md }}>
            <BrandMark size={72} />
            <Text style={[typography.h1, { color: colors.textPrimary, textAlign: 'center', marginTop: spacing.sm }]}>Welcome back</Text>
            <Text style={[typography.body, { color: colors.textSecondary, textAlign: 'center', maxWidth: 290 }]}>
              Sign in to manage your queue.
            </Text>
          </View>

          <TextField
            label="Email"
            placeholder="you@business.com"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            autoCorrect={false}
            keyboardType="email-address"
            textContentType="username"
            error={emailError}
          />
          <TextField
            label="Password"
            placeholder="Enter your password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry={!showPassword}
            autoCapitalize="none"
            textContentType="password"
            onSubmitEditing={() => canSubmit && submit()}
            error={passwordError ?? error}
            right={
              <Pressable
                onPress={() => setShowPassword((v) => !v)}
                hitSlop={10}
                accessibilityRole="button"
                accessibilityLabel={showPassword ? 'Hide password' : 'Show password'}
              >
                <Ionicons name={showPassword ? 'eye-off-outline' : 'eye-outline'} size={20} color={colors.textSecondary} />
              </Pressable>
            }
          />

          <Button label="Sign in" onPress={submit} disabled={!canSubmit} loading={busy} style={{ marginTop: spacing.sm }} />

          <View style={{ flexDirection: 'row', justifyContent: 'center', marginTop: spacing.lg, gap: 6 }}>
            <Text style={[typography.body, { color: colors.textSecondary }]}>New business?</Text>
            <Pressable onPress={() => router.push('/register')} hitSlop={8} accessibilityRole="button">
              <Text style={[typography.bodyStrong, { color: colors.primary }]}>Register</Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}
