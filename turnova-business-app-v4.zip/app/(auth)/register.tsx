import React, { useEffect, useState } from 'react';
import { KeyboardAvoidingView, Platform, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Button } from '@/src/components/Button';
import { LocationPicker } from '@/src/components/LocationPicker';
import { ChipRow } from '@/src/components/ChipRow';
import { Screen } from '@/src/components/Screen';
import { TextField } from '@/src/components/TextField';
import { TimeField } from '@/src/components/TimeField';
import { Notice } from '@/src/components/Ui';
import { useTheme } from '@/src/theme';
import { fetchCategories, registerBusiness } from '@/src/api/business';
import { ApiError, Category } from '@/src/api/types';
import { stripToDigits } from '@/src/utils/phone';
import { DAYS } from '@/src/utils/days';

type Step = 1 | 2 | 3;
// Which step each server-side field error belongs to, so a server error jumps back to the right step.
const STEP_OF: Record<string, Step> = {
  business_name: 1, category_id: 1, address: 1, city: 1, district: 1, state: 1,
  open_time: 2, close_time: 2, hours: 2, days: 2, location: 2, lat: 2, lng: 2,
  owner_name: 3, owner_email: 3, owner_phone: 3, password: 3, password_confirm: 3,
};
const TITLES: Record<Step, { title: string; sub: string }> = {
  1: { title: 'Tell us about your business', sub: 'We review every business before it goes live.' },
  2: { title: 'Hours and location', sub: 'When customers can book, and where to find you.' },
  3: { title: 'Your owner account', sub: 'You will sign in with your email and password.' },
};

export default function RegisterScreen() {
  const { colors, typography, spacing } = useTheme();
  const router = useRouter();

  const [step, setStep] = useState<Step>(1);
  const [categories, setCategories] = useState<Category[]>([]);
  const [form, setForm] = useState({
    business_name: '', category_id: '', address: '', city: '', district: '', state: '',
    open_time: '09:00', close_time: '18:00', owner_name: '', owner_email: '', owner_phone: '', password: '', password_confirm: '',
  });
  const [days, setDays] = useState<string[]>(['mon', 'tue', 'wed', 'thu', 'fri', 'sat']);
  const [lat, setLat] = useState('');
  const [lng, setLng] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    fetchCategories().then((r) => setCategories(r.categories)).catch(() => setFormError('Could not load categories. Check your connection and reopen this screen.'));
  }, []);

  const set = (key: keyof typeof form) => (value: string) => {
    setForm((f) => ({ ...f, [key]: value }));
    if (errors[key]) setErrors((e) => { const n = { ...e }; delete n[key]; return n; });
  };

  // Quick checks for the step being left; the server still does the authoritative validation on submit.
  const validate = (s: Step): Record<string, string> => {
    const e: Record<string, string> = {};
    if (s === 1) {
      if (!form.business_name.trim()) e.business_name = 'Enter your business name';
      if (!form.category_id) e.category_id = 'Choose a category';
      if (!form.address.trim()) e.address = 'Enter the address';
      if (!form.city.trim()) e.city = 'Enter the city';
    }
    if (s === 2 && days.length === 0) e.days = 'Pick at least one operating day';
    if (s === 3) {
      if (!form.owner_name.trim()) e.owner_name = 'Enter your name';
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.owner_email.trim())) e.owner_email = 'Enter a valid email';
      if (form.owner_phone.length !== 10) e.owner_phone = 'Enter a 10-digit mobile number';
      if (form.password.length < 8) e.password = 'Use at least 8 characters';
      if (!form.password_confirm || form.password_confirm !== form.password) e.password_confirm = 'Passwords do not match';
    }
    return e;
  };

  const next = () => {
    const e = validate(step);
    setErrors(e);
    if (Object.keys(e).length) return;
    if (step < 3) setStep((step + 1) as Step);
    else submit();
  };

  const submit = async () => {
    setBusy(true);
    setErrors({});
    setFormError(null);
    try {
      const result = await registerBusiness({
        ...form,
        owner_phone: stripToDigits(form.owner_phone),
        days,
        lat,
        lng,
      } as never);
      router.replace({ pathname: '/pending-approval', params: { business_id: String(result.business_id) } });
    } catch (e) {
      if (e instanceof ApiError && e.code === 'VALIDATION_ERROR') {
        const details = e.details as Record<string, string>;
        setErrors(details);
        setFormError('Please fix the highlighted fields.');
        const first = Math.min(...Object.keys(details).map((k) => STEP_OF[k] ?? 3)) as Step;
        setStep(first);
      } else {
        setFormError(e instanceof ApiError ? e.message : 'Something went wrong. Please try again.');
      }
    } finally {
      setBusy(false);
    }
  };

  const footer = (
    <View style={{ flexDirection: 'row', gap: spacing.sm + 2 }}>
      {step > 1 ? (
        <View style={{ flex: 1 }}>
          <Button label="Back" variant="outline" onPress={() => { setErrors({}); setStep((step - 1) as Step); }} />
        </View>
      ) : null}
      <View style={{ flex: 1 }}>
        <Button label={step < 3 ? 'Continue' : 'Submit for approval'} onPress={next} loading={busy} />
      </View>
    </View>
  );

  return (
    <Screen title="Create account" back footer={footer}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ gap: spacing.lg }}>
        <View style={{ gap: 8 }}>
          <Text style={[typography.label, { color: colors.textSecondary }]}>Step {step} of 3</Text>
          <View style={{ flexDirection: 'row', gap: 6 }}>
            {[1, 2, 3].map((i) => (
              <View key={i} style={{ flex: 1, height: 3, borderRadius: 2, backgroundColor: i <= step ? colors.primary : colors.border }} />
            ))}
          </View>
        </View>
        <View style={{ gap: 4 }}>
          <Text style={[typography.h1, { color: colors.textPrimary }]}>{TITLES[step].title}</Text>
          <Text style={[typography.body, { color: colors.textSecondary }]}>{TITLES[step].sub}</Text>
        </View>

        {formError ? <Notice tone="danger">{formError}</Notice> : null}

        {step === 1 ? (
          <>
            <TextField label="Business name" value={form.business_name} onChangeText={set('business_name')} error={errors.business_name} />
            <View style={{ gap: 8 }}>
              <Text style={[typography.label, { color: colors.textSecondary }]}>Category</Text>
              <ChipRow
                items={categories.map((c) => ({ value: String(c.id), label: c.name }))}
                selected={form.category_id}
                onSelect={set('category_id')}
              />
              {errors.category_id ? <Text style={[typography.caption, { color: colors.dangerText, fontSize: 12 }]}>{errors.category_id}</Text> : null}
            </View>
            <TextField label="Address" value={form.address} onChangeText={set('address')} error={errors.address} />
            <TextField label="City" value={form.city} onChangeText={set('city')} error={errors.city} />
            <TextField label="District" value={form.district} onChangeText={set('district')} error={errors.district} />
            <TextField label="State" value={form.state} onChangeText={set('state')} error={errors.state} />
          </>
        ) : null}

        {step === 2 ? (
          <>
            <TimeField label="Opens" value={form.open_time} onChange={set('open_time')} />
            <TimeField label="Closes" value={form.close_time} onChange={set('close_time')} />
            {errors.hours ? <Text style={[typography.caption, { color: colors.dangerText }]}>{errors.hours}</Text> : null}
            <View style={{ gap: 8 }}>
              <Text style={[typography.label, { color: colors.textSecondary }]}>Operating days</Text>
              <ChipRow
                items={DAYS}
                selected=""
                isSelected={(v) => days.includes(v)}
                onSelect={(v) => { setErrors((e) => ({ ...e, days: '' })); setDays((d) => (d.includes(v) ? d.filter((x) => x !== v) : [...d, v])); }}
              />
              {errors.days ? <Text style={[typography.caption, { color: colors.dangerText, fontSize: 12 }]}>{errors.days}</Text> : null}
            </View>
            <View style={{ gap: 8 }}>
              <Text style={[typography.label, { color: colors.textSecondary }]}>Location</Text>
              <Text style={[typography.caption, { color: colors.textSecondary }]}>Helps customers find you nearby.</Text>
              <LocationPicker
                initialLat={lat}
                initialLng={lng}
                onChange={(la, ln) => { setLat(la); setLng(ln); }}
                error={errors.location}
              />
            </View>
          </>
        ) : null}

        {step === 3 ? (
          <>
            <TextField label="Your name" value={form.owner_name} onChangeText={set('owner_name')} error={errors.owner_name} />
            <TextField label="Email" value={form.owner_email} onChangeText={set('owner_email')} autoCapitalize="none" keyboardType="email-address" error={errors.owner_email} />
            <TextField label="Mobile number" prefix="+91" value={form.owner_phone} onChangeText={(t) => set('owner_phone')(stripToDigits(t).slice(0, 10))} keyboardType="number-pad" error={errors.owner_phone} />
            <TextField label="Password" value={form.password} onChangeText={set('password')} secureTextEntry autoCapitalize="none" error={errors.password} />
            <TextField label="Confirm password" value={form.password_confirm} onChangeText={set('password_confirm')} secureTextEntry autoCapitalize="none" error={errors.password_confirm} />
          </>
        ) : null}
      </KeyboardAvoidingView>
    </Screen>
  );
}
