import React, { useEffect } from 'react';
import { Redirect } from 'expo-router';
import { useSession } from '@/src/auth/session';
import { useIsOnline } from '@/src/hooks/useIsOnline';
import { OfflineScreen } from '@/src/components/OfflineScreen';
import { ProfileLoading } from '@/src/components/ProfileLoading';

/** Entry: decides where to go -- login, owner home, or the staff queue. */
export default function Index() {
  const token = useSession((s) => s.token);
  const me = useSession((s) => s.me);
  const refreshMe = useSession((s) => s.refreshMe);
  const { isOnline, recheck } = useIsOnline();

  // Signed in but the profile could not be loaded yet (e.g. weak network on launch).
  useEffect(() => {
    if (token && !me) refreshMe().catch(() => undefined);
  }, [token, me, refreshMe]);

  if (!isOnline) return <OfflineScreen onRetry={recheck} />;
  if (!token) return <Redirect href="/login" />;
  if (!me) return <ProfileLoading />;
  return <Redirect href={me.account.role === 'owner' ? '/home' : '/my-queue'} />;
}
