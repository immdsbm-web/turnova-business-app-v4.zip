import React, { useState } from 'react';
import { Linking, Text, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Avatar } from '@/src/components/Avatar';
import { Button } from '@/src/components/Button';
import { Card } from '@/src/components/Card';
import { ConfirmSheet } from '@/src/components/ConfirmSheet';
import { Screen } from '@/src/components/Screen';
import { StatusBadge } from '@/src/components/StatusBadge';
import { TextField } from '@/src/components/TextField';
import { Notice } from '@/src/components/Ui';
import { LoadingState } from '@/src/components/LoadingState';
import { useToast } from '@/src/components/Toast';
import { useTheme } from '@/src/theme';
import { cancelBooking, fetchBookings, fetchChats } from '@/src/api/business';
import { BookingRow } from '@/src/api/types';
import { useAction } from '@/src/features/common/useAction';
import { formatBookingDay, formatTimeRange12, truthy } from '@/src/utils/format';
import { formatPhone, stripToDigits } from '@/src/utils/phone';

const CANCELLABLE = ['upcoming', 'waiting', 'called'];

/** Everything about one booking, opened from the Bookings list. */
export default function BookingDetailScreen() {
  const { colors, typography, spacing } = useTheme();
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const { busy, run } = useAction();
  // Opened from the Bookings list with the whole booking (b), or from chat with just its id.
  const { b: raw, id } = useLocalSearchParams<{ b?: string; id?: string }>();

  let passed: BookingRow | null = null;
  try { passed = raw ? (JSON.parse(raw) as BookingRow) : null; } catch { passed = null; }
  const byId = useQuery({
    queryKey: ['booking', id],
    enabled: !passed && !!id,
    queryFn: () => fetchBookings({ booking_id: Number(id), page: 1, page_size: 5 }),
    select: (r) => r.result.rows[0] ?? null,
  });
  const b: BookingRow | null = passed ?? byId.data ?? null;

  const [cancelOpen, setCancelOpen] = useState(false);
  const [reason, setReason] = useState('');
  const [reasonError, setReasonError] = useState<string | null>(null);
  const [opening, setOpening] = useState(false);

  if (!b && byId.isLoading) return <Screen title="Booking details" back><LoadingState /></Screen>;
  if (!b) {
    return (
      <Screen title="Booking" back>
        <Text style={[typography.body, { color: colors.textSecondary }]}>This booking could not be opened.</Text>
      </Screen>
    );
  }
  const booking = b;
  const digits = stripToDigits(booking.customer_phone ?? '');

  const call = () => { if (digits) Linking.openURL(`tel:+91${digits.slice(-10)}`).catch(() => undefined); };

  // Chats are per customer; find the one that belongs to this booking's customer.
  const message = async () => {
    setOpening(true);
    try {
      const res = await fetchChats();
      const chat = res.conversations.find((c) => c.customer.id === booking.customer_id);
      if (chat) router.push({ pathname: '/chat/[id]', params: { id: String(chat.id), name: chat.customer.name, photo: chat.customer.photo_url ?? '' } });
      else toast.show('No messages with this customer yet.', 'error');
    } catch {
      toast.show('Could not open messages. Please try again.', 'error');
    } finally {
      setOpening(false);
    }
  };

  const confirmCancel = async () => {
    if (!reason.trim()) { setReasonError('Please enter a reason. It is shared with the customer.'); return; }
    const ok = await run(() => cancelBooking(booking.id, reason.trim()), 'Booking cancelled.');
    if (ok) {
      setCancelOpen(false);
      qc.invalidateQueries({ queryKey: ['bookings'] });
      qc.invalidateQueries({ queryKey: ['bookings-count'] });
      qc.invalidateQueries({ queryKey: ['dashboard'] });
      router.back();
    }
  };

  const Row = ({ label, value }: { label: string; value: string }) => (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 10, gap: spacing.md }}>
      <Text style={[typography.body, { color: colors.textSecondary }]}>{label}</Text>
      <Text style={[typography.bodyStrong, { color: colors.textPrimary, flex: 1, textAlign: 'right' }]}>{value}</Text>
    </View>
  );
  const Sep = () => <View style={{ height: 1, backgroundColor: colors.border }} />;

  return (
    <Screen title="Booking details" back>
      <View style={{ gap: spacing.lg }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
          <Avatar uri={booking.customer_photo_url} name={booking.customer_name} size={56} shape="tile" />
          <View style={{ flex: 1, gap: 6 }}>
            <Text style={[typography.h2, { color: colors.textPrimary }]} numberOfLines={1}>{booking.customer_name}</Text>
            <View style={{ flexDirection: 'row' }}><StatusBadge status={booking.status} /></View>
          </View>
        </View>

        {truthy(booking.flagged_for_reassignment) ? (
          <Notice tone="warning">The assigned staff member is on leave for this date. Reassign or cancel this booking.</Notice>
        ) : null}

        <Card padded={false} style={{ paddingHorizontal: spacing.lg }}>
          <Row label="Phone" value={digits ? formatPhone(digits.slice(-10)) : '—'} />
          <Sep />
          <Row label="Date" value={formatBookingDay(booking.booking_date)} />
          <Sep />
          <Row label="Time" value={formatTimeRange12(booking.booking_time, booking.end_time) || '—'} />
          <Sep />
          <Row label="Staff" value={booking.staff_name ?? 'Any available'} />
          <Sep />
          <Row label="Services" value={booking.service_names ?? '—'} />
        </Card>

        <View style={{ flexDirection: 'row', gap: spacing.sm + 2 }}>
          <View style={{ flex: 1 }}><Button label="Call" variant="outline" icon="call-outline" onPress={call} disabled={!digits} /></View>
          <View style={{ flex: 1 }}><Button label="Message" variant="outline" icon="chatbubble-outline" onPress={message} loading={opening} /></View>
        </View>

        {CANCELLABLE.includes(booking.status) ? (
          <Button label="Cancel booking" variant="destructive-outline" onPress={() => { setReason(''); setReasonError(null); setCancelOpen(true); }} />
        ) : null}
      </View>

      <ConfirmSheet
        visible={cancelOpen}
        title="Cancel this booking?"
        message={`${booking.customer_name} will be told why it was cancelled.`}
        confirmLabel="Cancel booking"
        destructive
        loading={busy}
        onConfirm={confirmCancel}
        onClose={() => setCancelOpen(false)}
      >
        <TextField label="Reason (shared with the customer)" value={reason} onChangeText={setReason} multiline error={reasonError} />
      </ConfirmSheet>
    </Screen>
  );
}
