import React, { useEffect, useRef, useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useIsFocused } from '@react-navigation/native';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Circle, Defs, Pattern, Rect } from 'react-native-svg';
import { Avatar } from '@/src/components/Avatar';
import { BackButton } from '@/src/components/BackButton';
import { useToast } from '@/src/components/Toast';
import { useTheme } from '@/src/theme';
import { ApiError, ChatConversation, ChatMessage } from '@/src/api/types';
import { useSession } from '@/src/auth/session';
import { fetchChatMessages, markChatRead, sendChatMessage } from '@/src/api/business';

const KIND_LABEL: Record<string, string> = {
  booking_confirmed: 'Booking confirmed', opening_notice: 'Opening-time notice', reminder: 'Reminder sent',
  your_turn: "Customer called", no_show: 'Marked as no-show', cancelled: 'Booking cancelled',
};

/** System messages that get a "View Booking" link (opens that booking's details). */
const BOOKING_LINK_KINDS = ['booking_confirmed', 'your_turn', 'reminder', 'cancelled', 'no_show'];

type IconName = keyof typeof Ionicons.glyphMap;
type NoticeTone = 'primary' | 'info' | 'solid' | 'warning' | 'danger';
const NOTICE_STYLE: Record<string, { icon: IconName; tone: NoticeTone }> = {
  booking_confirmed: { icon: 'checkmark-circle-outline', tone: 'primary' },
  opening_notice: { icon: 'calendar-outline', tone: 'info' },
  reminder: { icon: 'notifications-outline', tone: 'info' },
  your_turn: { icon: 'notifications', tone: 'solid' },
  no_show: { icon: 'alert-circle-outline', tone: 'warning' },
  cancelled: { icon: 'close-circle-outline', tone: 'danger' },
};

function parseDate(t: string): Date {
  return new Date(t.replace(' ', 'T'));
}

/** "5:08 PM", time only: the day is shown by the day separator. */
function timeOnly(t: string): string {
  const d = parseDate(t);
  if (Number.isNaN(d.getTime())) return t;
  return d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
}

/** "Today" / "Yesterday" / "Sat, 17 Oct" for the day separators. */
function dayLabel(t: string): string {
  const d = parseDate(t);
  if (Number.isNaN(d.getTime())) return '';
  const today = new Date();
  const yesterday = new Date();
  yesterday.setDate(today.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return 'Today';
  if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
  return d.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' }).replace(',', '');
}

/**
 * The server writes system messages as a few lines that start with the message's own title
 * ("Booking confirmed" then the business, services, ...). The card already shows that title as
 * its heading, so drop a repeated first line instead of showing the same words twice.
 */
function noticeLines(body: string, heading: string): string[] {
  const lines = body.split('\n').map((l) => l.trim()).filter(Boolean);
  if (lines.length > 1 && lines[0].toLowerCase() === heading.toLowerCase()) lines.shift();
  return lines;
}

/** Faint dotted wallpaper behind the messages (uses the divider colour, so it works in light and dark). */
function ChatWallpaper({ color }: { color: string }) {
  return (
    <Svg style={StyleSheet.absoluteFill} pointerEvents="none">
      <Defs>
        <Pattern id="dots" width={22} height={22} patternUnits="userSpaceOnUse">
          <Circle cx={11} cy={11} r={1} fill={color} />
        </Pattern>
      </Defs>
      <Rect width="100%" height="100%" fill="url(#dots)" />
    </Svg>
  );
}

/** Two consecutive text messages from the same sender on the same day form one visual group. */
function sameGroup(a: ChatMessage | undefined, b: ChatMessage | undefined): boolean {
  if (!a || !b) return false;
  if (a.sender_type === 'system' || b.sender_type === 'system') return false;
  return a.sender_type === b.sender_type && parseDate(a.created_at).toDateString() === parseDate(b.created_at).toDateString();
}

/** One customer chat, same as the Customer app. New messages arrive every few seconds; opening the chat marks it read for you only. */
export default function ChatScreen() {
  const { colors, typography, spacing } = useTheme();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { id, name: nameParam, photo: photoParam } = useLocalSearchParams<{ id: string; name?: string; photo?: string }>();
  const chatId = Number(id);
  const focused = useIsFocused();
  const qc = useQueryClient();
  const refreshMe = useSession((st) => st.refreshMe);
  const toast = useToast();
  const scroller = useRef<ScrollView>(null);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [inputFocused, setInputFocused] = useState(false);

  const query = useQuery({
    queryKey: ['chat', chatId],
    queryFn: () => fetchChatMessages(chatId),
    refetchInterval: focused ? 4000 : false,
    staleTime: 0,
  });
  const messages = query.data?.messages ?? [];
  // Show the customer's name + photo at once: loaded chat, else the Messages list cache, else the tapped row's params.
  const cachedChat = qc
    .getQueryData<{ conversations: ChatConversation[] }>(['chats'])
    ?.conversations.find((c) => c.id === Number(id));
  const customer =
    query.data?.conversation.customer ??
    cachedChat?.customer ??
    (nameParam ? { id: 0, name: String(nameParam), photo_url: photoParam ? String(photoParam) : null } : undefined);
  const lastId = messages.length ? messages[messages.length - 1].id : 0;

  useEffect(() => {
    if (!focused || !lastId) return;
    markChatRead(chatId)
      .then(() => {
        qc.invalidateQueries({ queryKey: ['chat-unread'] });
        qc.invalidateQueries({ queryKey: ['chats'] });
        refreshMe().catch(() => undefined);
      })
      .catch(() => undefined);
    setTimeout(() => scroller.current?.scrollToEnd({ animated: true }), 50);
  }, [lastId, focused, chatId, qc, refreshMe]);

  const send = async () => {
    const body = text.trim();
    if (!body || sending) return;
    setSending(true);
    try {
      await sendChatMessage(chatId, body);
      setText('');
      await query.refetch();
    } catch (e) {
      toast.show(e instanceof ApiError ? e.message : 'Could not send the message.', 'error');
    } finally {
      setSending(false);
    }
  };

  const noticeTint = (tone: NoticeTone) => {
    switch (tone) {
      case 'info':
        return { bg: colors.infoBg, fg: colors.infoText };
      case 'solid':
        return { bg: colors.primary, fg: colors.primaryText };
      case 'warning':
        return { bg: colors.warningBg, fg: colors.warningText };
      case 'danger':
        return { bg: colors.dangerBg, fg: colors.dangerText };
      default:
        return { bg: colors.primaryContainer, fg: colors.primary };
    }
  };

  const bubble = (m: ChatMessage, groupStart = true, groupEnd = true) => {
    if (m.sender_type === 'system') {
      const heading = KIND_LABEL[m.kind] ?? 'Notification';
      const style = NOTICE_STYLE[m.kind] ?? { icon: 'info' as IconName, tone: 'primary' as NoticeTone };
      const tint = noticeTint(style.tone);
      const lines = noticeLines(m.body, heading);
      return (
        <View
          key={m.id}
          style={[styles.notice, { backgroundColor: colors.surface, borderColor: colors.border }]}
        >
          <View style={[styles.noticeIcon, { backgroundColor: tint.bg }]}>
            <Ionicons name={style.icon} size={18} color={tint.fg} />
          </View>
          <View style={{ flex: 1, marginLeft: 12 }}>
            <Text style={[typography.bodyStrong, { color: colors.textPrimary, fontSize: 14, lineHeight: 20 }]}>{heading}</Text>
            {lines.map((line, i) => (
              <Text key={i} style={[typography.caption, { color: colors.textSecondary }]}>
                {line}
              </Text>
            ))}
            {m.booking_id && BOOKING_LINK_KINDS.includes(m.kind) ? (
              <Pressable
                onPress={() => router.push({ pathname: '/booking-detail', params: { id: String(m.booking_id) } })}
                accessibilityRole="link"
                accessibilityLabel="View Booking"
                hitSlop={8}
                style={{ flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start', marginTop: 6 }}
              >
                <Text style={[typography.captionStrong, { color: colors.primary }]}>View Booking</Text>
                <Ionicons name="chevron-forward" size={14} color={colors.primary} />
              </Pressable>
            ) : null}
            <Text style={[typography.tab, { color: colors.textSecondary, marginTop: 6 }]}>{timeOnly(m.created_at)}</Text>
          </View>
        </View>
      );
    }
    const mine = m.sender_type === 'business';
    // Rounded bubbles; only the last bubble of a group has the small "tail" corner.
    const tail = groupEnd ? 5 : 18;
    return (
      <View
        key={m.id}
        style={[
          styles.bubble,
          { marginTop: groupStart ? 8 : 0 },
          mine
            ? { alignSelf: 'flex-end', backgroundColor: colors.primary, borderBottomRightRadius: tail }
            : {
                alignSelf: 'flex-start',
                backgroundColor: colors.surface,
                borderColor: colors.border,
                borderWidth: 1,
                borderBottomLeftRadius: tail,
              },
        ]}
      >
        {mine && groupStart ? (
          <Text style={[typography.captionStrong, { color: colors.primaryText, opacity: 0.85 }]}>
            {(m.sender_name ?? 'Business') + (m.sender_role === 'staff' ? ' · staff' : ' · owner')}
          </Text>
        ) : null}
        {/* Time sits at the bottom right: beside a short message, on its own line under a long one. */}
        <View style={styles.bubbleRow}>
          <Text style={[typography.body, { color: mine ? colors.primaryText : colors.textPrimary, flexShrink: 1 }]}>{m.body}</Text>
          <Text
            style={[
              typography.tab,
              { color: mine ? colors.primaryText : colors.textSecondary, opacity: 0.75, marginLeft: 10, marginTop: 6 },
            ]}
          >
            {timeOnly(m.created_at)}
          </Text>
        </View>
      </View>
    );
  };

  // Day separators between messages from different days.
  const items: React.ReactNode[] = [];
  let lastDay = '';
  messages.forEach((m, index) => {
    const day = dayLabel(m.created_at);
    const key = parseDate(m.created_at).toDateString();
    if (key !== lastDay) {
      lastDay = key;
      items.push(
        <View key={`day-${m.id}`} style={[styles.day, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[typography.label, { color: colors.textSecondary, fontSize: 12 }]}>{day}</Text>
        </View>,
      );
    }
    items.push(bubble(m, !sameGroup(messages[index - 1], m), !sameGroup(m, messages[index + 1])));
  });

  const canSend = !sending && text.trim().length > 0;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <View
        style={[
          styles.header,
          { paddingTop: insets.top + 6, borderBottomColor: colors.border, backgroundColor: colors.surface },
        ]}
      >
        <BackButton />
        {customer ? (
          <Avatar uri={customer.photo_url} name={customer.name} size={42} shape="tile" />
        ) : (
          <View style={{ width: 42, height: 42, borderRadius: 10, backgroundColor: colors.border }} />
        )}
        <Text style={[typography.appBar, { color: colors.textPrimary, marginLeft: 12, flex: 1 }]} numberOfLines={1}>
          {customer?.name ?? ''}
        </Text>
      </View>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={{ flex: 1 }}>
          <ChatWallpaper color={colors.border} />
          <ScrollView
            ref={scroller}
            style={{ flex: 1 }}
            contentContainerStyle={{ paddingHorizontal: 12, paddingTop: 8, paddingBottom: 14, gap: 2 }}
            keyboardShouldPersistTaps="handled"
          >
            {messages.length === 0 && !query.isLoading ? (
              <Text style={[typography.caption, { color: colors.textSecondary, textAlign: 'center' }]}>No messages yet.</Text>
            ) : null}
            {items}
          </ScrollView>
        </View>

        <View
          style={[
            styles.compose,
            {
              paddingBottom: 12 + insets.bottom,
              borderTopColor: colors.border,
              backgroundColor: colors.background,
            },
          ]}
        >
          <TextInput
            value={text}
            onChangeText={setText}
            onFocus={() => setInputFocused(true)}
            onBlur={() => setInputFocused(false)}
            placeholder="Message"
            placeholderTextColor={colors.textSecondary}
            multiline
            maxLength={1000}
            style={[
              typography.body,
              styles.input,
              {
                color: colors.textPrimary,
                backgroundColor: colors.surface,
                borderColor: inputFocused ? colors.primary : colors.border,
              },
            ]}
          />
          <Pressable
            onPress={send}
            disabled={!canSend}
            accessibilityRole="button"
            accessibilityLabel="Send message"
            style={[styles.send, { backgroundColor: colors.primary, opacity: canSend ? 1 : 0.4, shadowColor: colors.shadow }]}
          >
            <Ionicons name="send" size={20} color={colors.primaryText} />
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', borderBottomWidth: 1, paddingLeft: 8, paddingRight: 16, paddingBottom: 8 },
  day: { alignSelf: 'center', borderRadius: 12, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 4, marginTop: 10, marginBottom: 8 },
  bubble: { maxWidth: '80%', borderRadius: 18, paddingLeft: 12, paddingRight: 10, paddingTop: 7, paddingBottom: 6, shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 1 },
  bubbleRow: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'flex-end', justifyContent: 'flex-end' },
  notice: { alignSelf: 'flex-end', maxWidth: '88%', flexDirection: 'row', borderRadius: 16, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 12, marginVertical: 8 },
  noticeIcon: { width: 32, height: 32, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  compose: { flexDirection: 'row', alignItems: 'flex-end', borderTopWidth: 1, paddingTop: 8, paddingHorizontal: 12 },
  input: { flex: 1, maxHeight: 110, minHeight: 48, borderRadius: 24, borderWidth: 1, paddingHorizontal: 18, paddingTop: 12, paddingBottom: 12, marginRight: 8 },
  send: { width: 48, height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center', elevation: 2, shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.18, shadowRadius: 3 },
});
