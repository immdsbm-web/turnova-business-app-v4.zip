import React from 'react';
import { Redirect, Tabs } from 'expo-router';
import { CustomTabBar } from '@/src/components/CustomTabBar';
import { useSession } from '@/src/auth/session';
import { useTheme } from '@/src/theme';

export default function StaffTabs() {
  const role = useSession((s) => s.me?.account.role);
  const { colors } = useTheme();

  if (role !== 'staff') return <Redirect href="/home" />;

  return (
    <Tabs
      tabBar={(props) => <CustomTabBar {...props} />}
      screenOptions={{ headerShown: false, sceneStyle: { backgroundColor: colors.background } }}
    >
      <Tabs.Screen name="my-queue" options={{ title: 'Appointments' }} />
      <Tabs.Screen name="my-qr" options={{ title: 'QR code' }} />
      <Tabs.Screen name="my-profile" options={{ title: 'Profile' }} />
    </Tabs>
  );
}
