import React from 'react';
import { QrView } from '@/src/features/qr/QrView';

export default function StaffQr() {
  return <QrView tabs />;
}
