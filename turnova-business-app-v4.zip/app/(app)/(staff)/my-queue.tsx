import React from 'react';
import { QueueView } from '@/src/features/queue/QueueView';

export default function StaffQueue() {
  return <QueueView tabs />;
}
