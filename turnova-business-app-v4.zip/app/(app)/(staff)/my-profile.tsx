import { MessagesButton } from '@/src/components/MessagesButton';
import React, { useEffect, useState } from 'react';
import { Text } from 'react-native';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/src/components/Button';
import { Card } from '@/src/components/Card';
import { ErrorState } from '@/src/components/ErrorState';
import { LoadingState } from '@/src/components/LoadingState';
import { PhotoField, PickedPhoto } from '@/src/components/PhotoField';
import { Screen } from '@/src/components/Screen';
import { ConfirmSheet } from '@/src/components/ConfirmSheet';
import { useTheme } from '@/src/theme';
import { fetchMyProfile, saveMyPhoto } from '@/src/api/business';
import { useSession } from '@/src/auth/session';
import { useAction } from '@/src/features/common/useAction';

export default function MyProfileScreen() {
  const { colors, typography, spacing } = useTheme();
  const me = useSession((s) => s.me);
  const signOut = useSession((s) => s.signOut);
  const qc = useQueryClient();
  const { busy, run } = useAction();
  const query = useQuery({ queryKey: ['my-profile'], queryFn: fetchMyProfile });
  const staff = query.data?.staff;

  const [picked, setPicked] = useState<PickedPhoto | null>(null);
  const [removed, setRemoved] = useState(false);
  const [confirmOut, setConfirmOut] = useState(false);
  useEffect(() => { setPicked(null); setRemoved(false); }, [staff?.photo_url]);

  const save = async () => {
    const ok = await run(() => saveMyPhoto(picked, removed && !picked), 'Profile photo updated.');
    if (ok) {
      setPicked(null);
      setRemoved(false);
      qc.invalidateQueries({ queryKey: ['my-profile'] });
    }
  };

  const dirty = picked !== null || removed;

  return (
    <Screen title="My profile" subtitle={me?.business.name} right={<MessagesButton />} tabs>
      {query.isLoading ? <LoadingState /> : null}
      {query.isError && !staff ? <ErrorState message="Couldn't load your profile." onRetry={() => query.refetch()} /> : null}
      {staff ? (
        <>
          <Card style={{ gap: spacing.md }}>
            <Text style={[typography.h2, { color: colors.textPrimary }]}>{staff.name}</Text>
            <Text style={[typography.body, { color: colors.textSecondary }]}>{staff.role ?? 'Staff'} · {me?.account.email}</Text>
            <PhotoField
              label="Profile photo"
              name={staff.name}
              currentUrl={staff.photo_url}
              picked={picked}
              removed={removed}
              onPick={(p) => { setPicked(p); setRemoved(false); }}
              onRemove={() => { setPicked(null); setRemoved(true); }}
            />
            <Button label="Save photo" loading={busy} disabled={!dirty} onPress={save} />
          </Card>
          <Button label="Sign out" variant="destructive-outline" icon="log-out-outline" onPress={() => setConfirmOut(true)} />
        </>
      ) : null}
      <ConfirmSheet visible={confirmOut} title="Sign out?" confirmLabel="Sign out" destructive onConfirm={() => signOut()} onClose={() => setConfirmOut(false)} />
    </Screen>
  );
}
