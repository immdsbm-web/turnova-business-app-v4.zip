import { MessagesButton } from '@/src/components/MessagesButton';
import React from 'react';
import { Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@tanstack/react-query';
import { Card } from '@/src/components/Card';
import { ErrorState } from '@/src/components/ErrorState';
import { LoadingState } from '@/src/components/LoadingState';
import { Screen } from '@/src/components/Screen';
import { Notice, SectionTitle, StatTile } from '@/src/components/Ui';
import { QuickActionsRow, quickActions } from '@/src/components/QuickActions';
import { useTheme } from '@/src/theme';
import { fetchDashboard } from '@/src/api/business';
import { useSession } from '@/src/auth/session';
import { formatShort } from '@/src/components/DateStrip';
import { formatTime12 } from '@/src/utils/format';

function greeting(): string {
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
}

export default function HomeScreen() {
  const { colors, typography, spacing, radii } = useTheme();
  const me = useSession((s) => s.me);
  const query = useQuery({ queryKey: ['dashboard'], queryFn: fetchDashboard, refetchInterval: 20000 });
  const d = query.data;
  const onHero = colors.primaryText;
  const heroSoft = colors.primaryText + '24'; // translucent overlay of the text colour

  const quick = quickActions();

  return (
    <Screen tabs refreshing={query.isRefetching} onRefresh={() => query.refetch()}>
      {/* Hero summary */}
      <View style={{ backgroundColor: colors.primary, borderRadius: radii.card + 4, padding: spacing.lg + 2, gap: spacing.lg }}>
        <View style={{ position: 'absolute', top: spacing.sm, right: spacing.sm, zIndex: 2 }}>
          <MessagesButton color={onHero} />
        </View>
        <View style={{ gap: 2, paddingRight: 44 }}>
          <Text style={[typography.caption, { color: onHero, opacity: 0.85 }]}>{greeting()}, {me?.account.name?.split(' ')[0] ?? ''}</Text>
          <Text style={[typography.h1, { color: onHero }]} numberOfLines={1}>{me?.business.name ?? 'Dashboard'}</Text>
          {me?.plan.notice ? (
            <View style={{ flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start', gap: 6, backgroundColor: heroSoft, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 4, marginTop: 8 }}>
              <Ionicons name="time-outline" size={13} color={onHero} />
              <Text style={[typography.caption, { color: onHero, fontFamily: 'Inter_700Bold' }]}>{me.plan.notice.replace(/\.$/, '')}</Text>
            </View>
          ) : null}
        </View>

        <View style={{ flexDirection: 'row', alignItems: 'stretch', backgroundColor: heroSoft, borderRadius: radii.card, paddingVertical: spacing.md, paddingHorizontal: spacing.sm }}>
          {[
            { label: "Today's bookings", value: d?.summary.todays_bookings },
            { label: 'Remaining today', value: d?.summary.current_queue_length },
            { label: 'Active staff', value: d?.summary.active_staff },
          ].map((m, i) => (
            <React.Fragment key={m.label}>
              {/* Divider is its own element with margin, so it can never touch the text. */}
              {i > 0 ? <View style={{ width: 1, marginVertical: 6, backgroundColor: onHero + '47' }} /> : null}
              <View style={{ flex: 1, alignItems: 'center', gap: 2, paddingHorizontal: 6 }}>
                <Text style={[typography.metric, { color: onHero }]}>{m.value == null ? '–' : Number(m.value) || 0}</Text>
                <Text style={[typography.caption, { color: onHero, opacity: 0.88, textAlign: 'center' }]}>{m.label}</Text>
              </View>
            </React.Fragment>
          ))}
        </View>
      </View>

      {query.isLoading ? <LoadingState /> : null}
      {query.isError && !d ? <ErrorState message="Couldn't load the dashboard." onRetry={() => query.refetch()} /> : null}

      {d ? (
        <>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.md }}>
            <StatTile label="Upcoming bookings" value={Number(d.summary.upcoming_bookings) || 0} icon="time-outline" tone="info" />
            <StatTile label="Staff with login" value={Number(d.summary.staff_with_login) || 0} icon="key-outline" tone="neutral" />
          </View>

          <SectionTitle>Quick actions</SectionTitle>
          <QuickActionsRow items={quick} variant="card" />

          {(d.flagged_bookings ?? []).length > 0 ? (
            <>
              <SectionTitle>Needs reassignment ({d.flagged_bookings.length})</SectionTitle>
              {d.flagged_bookings.map((b, i) => (
                <Card key={b.id ?? i} accent={colors.danger} style={{ gap: 2, paddingLeft: spacing.lg + 4 }}>
                  <Text style={[typography.titleSmall, { color: colors.textPrimary }]}>{b.customer_name}</Text>
                  <Text style={[typography.caption, { color: colors.textSecondary }]}>
                    {formatShort(b.booking_date)}{b.booking_time ? `, ${formatTime12(b.booking_time)}` : ''} · {b.service_names ?? 'Service'}
                  </Text>
                  <Text style={[typography.caption, { color: colors.danger, fontFamily: 'Inter_600SemiBold' }]}>{b.staff_name ?? 'Assigned staff'} is on leave</Text>
                </Card>
              ))}
            </>
          ) : (
            <Notice tone="success">All bookings are covered. Nothing needs reassignment.</Notice>
          )}
        </>
      ) : null}
    </Screen>
  );
}
