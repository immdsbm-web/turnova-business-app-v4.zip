import { MessagesButton } from '@/src/components/MessagesButton';
import React, { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useQuery } from '@tanstack/react-query';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Avatar } from '@/src/components/Avatar';
import { BottomSheet } from '@/src/components/BottomSheet';
import { Button } from '@/src/components/Button';
import { Card } from '@/src/components/Card';
import { Screen } from '@/src/components/Screen';
import { StatusBadge } from '@/src/components/StatusBadge';
import { IconTile } from '@/src/components/Ui';
import { QuickActionsRow, quickActions } from '@/src/components/QuickActions';
import { SettingsList, SettingsRow, SettingsSwitchRow } from '@/src/components/SettingsList';
import { useTheme, useThemeMode } from '@/src/theme';
import { useSession } from '@/src/auth/session';
import { fetchBusinessProfile } from '@/src/api/business';
import { formatDateLong } from '@/src/utils/format';

/**
 * Manage = the business hub: green header, quick shortcuts, Billing (now lives
 * here instead of its own tab), and the remaining management screens.
 */
export default function ManageScreen() {
  const { colors, typography, spacing, radii, isDark } = useTheme();
  const { toggleDarkMode } = useThemeMode();
  const router = useRouter();
  const me = useSession((s) => s.me);
  const signOut = useSession((s) => s.signOut);
  const [confirmOut, setConfirmOut] = useState(false);

  const plan = me?.plan;
  const planState = plan?.state ?? 'none';
  const [loggingOut, setLoggingOut] = useState(false);
  const insets = useSafeAreaInsets();
  const onHero = '#FFFFFF';
  // The business logo (same query the Edit business screen uses, so it is usually already cached).
  const profile = useQuery({ queryKey: ['business-profile'], queryFn: fetchBusinessProfile, staleTime: 60_000 });
  const logoUrl = profile.data?.business.logo_url ?? null;

  const shortcuts = quickActions(me?.badges.flagged_for_reassignment);

  const handleConfirmLogout = async () => {
    setLoggingOut(true);
    try {
      await signOut();
    } finally {
      setLoggingOut(false);
      setConfirmOut(false);
    }
  };

  return (
    <Screen tabs contentStyle={{ paddingHorizontal: 0, paddingTop: 0 }}>
      {/* Hero band, as before; the tile shows the business logo (its initial when there is none). */}
      <View style={{ backgroundColor: colors.hero, paddingTop: insets.top + spacing.md, paddingHorizontal: spacing.xl, paddingBottom: spacing.xl, borderBottomLeftRadius: radii.card, borderBottomRightRadius: radii.card }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md }}>
          <Avatar uri={logoUrl} name={me?.business.name} size={48} />
          <View style={{ flex: 1 }}>
            <Text style={[typography.h1, { color: onHero }]} numberOfLines={1}>{me?.business.name ?? 'Manage'}</Text>
            <Text style={[typography.caption, { color: onHero, opacity: 0.8 }]} numberOfLines={1}>{me?.account.name} · Owner</Text>
          </View>
          <MessagesButton color={onHero} />
        </View>
        {plan?.notice ? (
          <View style={{ marginTop: spacing.lg }}>
            <Text style={[typography.caption, { color: onHero, fontFamily: 'Inter_700Bold' }]}>{plan.notice.replace(/\.$/, '')}</Text>
          </View>
        ) : null}
      </View>

      <View style={{ paddingHorizontal: spacing.xl, gap: spacing.md, marginTop: spacing.lg }}>
        {/* Shortcuts: same four as Home */}
        <QuickActionsRow items={shortcuts} variant="circle" />

        {/* Billing (moved here from the bottom tab bar) */}
        <Card style={{ gap: spacing.md }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md }}>
            <IconTile icon="wallet-outline" size={42} />
            <View style={{ flex: 1 }}>
              <Text style={[typography.titleSmall, { color: colors.textPrimary }]}>Billing</Text>
              <Text style={[typography.caption, { color: colors.textSecondary }]} numberOfLines={1}>
                {plan?.name ? `${plan.name} plan` : 'No plan chosen'}{plan?.valid_until && planState !== 'none' ? ` · until ${formatDateLong(plan.valid_until)}` : ''}
              </Text>
            </View>
            <StatusBadge status={planState} />
          </View>
          <View style={{ flexDirection: 'row', gap: spacing.sm }}>
            <View style={{ flex: 1 }}><Button label="Payments" size="sm" variant="secondary" onPress={() => router.push('/billing')} /></View>
            <View style={{ flex: 1 }}><Button label={plan?.name ? 'Change plan' : 'Choose a plan'} size="sm" variant="outline" onPress={() => router.push('/plans')} /></View>
          </View>
        </Card>

        <SettingsList>
          <SettingsRow icon="calendar-outline" label="Dates & Breaks" onPress={() => router.push('/more/dates-capacity')} />
          <SettingsRow icon="images-outline" label="Add Photos" onPress={() => router.push('/more/photos')} />
          <SettingsRow icon="image-outline" label="Banner" onPress={() => router.push('/more/banners')} />
          <SettingsRow icon="storefront-outline" label="Edit business" onPress={() => router.push('/more/business-edit')} />
          <SettingsRow icon="star-outline" label="Reviews" onPress={() => router.push('/more/reviews')} />
          <SettingsSwitchRow icon="moon-outline" label="Dark Mode" value={isDark} onValueChange={toggleDarkMode} />
        </SettingsList>

        <View style={{ paddingTop: spacing.lg }}>
          <Button label="Log out" icon="log-out-outline" variant="destructive-outline" onPress={() => setConfirmOut(true)} />
        </View>
      </View>

      <BottomSheet visible={confirmOut} onClose={() => setConfirmOut(false)} variant="center">
        <Text style={[typography.h2, { color: colors.textPrimary, marginBottom: spacing.xl }]}>Log out?</Text>
        <View style={{ flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center' }}>
          <Pressable onPress={() => setConfirmOut(false)} accessibilityRole="button" style={{ height: 44, paddingHorizontal: 16, justifyContent: 'center' }}>
            <Text style={[typography.button, { fontSize: 15, color: colors.textSecondary }]}>Cancel</Text>
          </Pressable>
          {/* Destructive action: red text, no fill. */}
          <Pressable onPress={handleConfirmLogout} disabled={loggingOut} accessibilityRole="button" style={{ height: 44, paddingHorizontal: 16, justifyContent: 'center', opacity: loggingOut ? 0.6 : 1 }}>
            <Text style={[typography.button, { fontSize: 15, color: colors.dangerText }]}>Log out</Text>
          </Pressable>
        </View>
      </BottomSheet>
    </Screen>
  );
}
