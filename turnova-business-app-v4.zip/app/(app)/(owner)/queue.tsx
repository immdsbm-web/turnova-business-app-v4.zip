import React from 'react';
import { QueueView } from '@/src/features/queue/QueueView';

export default function OwnerQueue() {
  return <QueueView tabs />;
}
