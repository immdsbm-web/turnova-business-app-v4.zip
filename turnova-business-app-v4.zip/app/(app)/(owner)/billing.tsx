import React, { useState } from 'react';
import { Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/src/components/Button';
import { Card } from '@/src/components/Card';
import { EmptyState } from '@/src/components/EmptyState';
import { ErrorState } from '@/src/components/ErrorState';
import { LoadingState } from '@/src/components/LoadingState';
import { Screen } from '@/src/components/Screen';
import { StatusBadge } from '@/src/components/StatusBadge';
import { InfoRow, Notice, SectionTitle } from '@/src/components/Ui';
import { useTheme } from '@/src/theme';
import { downloadReceipt, fetchBilling } from '@/src/api/business';
import { useToast } from '@/src/components/Toast';
import { formatDateLong, formatDateTime, rupees } from '@/src/utils/format';

export default function BillingScreen() {
  const { colors, typography, spacing, radii } = useTheme();
  const router = useRouter();
  const toast = useToast();
  const query = useQuery({ queryKey: ['billing'], queryFn: fetchBilling });
  const [downloading, setDownloading] = useState<number | null>(null);
  const d = query.data;

  const plan = d?.current.plan ?? null;
  const state = d?.current.state ?? 'none';
  const maxStaff = d?.usage.max_staff;
  const maxPhotos = d?.usage.max_photos;
  const gstNote = d?.breakdown && d.breakdown.gst > 0
    ? d.settings.prices_include_gst
      ? `Inclusive of ${Number(d.settings.gst_percent)}% GST`
      : `+ ${rupees(d.breakdown.gst)} GST`
    : undefined;

  const receipt = async (id: number) => {
    setDownloading(id);
    try {
      await downloadReceipt(id);
    } catch (e) {
      toast.show(e instanceof Error ? e.message : 'Could not download the receipt.', 'error');
    } finally {
      setDownloading(null);
    }
  };

  const statusTone: Record<string, string> = { trial: 'Free trial', active: 'Active', expired: 'Expired', cancelled: 'Cancelled', none: 'No plan' };
  const onHero = colors.primaryText;
  const heroSoft = colors.primaryText + '24';

  return (
    <Screen title="Billing" subtitle="Plan, payments and receipts" back tabs refreshing={query.isRefetching} onRefresh={() => query.refetch()}>
      {query.isLoading ? <LoadingState /> : null}
      {query.isError && !d ? <ErrorState message="Couldn't load billing." onRetry={() => query.refetch()} /> : null}

      {d ? (
        <>
          {state === 'expired' ? <Notice tone="danger">Your plan has expired. Renew to keep accepting bookings.</Notice> : null}
          {state === 'cancelled' ? <Notice tone="danger">Your subscription was cancelled. Please contact support to get it re-enabled.</Notice> : null}

          {/* Plan hero */}
          <View style={{ backgroundColor: colors.primary, borderRadius: radii.card + 4, padding: spacing.lg + 2, gap: spacing.md }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text style={[typography.overline, { color: onHero, opacity: 0.8, flex: 1 }]}>CURRENT PLAN</Text>
              <View style={{ backgroundColor: heroSoft, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 3 }}>
                <Text style={[typography.caption, { color: onHero, fontFamily: 'Inter_700Bold' }]}>{statusTone[state] ?? state}</Text>
              </View>
            </View>
            {plan ? (
              <>
                <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 6 }}>
                  <Text style={[typography.display, { color: onHero, fontSize: 34, lineHeight: 40 }]}>{plan.name}</Text>
                  <Text style={[typography.body, { color: onHero, opacity: 0.85, marginBottom: 5 }]}>{rupees(d.breakdown?.total)} / month</Text>
                </View>
                {gstNote ? <Text style={[typography.caption, { color: onHero, opacity: 0.8, marginTop: -6 }]}>{gstNote}</Text> : null}
                <View style={{ backgroundColor: heroSoft, borderRadius: radii.input, padding: spacing.md, gap: 2 }}>
                  <Text style={[typography.caption, { color: onHero, opacity: 0.85 }]}>{state === 'expired' ? 'Payment overdue since' : 'Next due date'}</Text>
                  <Text style={[typography.h2, { color: onHero }]}>{state === 'cancelled' ? '—' : formatDateLong(d.current.valid_until)}</Text>
                  {state === 'trial' || state === 'active' ? (
                    <Text style={[typography.caption, { color: onHero, opacity: 0.85 }]}>
                      {state === 'trial' ? 'Free trial ends · ' : ''}{d.current.days_left} day{d.current.days_left === 1 ? '' : 's'} left
                    </Text>
                  ) : null}
                </View>
              </>
            ) : (
              <Text style={[typography.body, { color: onHero }]}>You have not chosen a plan yet. Start your free trial from Change Plans.</Text>
            )}
            <View style={{ flexDirection: 'row', gap: spacing.sm }}>
              {plan && state !== 'cancelled' && d.breakdown ? (
                <Pressable
                  onPress={() => router.push({ pathname: '/pay', params: { planId: String(plan.id) } })}
                  disabled={!d.gateway_ready}
                  accessibilityRole="button"
                  style={{ flex: 1.4, minHeight: 46, borderRadius: radii.button, backgroundColor: onHero, alignItems: 'center', justifyContent: 'center', opacity: d.gateway_ready ? 1 : 0.5 }}
                >
                  <Text style={[typography.button, { color: colors.primaryDark }]}>Pay {rupees(d.breakdown.total)}</Text>
                </Pressable>
              ) : null}
              <Pressable
                onPress={() => router.push('/plans')}
                accessibilityRole="button"
                style={{ flex: 1, minHeight: 46, borderRadius: radii.button, borderWidth: 1, borderColor: heroSoft, backgroundColor: heroSoft, alignItems: 'center', justifyContent: 'center' }}
              >
                <Text style={[typography.button, { color: onHero }]}>{plan ? 'Change plan' : 'Choose a plan'}</Text>
              </Pressable>
            </View>
            {plan && !d.gateway_ready ? <Text style={[typography.caption, { color: onHero, opacity: 0.85 }]}>Online payment is not available right now.</Text> : null}
          </View>

          {d.usage.photos_notice ? (
            <Notice tone="danger">
              Too many photos for your plan. {d.usage.photos_notice} Nothing is deleted automatically and customers still see your photos;
              you just can't add new ones until you delete the extra ones (Edit business → Photos).
            </Notice>
          ) : null}

          {plan ? (
            <>
              <SectionTitle>Plan details</SectionTitle>
              <Card>
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', columnGap: spacing.lg }}>
                  <InfoRow label="Activation date" value={formatDateLong(d.activated_at)} />
                  <InfoRow label="Billing cycle" value="Monthly" />
                  <InfoRow label="Staff" value={`${d.usage.staff_count} of ${maxStaff ?? 'unlimited'}`} />
                  <InfoRow label="Photos" value={`${d.usage.photo_count ?? 0} of ${maxPhotos == null ? 'unlimited' : maxPhotos}`} />
                  <InfoRow label="Free trial" value={`${plan.trial_days} days`} />
                  <InfoRow label="Payment method" value="UPI" hint="Pay each month, no auto-debit" />
                </View>
              </Card>
            </>
          ) : null}

          <SectionTitle>Summary</SectionTitle>
          <Card>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', columnGap: spacing.lg }}>
              <InfoRow label="Total paid" value={rupees(d.totals.total_paid)} />
              <InfoRow label="Payments made" value={String(d.totals.paid_count)} />
              <InfoRow label="Last payment" value={formatDateLong(d.totals.last_paid_at)} />
              <InfoRow label="Currency" value="INR (₹)" />
              {d.contact ? <InfoRow label="Billing contact" value={d.contact.name} hint={`${d.contact.email}\n${d.contact.phone}`} /> : null}
            </View>
          </Card>

          <SectionTitle>Payments & receipts</SectionTitle>
          {d.payments.length === 0 ? (
            <EmptyState icon="receipt-outline" title="No payments yet" subtitle="Your payments and receipts will appear here." />
          ) : (
            <Card padded={false}>
              {d.payments.map((p, idx) => {
                const payable = p.status === 'created' && !!p.link_url && !!p.link_expires_at && new Date(p.link_expires_at.replace(' ', 'T')).getTime() > Date.now();
                const shown = p.status === 'created' ? (payable ? 'created' : 'link expired') : p.status;
                const receiptNo = `SQR-${String(p.id).padStart(6, '0')}`;
                const last = idx === d.payments.length - 1;
                return (
                  <View key={p.id} style={{ padding: spacing.md, gap: spacing.xs, borderBottomWidth: last ? 0 : StyleSheet.hairlineWidth, borderBottomColor: colors.border }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md }}>
                      <View style={{ flex: 1 }}>
                        <Text style={[typography.titleSmall, { color: colors.textPrimary }]}>{p.plan_name} · {rupees(p.total_amount)}</Text>
                        <Text style={[typography.caption, { color: colors.textSecondary }]}>
                          {formatDateTime(p.paid_at ?? p.created_at)}{Number(p.gst_amount) > 0 ? ` · incl. ${rupees(p.gst_amount)} GST` : ''}
                        </Text>
                        {p.status === 'paid' && p.period_start && p.period_end ? (
                          <Text style={[typography.caption, { color: colors.textMuted }]}>Covers {formatDateLong(p.period_start)} – {formatDateLong(p.period_end)} · {receiptNo}</Text>
                        ) : null}
                      </View>
                      <StatusBadge status={shown} />
                    </View>
                    {p.status === 'paid' ? (
                      <Button label="Download receipt (PDF)" size="sm" variant="secondary" icon="download-outline" loading={downloading === p.id} onPress={() => receipt(p.id)} />
                    ) : payable ? (
                      <Button label="Complete payment" size="sm" variant="outline" onPress={() => Linking.openURL(p.link_url as string)} />
                    ) : null}
                  </View>
                );
              })}
            </Card>
          )}
        </>
      ) : null}
    </Screen>
  );
}
