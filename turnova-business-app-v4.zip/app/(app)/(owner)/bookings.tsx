import { MessagesButton } from '@/src/components/MessagesButton';
import React, { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useInfiniteQuery, useQuery } from '@tanstack/react-query';
import { ChipRow } from '@/src/components/ChipRow';
import { EmptyState } from '@/src/components/EmptyState';
import { ErrorState } from '@/src/components/ErrorState';
import { LoadingState } from '@/src/components/LoadingState';
import { Button } from '@/src/components/Button';
import { UnderlineTabs } from '@/src/components/UnderlineTabs';
import { ListRow } from '@/src/components/ListRow';
import { Screen } from '@/src/components/Screen';
import { formatShort, toYmd } from '@/src/components/DateStrip';
import { CalendarSheet } from '@/src/components/CalendarSheet';
import { useTheme } from '@/src/theme';
import { fetchBookings } from '@/src/api/business';
import { BookingRow } from '@/src/api/types';
import { formatBookingDay, formatTimeRange12, truthy } from '@/src/utils/format';

// Status filters: All, Completed, Cancelled, No show. (Day tabs above are separate and combine with these.)
const STATUSES = ['', 'completed', 'cancelled', 'no_show'];

export default function BookingsScreen() {
  const { colors, typography, spacing } = useTheme();
  const router = useRouter();

  const [status, setStatus] = useState('');
  const [staffId, setStaffId] = useState(0);
  // A picked date RANGE (past dates allowed) overrides the day tabs.
  const [pickedRange, setPickedRange] = useState<{ from: string; to: string } | null>(null);
  const [calendarOpen, setCalendarOpen] = useState(false);
  // Day tabs: Today, Tomorrow, or Upcoming (the day after tomorrow onward).
  const [tab, setTab] = useState<'today' | 'tomorrow' | 'upcoming'>('today');
  const dayYmd = (offset: number) => { const d = new Date(); d.setHours(12, 0, 0, 0); d.setDate(d.getDate() + offset); return toYmd(d); };
  const todayYmd = dayYmd(0);
  const tomorrowYmd = dayYmd(1);
  const dayAfterYmd = dayYmd(2);
  const range: { from?: string; to?: string } = pickedRange
    ? pickedRange
    : tab === 'today' ? { from: todayYmd, to: todayYmd } : tab === 'tomorrow' ? { from: tomorrowYmd, to: tomorrowYmd } : { from: dayAfterYmd, to: undefined };

  const query = useInfiniteQuery({
    queryKey: ['bookings', status, staffId, range.from ?? '', range.to ?? ''],
    initialPageParam: 1,
    queryFn: ({ pageParam }) =>
      fetchBookings({
        status: status || undefined,
        staff_id: staffId || undefined,
        date_from: range.from,
        date_to: range.to,
        page: pageParam,
        page_size: 20,
      }),
    getNextPageParam: (last) => (last.result.page < last.result.total_pages ? last.result.page + 1 : undefined),
  });

  const pages = query.data?.pages ?? [];
  const rows = pages.flatMap((p) => p.result.rows);
  const staffList = pages[0]?.staff_list ?? [];
  const total = pages[0]?.result.total ?? 0;

  // Counts shown on the day tabs (ignore the status chip so they stay stable).
  const countQ = (key: string, from?: string, to?: string) =>
    useQuery({
      queryKey: ['bookings-count', key, staffId],
      queryFn: () => fetchBookings({ staff_id: staffId || undefined, date_from: from, date_to: to, page: 1, page_size: 1 }),
      select: (r) => r.result.total,
    });
  const todayCount = countQ('today', todayYmd, todayYmd).data;
  const tomorrowCount = countQ('tomorrow', tomorrowYmd, tomorrowYmd).data;
  const upcomingCount = countQ('upcoming', dayAfterYmd, undefined).data;

  return (
    <Screen title="Bookings" subtitle={`${total} booking${total === 1 ? '' : 's'}`} right={<MessagesButton />} tabs refreshing={query.isRefetching && !query.isFetchingNextPage} onRefresh={() => query.refetch()}>
      <UnderlineTabs
        value={pickedRange ? null : tab}
        onChange={(t) => { setPickedRange(null); setTab(t); }}
        items={[
          { value: 'today', label: 'Today', count: todayCount },
          { value: 'tomorrow', label: 'Tomorrow', count: tomorrowCount },
          { value: 'upcoming', label: 'Upcoming', count: upcomingCount },
        ]}
      />
      <ChipRow
        items={STATUSES.map((s) => ({ value: s, label: s === '' ? 'All' : s.replace('_', ' ').replace(/^./, (c) => c.toUpperCase()) }))}
        selected={status}
        onSelect={setStatus}
      />
      {staffList.length > 1 ? (
        <ChipRow
          items={[{ value: 0, label: 'All staff' }, ...staffList.map((s) => ({ value: s.id, label: s.name }))]}
          selected={staffId}
          onSelect={setStaffId}
        />
      ) : null}
      <ChipRow
        items={[
          { value: 'date', label: pickedRange ? (pickedRange.from === pickedRange.to ? formatShort(pickedRange.from) : `${formatShort(pickedRange.from)} – ${formatShort(pickedRange.to)}`) : 'Filter by date', icon: 'calendar-outline' },
          ...(pickedRange ? [{ value: 'clear', label: 'Clear', icon: 'close-outline' as const }] : []),
        ]}
        selected=""
        isSelected={(v) => v === 'date' && !!pickedRange}
        onSelect={(v) => (v === 'clear' ? setPickedRange(null) : setCalendarOpen(true))}
      />
      <CalendarSheet
        visible={calendarOpen}
        range
        title="Show bookings for"
        value={pickedRange?.from ?? null}
        rangeValue={pickedRange}
        onClose={() => setCalendarOpen(false)}
        onPickRange={(from, to) => setPickedRange({ from, to })}
        onClearRange={() => setPickedRange(null)}
      />

      {query.isLoading ? <LoadingState /> : null}
      {query.isError && rows.length === 0 ? <ErrorState message="Couldn't load bookings." onRetry={() => query.refetch()} /> : null}
      {!query.isLoading && !query.isError && rows.length === 0 ? (
        <EmptyState icon="receipt-outline" title="No bookings found" subtitle="Try a different filter." />
      ) : null}

      <View>
        {rows.map((b, i) => (
          <ListRow
            key={b.id}
            uri={b.customer_photo_url}
            name={b.customer_name}
            title={b.customer_name}
            status={b.status}
            lines={[formatBookingDay(b.booking_date), formatTimeRange12(b.booking_time, b.end_time) || null, truthy(b.flagged_for_reassignment) ? 'Assigned staff on leave. Needs reassignment.' : null]}
            last={i === rows.length - 1}
            onPress={() => router.push({ pathname: '/booking-detail', params: { b: JSON.stringify(b) } })}
          />
        ))}
      </View>

      {query.hasNextPage ? (
        <Button label="Load more" variant="outline" loading={query.isFetchingNextPage} onPress={() => query.fetchNextPage()} />
      ) : null}

    </Screen>
  );
}
