import React from 'react';
import { Redirect, Tabs } from 'expo-router';
import { CustomTabBar } from '@/src/components/CustomTabBar';
import { useSession } from '@/src/auth/session';
import { useTheme } from '@/src/theme';

export default function OwnerTabs() {
  const role = useSession((s) => s.me?.account.role);
  const { colors } = useTheme();

  // Staff accounts never see owner screens.
  if (role !== 'owner') return <Redirect href="/my-queue" />;

  return (
    <Tabs
      tabBar={(props) => <CustomTabBar {...props} />}
      screenOptions={{ headerShown: false, sceneStyle: { backgroundColor: colors.background } }}
    >
      <Tabs.Screen name="home" options={{ title: 'Home' }} />
      <Tabs.Screen name="queue" options={{ title: 'Appointments' }} />
      <Tabs.Screen name="bookings" options={{ title: 'Bookings' }} />
      <Tabs.Screen name="manage" options={{ title: 'Manage' }} />
      {/* Billing lives inside Manage now: still a route, but no tab. */}
      <Tabs.Screen name="billing" options={{ href: null }} />
    </Tabs>
  );
}
