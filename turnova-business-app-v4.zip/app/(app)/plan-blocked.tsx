import React from 'react';
import { Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Button } from '@/src/components/Button';
import { Screen } from '@/src/components/Screen';
import { StatusIcon } from '@/src/components/BrandMark';
import { useTheme } from '@/src/theme';
import { useSession } from '@/src/auth/session';

/** Shown for owner AND staff whenever the plan is not running (same wording as the website). */
export default function PlanBlockedScreen() {
  const { colors, typography, spacing } = useTheme();
  const router = useRouter();
  const me = useSession((s) => s.me);
  const signOut = useSession((s) => s.signOut);
  const refreshMe = useSession((s) => s.refreshMe);
  const isOwner = me?.account.role === 'owner';
  const state = me?.plan.state ?? 'expired';

  const message =
    state === 'none'
      ? isOwner ? 'Please choose a plan to start using Turnova.' : 'This business has not activated a plan yet. Please ask the business owner.'
      : state === 'cancelled'
        ? isOwner ? 'Your subscription has been cancelled. Please contact support.' : 'This business subscription is cancelled. Please contact the business owner.'
        : isOwner
          ? 'Your plan has expired. Renew to keep accepting bookings.'
          : 'This business plan has expired. Please ask the business owner to renew it.';

  const running = state === 'trial' || state === 'active';

  return (
    <Screen>
      <View style={{ alignItems: 'center', gap: spacing.md, marginTop: spacing.xxxl }}>
        <StatusIcon tint={colors.warningBg}>
          <Ionicons name="alert-circle" size={52} color={colors.warning} />
        </StatusIcon>
        <Text style={[typography.h1, { color: colors.textPrimary, textAlign: 'center' }]}>{state === 'none' ? 'Choose a plan' : 'Plan expired'}</Text>
        <Text style={[typography.body, { color: colors.textSecondary, textAlign: 'center' }]}>{message}</Text>
      </View>
      {running ? <Button label="Continue" onPress={() => router.replace('/')} /> : null}
      {isOwner && state !== 'cancelled' ? (
        <Button label={state === 'none' ? 'Choose a plan' : 'Renew / choose a plan'} onPress={() => router.push(state === 'none' ? '/plans' : '/billing')} />
      ) : null}
      <Button label="Check again" variant="outline" icon="refresh-outline" onPress={() => refreshMe().catch(() => undefined)} />
      <Button label="Sign out" variant="destructive-outline" onPress={() => signOut()} />
    </Screen>
  );
}
