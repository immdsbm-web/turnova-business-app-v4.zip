import React, { useState } from 'react';
import { Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/src/components/Button';
import { Card } from '@/src/components/Card';
import { ErrorState } from '@/src/components/ErrorState';
import { LoadingState } from '@/src/components/LoadingState';
import { Screen } from '@/src/components/Screen';
import { StatusBadge } from '@/src/components/StatusBadge';
import { Notice } from '@/src/components/Ui';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/src/theme';
import { fetchPlans, selectPlan } from '@/src/api/business';
import { PlanCard } from '@/src/api/types';
import { useSession } from '@/src/auth/session';
import { useAction } from '@/src/features/common/useAction';
import { rupees } from '@/src/utils/format';

/** Change Plans: start a trial, subscribe, or open the upgrade / downgrade confirmation. */
export default function PlansScreen() {
  const { colors, typography, spacing } = useTheme();
  const router = useRouter();
  const qc = useQueryClient();
  const { busy, run } = useAction();
  const role = useSession((s) => s.me?.account.role);
  const [busyPlan, setBusyPlan] = useState<number | null>(null);
  const query = useQuery({ queryKey: ['plans'], queryFn: fetchPlans });
  const d = query.data;
  const state = d?.current.state ?? 'none';
  const running = state === 'trial' || state === 'active';

  if (role && role !== 'owner') {
    return <Screen title="Plans" back><Notice tone="primary">Only the business owner can manage plans.</Notice></Screen>;
  }

  const limit = (v: number | null, unit: string) => (v == null ? `Unlimited ${unit}` : `${v} ${unit}`);
  const gstNote = (c: PlanCard) =>
    !d || c.breakdown.gst <= 0 ? null
      : d.settings.prices_include_gst ? `Inclusive of ${Number(d.settings.gst_percent)}% GST` : `+ ${rupees(c.breakdown.gst)} GST = ${rupees(c.breakdown.total)} total`;

  const startTrial = async (c: PlanCard) => {
    setBusyPlan(c.id);
    const ok = await run(async () => {
      const res = await selectPlan(c.id);
      if (res.mode === 'payment_required') {
        router.push({ pathname: '/pay', params: { planId: String(c.id) } });
        return;
      }
      await useSession.getState().refreshMe();
      qc.invalidateQueries();
      router.replace('/home');
      return { message: res.message };
    });
    setBusyPlan(null);
    return ok;
  };

  return (
    <Screen title="Change Plans" subtitle="Compare the plans and pick the one that fits your business." back refreshing={query.isRefetching} onRefresh={() => query.refetch()}>
      {query.isLoading ? <LoadingState /> : null}
      {query.isError && !d ? <ErrorState message="Couldn't load the plans." onRetry={() => query.refetch()} /> : null}

      {d && state === 'expired' ? <Notice tone="danger">Your plan has expired. Renew to keep accepting bookings.</Notice> : null}
      {d && state === 'none' ? <Notice tone="success">Welcome! Pick a plan to start your free trial. No payment is needed until the trial ends.</Notice> : null}
      {d && state === 'cancelled' ? <Notice tone="danger">Your subscription was cancelled. Please contact support.</Notice> : null}

      {d && state !== 'cancelled' ? d.cards.map((c) => (
        <Card key={c.id} style={{ gap: spacing.sm, borderColor: c.is_current ? colors.primary : colors.border, borderWidth: c.is_current ? 2 : 1 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md }}>
            <Text style={[typography.h2, { color: colors.textPrimary, flex: 1 }]}>{c.name}</Text>
            {c.is_current ? <StatusBadge status="active" label="Current" /> : null}
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 4 }}>
            <Text style={[typography.metric, { color: colors.textPrimary }]}>{rupees(c.breakdown.total)}</Text>
            <Text style={[typography.caption, { color: colors.textSecondary }]}>/month</Text>
          </View>
          {gstNote(c) ? <Text style={[typography.caption, { color: colors.textSecondary }]}>{gstNote(c)}</Text> : null}
          <View style={{ gap: 8, paddingVertical: 4 }}>
            <Feature text={limit(c.max_staff, 'staff')} />
            <Feature text={limit(c.max_photos ?? null, 'photos')} />
            {c.description ? <Text style={[typography.caption, { color: colors.textSecondary }]}>{c.description}</Text> : null}
          </View>

          {c.is_current ? (
            <Button label="Your current plan" variant="outline" disabled onPress={() => undefined} />
          ) : !c.fits ? (
            <>
              <Button label="Too many staff for this plan" variant="outline" disabled onPress={() => undefined} />
              <Text style={[typography.caption, { color: colors.textSecondary }]}>
                You have {d.usage.staff_count} staff; this plan allows {c.max_staff}. Remove staff to switch.
              </Text>
            </>
          ) : running ? (
            <>
              <Button
                label={`${c.direction === 'downgrade' ? 'Downgrade' : c.direction === 'upgrade' ? 'Upgrade' : 'Switch'} to ${c.name}`}
                variant={c.direction === 'downgrade' ? 'outline' : 'primary'}
                onPress={() => router.push({ pathname: '/change-plan', params: { planId: String(c.id) } })}
              />
              {state === 'trial' ? <Text style={[typography.caption, { color: colors.textSecondary }]}>Your free trial days stay the same.</Text> : null}
            </>
          ) : c.can_trial ? (
            <>
              <Button label={`Start ${c.trial_days}-day free trial`} loading={busy && busyPlan === c.id} disabled={busy} onPress={() => startTrial(c)} />
              <Text style={[typography.caption, { color: colors.textSecondary }]}>No payment needed until the trial ends.</Text>
            </>
          ) : (
            <>
              <Button
                label={`Subscribe · ${rupees(c.breakdown.total)}`}
                disabled={!d.gateway_ready}
                onPress={() => router.push({ pathname: '/pay', params: { planId: String(c.id) } })}
              />
              {!d.gateway_ready ? <Text style={[typography.caption, { color: colors.textSecondary }]}>Online payment is not available right now.</Text> : null}
            </>
          )}
        </Card>
      )) : null}
    </Screen>
  );
}

function Feature({ text }: { text: string }) {
  const { colors, typography } = useTheme();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
      <Ionicons name="checkmark-circle" size={18} color={colors.success} />
      <Text style={[typography.body, { color: colors.textPrimary }]}>{text}</Text>
    </View>
  );
}
