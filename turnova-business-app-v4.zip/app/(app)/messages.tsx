import React from 'react';
import { FlatList, Pressable, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useIsFocused } from '@react-navigation/native';
import { useQuery } from '@tanstack/react-query';
import { Avatar } from '@/src/components/Avatar';
import { EmptyState } from '@/src/components/EmptyState';
import { ErrorState } from '@/src/components/ErrorState';
import { LoadingState } from '@/src/components/LoadingState';
import { Screen } from '@/src/components/Screen';
import { useTheme } from '@/src/theme';
import { fetchChats } from '@/src/api/business';

function whenLabel(t: string | null): string {
  if (!t) return '';
  const d = new Date(t.replace(' ', 'T'));
  if (Number.isNaN(d.getTime())) return '';
  return d.toDateString() === new Date().toDateString()
    ? d.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit', hour12: true }).toUpperCase()
    : d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
}

/** Chat list, same as the Customer app: plain rows, square tile, time, one-line preview, unread dot. Owner sees every chat, staff only their own customers'. */
export default function MessagesScreen() {
  const { colors, typography, spacing } = useTheme();
  const router = useRouter();
  const focused = useIsFocused();
  const query = useQuery({ queryKey: ['chats'], queryFn: fetchChats, refetchInterval: focused ? 8000 : false, staleTime: 0 });
  const chats = query.data?.conversations ?? [];

  return (
    <Screen title="Messages" back scroll={false} contentStyle={{ paddingBottom: 0 }}>
      {query.isLoading ? <LoadingState /> : null}
      {query.isError && !query.data ? <ErrorState message="Couldn't load your messages." onRetry={() => query.refetch()} /> : null}
      {query.data && chats.length === 0 ? (
        <EmptyState icon="chatbubble-outline" title="No messages yet" subtitle="Booking confirmations and chats with customers appear here." />
      ) : null}
      {chats.length > 0 ? (
        <FlatList
          data={chats}
          keyExtractor={(c) => String(c.id)}
          contentContainerStyle={{ paddingBottom: spacing.xxxl }}
          refreshing={query.isRefetching}
          onRefresh={() => query.refetch()}
          ItemSeparatorComponent={() => <View style={{ height: 1, backgroundColor: colors.border }} />}
          renderItem={({ item }) => {
            const unread = item.unread > 0;
            return (
              <Pressable
                onPress={() => router.push({ pathname: '/chat/[id]', params: { id: String(item.id), name: item.customer.name, photo: item.customer.photo_url ?? '' } })}
                accessibilityRole="button"
                accessibilityLabel={`${item.customer.name}${unread ? `, ${item.unread} unread` : ''}`}
                style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', paddingVertical: 14, opacity: pressed ? 0.7 : 1 })}
              >
                <Avatar uri={item.customer.photo_url} name={item.customer.name} size={52} shape="tile" />
                <View style={{ flex: 1, marginLeft: 14 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between' }}>
                    <Text style={[typography.titleSmall, { color: colors.textPrimary, flex: 1, marginRight: 8 }]} numberOfLines={1}>{item.customer.name}</Text>
                    <Text style={[unread ? typography.badge : typography.caption, { color: unread ? colors.primary : colors.textSecondary, fontSize: 12 }]}>
                      {whenLabel(item.last_message_at)}
                    </Text>
                  </View>
                  <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 3 }}>
                    <Text
                      style={[unread ? typography.label : typography.caption, { color: unread ? colors.textPrimary : colors.textSecondary, flex: 1, fontSize: 14, lineHeight: 20 }]}
                      numberOfLines={1}
                    >
                      {item.last_message_preview}
                    </Text>
                    {unread ? (
                      <View style={{ minWidth: 20, height: 20, borderRadius: 10, paddingHorizontal: 6, marginLeft: 10, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' }}>
                        <Text style={[typography.badge, { color: colors.primaryText, fontSize: 11, lineHeight: 14 }]}>{item.unread > 99 ? '99+' : item.unread}</Text>
                      </View>
                    ) : null}
                  </View>
                </View>
              </Pressable>
            );
          }}
        />
      ) : null}
    </Screen>
  );
}
