import React, { useState } from 'react';
import { Text, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/src/components/Button';
import { Card } from '@/src/components/Card';
import { ErrorState } from '@/src/components/ErrorState';
import { LoadingState } from '@/src/components/LoadingState';
import { Screen } from '@/src/components/Screen';
import { Notice } from '@/src/components/Ui';
import { useTheme } from '@/src/theme';
import { changePlan, fetchChangePreview } from '@/src/api/business';
import { ApiError } from '@/src/api/types';
import { useSession } from '@/src/auth/session';
import { useAction } from '@/src/features/common/useAction';
import { formatDateLong, rupees } from '@/src/utils/format';

/** Upgrade / downgrade: shows what changes and asks for confirmation. */
export default function ChangePlanScreen() {
  const { colors, typography, spacing } = useTheme();
  const router = useRouter();
  const qc = useQueryClient();
  const { busy, run } = useAction();
  const { planId } = useLocalSearchParams<{ planId?: string }>();
  const id = Number(planId ?? 0);
  const query = useQuery({ queryKey: ['change-preview', id], queryFn: () => fetchChangePreview(id), retry: false });
  const d = query.data;
  const [confirming, setConfirming] = useState(false);

  const word = d ? (d.direction === 'upgrade' ? 'Upgrade' : d.direction === 'downgrade' ? 'Downgrade' : 'Switch') : 'Change';
  const limit = (v: number | null) => (v == null ? 'Unlimited' : String(v));

  const confirm = async () => {
    if (!d) return;
    setConfirming(true);
    await run(async () => {
      const res = await changePlan(id);
      if (res.mode === 'payment_required') {
        router.replace({ pathname: '/pay', params: { planId: String(id) } });
        return;
      }
      await useSession.getState().refreshMe();
      qc.invalidateQueries();
      router.replace('/billing');
      return { message: res.message };
    });
    setConfirming(false);
  };

  const money = (n: number) => rupees(n);
  const validUntil = d?.current.valid_until ?? null;
  const daysLeft = d?.current.days_left ?? 0;

  return (
    <Screen title={d ? `${word} to ${d.target.name}` : 'Change plan'} subtitle="Please review the change and confirm." back>
      {query.isLoading ? <LoadingState /> : null}
      {query.isError ? <ErrorState message={query.error instanceof ApiError ? query.error.message : "Couldn't load the plan change."} onRetry={() => query.refetch()} /> : null}

      {d ? (
        <>
          <Card style={{ gap: spacing.sm }}>
            <Text style={[typography.h2, { color: colors.textPrimary }]}>What changes</Text>
            {[
              ['Price per month', money(d.current_breakdown.total), money(d.target_breakdown.total)],
              ['Staff allowed', limit(d.current.plan?.max_staff ?? null), limit(d.target.max_staff)],
              ['Photos allowed', limit(d.current.plan?.max_photos ?? null), limit(d.target.max_photos ?? null)],
            ].map(([label, from, to]) => (
              <View key={label} style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.sm }}>
                <Text style={[typography.caption, { color: colors.textSecondary, flex: 1.3 }]}>{label}</Text>
                <Text style={[typography.body, { color: colors.textSecondary, flex: 1 }]}>{from}</Text>
                <Text style={[typography.bodyStrong, { color: colors.textPrimary, flex: 1 }]}>{to}</Text>
              </View>
            ))}
            <Text style={[typography.caption, { color: colors.textMuted }]}>Current: {d.current.plan?.name} → New: {d.target.name}</Text>
          </Card>

          {d.photos_notice ? (
            <Notice tone="danger">
              Too many photos for this plan. {d.photos_notice} You can still switch: your photos stay visible to customers and nothing is deleted automatically,
              but you can't add new photos until you delete the extra ones (Edit business → Photos).
            </Notice>
          ) : null}

          {!d.fits ? (
            <Notice tone="danger">
              You can't switch yet. You have {d.staff_count} staff members, but {d.target.name} allows only {d.target.max_staff}. Remove staff first, then come back.
            </Notice>
          ) : (
            <>
              <Card style={{ gap: spacing.sm }}>
                <Text style={[typography.h2, { color: colors.textPrimary }]}>What happens next</Text>
                {d.is_trial ? (
                  <>
                    <Text style={[typography.body, { color: colors.textPrimary }]}>• Your plan changes to {d.target.name} right away.</Text>
                    <Text style={[typography.body, { color: colors.textPrimary }]}>
                      • Free trial: {daysLeft} day{daysLeft === 1 ? '' : 's'} left. Pick a plan to continue.
                    </Text>
                    <Text style={[typography.body, { color: colors.textPrimary }]}>
                      • No payment is needed now. After the trial ends you pay {money(d.target_breakdown.total)} per month to continue on {d.target.name}.
                    </Text>
                  </>
                ) : (
                  <>
                    <Text style={[typography.body, { color: colors.textPrimary }]}>
                      • {d.target.name} starts with a new 1-month period as soon as your payment of {money(d.target_breakdown.total)} is confirmed.
                    </Text>
                    <Text style={[typography.body, { color: colors.textPrimary }]}>
                      • New plan starts today. No refund for unused days.
                    </Text>
                  </>
                )}
                {d.direction === 'downgrade' ? (
                  <Text style={[typography.body, { color: colors.textPrimary }]}>
                    • Lower limits apply: {limit(d.target.max_staff)} staff, {limit(d.target.max_photos ?? null)} photos.
                  </Text>
                ) : null}
                {!d.is_trial && !d.gateway_ready ? <Text style={[typography.caption, { color: colors.textSecondary }]}>Online payment is not available right now.</Text> : null}
              </Card>

              <Button
                label={d.is_trial ? `Confirm ${word.toLowerCase()}` : `Confirm and pay ${money(d.target_breakdown.total)}`}
                variant={d.direction === 'downgrade' ? 'destructive-outline' : 'primary'}
                loading={busy || confirming}
                disabled={!d.is_trial && !d.gateway_ready}
                onPress={confirm}
              />
              <Button label="Cancel" variant="outline" onPress={() => router.back()} />
            </>
          )}
        </>
      ) : null}
    </Screen>
  );
}
