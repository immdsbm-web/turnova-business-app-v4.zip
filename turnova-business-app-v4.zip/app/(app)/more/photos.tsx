import React, { useState } from 'react';
import { Image, Modal, Pressable, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Button } from '@/src/components/Button';
import { Card } from '@/src/components/Card';
import { ConfirmSheet } from '@/src/components/ConfirmSheet';
import { ErrorState } from '@/src/components/ErrorState';
import { LoadingState } from '@/src/components/LoadingState';
import { PhotoSheet } from '@/src/components/PhotoSheet';
import type { PickedPhoto } from '@/src/components/PhotoSheet';
import { Screen } from '@/src/components/Screen';
import { useToast } from '@/src/components/Toast';
import { Notice } from '@/src/components/Ui';
import { useTheme } from '@/src/theme';
import { ApiError, BusinessPhoto } from '@/src/api/types';
import { deleteBusinessPhoto, fetchBusinessPhotos, makeBusinessPhotoFirst, replaceBusinessPhoto, uploadBusinessPhoto } from '@/src/api/business';
import { resolveImageUrl } from '@/src/utils/media';

const COLS = 3;
const GAP = 3;

/**
 * Add Photos: an Instagram-style grid of the business gallery. Photos only.
 * Add (camera or gallery, cropped square in the system editor), open a photo to
 * replace, move to first, or delete. How many photos a business may have is set
 * by its plan and enforced by the server.
 */
export default function PhotosScreen() {
  const { colors, typography, spacing, radii } = useTheme();
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const { width } = useWindowDimensions();
  const query = useQuery({ queryKey: ['business-photos'], queryFn: fetchBusinessPhotos, staleTime: 0 });
  const photos = query.data?.photos ?? [];
  const usage = query.data?.usage;

  const [addOpen, setAddOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [openId, setOpenId] = useState<number | null>(null);
  const [replaceOpen, setReplaceOpen] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const cell = Math.floor((width - spacing.lg * 2 - GAP * (COLS - 1)) / COLS);
  const current: BusinessPhoto | undefined = photos.find((p) => p.id === openId);
  const currentIndex = current ? photos.findIndex((p) => p.id === current.id) : -1;

  const apply = (out: { photos: BusinessPhoto[]; usage: NonNullable<typeof usage> }) => qc.setQueryData(['business-photos'], { photos: out.photos, usage: out.usage });
  const fail = (e: unknown, fallback: string) => toast.show(e instanceof ApiError ? e.message : fallback, 'error');

  const add = async (p: PickedPhoto) => {
    setBusy(true);
    try {
      const out = await uploadBusinessPhoto(p);
      apply(out);
      toast.show('Photo added.', 'success');
    } catch (e) { fail(e, 'Could not upload the photo. Please try again.'); } finally { setBusy(false); }
  };
  const replace = async (p: PickedPhoto) => {
    if (!current) return;
    setBusy(true);
    try {
      const out = await replaceBusinessPhoto(current.id, p);
      apply(out);
      toast.show('Photo updated.', 'success');
    } catch (e) { fail(e, 'Could not update the photo.'); } finally { setBusy(false); }
  };
  const makeFirst = async () => {
    if (!current) return;
    setBusy(true);
    try {
      const out = await makeBusinessPhotoFirst(current.id);
      apply(out);
      toast.show('Moved to the first position.', 'success');
    } catch (e) { fail(e, 'Could not move the photo.'); } finally { setBusy(false); }
  };
  const remove = async () => {
    if (!current) return;
    setBusy(true);
    try {
      const out = await deleteBusinessPhoto(current.id);
      apply(out);
      setConfirmDelete(false);
      setOpenId(null);
      toast.show('Photo deleted.', 'success');
    } catch (e) { setConfirmDelete(false); fail(e, 'Could not delete the photo.'); } finally { setBusy(false); }
  };

  const counter = !usage ? '' : usage.max === null
    ? `${usage.count} photo${usage.count === 1 ? '' : 's'} · Unlimited on your ${usage.plan_name ?? 'current'} plan`
    : `${usage.count} of ${usage.max} photos used`;
  const planActive = usage?.state === 'trial' || usage?.state === 'active';
  const canAdd = !!usage?.can_add;

  const addTile = (
    <Pressable
      onPress={() => setAddOpen(true)}
      disabled={busy}
      accessibilityRole="button"
      accessibilityLabel="Add photo"
      style={{ width: cell, height: cell, backgroundColor: colors.primaryContainer, alignItems: 'center', justifyContent: 'center', gap: 4, opacity: busy ? 0.6 : 1 }}
    >
      <Ionicons name="add" size={30} color={colors.primary} />
      <Text style={[typography.caption, { color: colors.primary, fontFamily: 'Inter_700Bold' }]}>{busy ? 'Working…' : 'Add'}</Text>
    </Pressable>
  );

  return (
    <Screen title="Add Photos" subtitle="Shown on your business page" back refreshing={query.isRefetching} onRefresh={() => query.refetch()}>
      {query.isLoading ? <LoadingState /> : null}
      {query.isError && !usage ? <ErrorState message="Couldn't load your photos." onRetry={() => query.refetch()} /> : null}

      {usage ? (
        <>
          <Card style={{ gap: spacing.sm }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text style={[typography.bodyStrong, { color: colors.textPrimary, flex: 1 }]}>{counter}</Text>
              {usage.plan_name ? <Text style={[typography.caption, { color: colors.textSecondary }]}>{usage.plan_name} plan</Text> : null}
            </View>
            {usage.max !== null ? (
              <View style={{ height: 6, borderRadius: 3, backgroundColor: colors.neutralBg, overflow: 'hidden' }}>
                <View style={{ width: `${Math.min(100, (usage.count / Math.max(1, usage.max)) * 100)}%`, height: 6, backgroundColor: usage.count >= usage.max ? colors.warning : colors.primary }} />
              </View>
            ) : null}
            <Text style={[typography.caption, { color: colors.textSecondary }]}>
              Up to 5 MB each. Tap a photo to manage it.
            </Text>
          </Card>

          {usage.notice ? (
            <Notice tone="danger">{usage.notice}</Notice>
          ) : null}

          {canAdd ? (
            <Button label="Add photo" icon="add" loading={busy} onPress={() => setAddOpen(true)} />
          ) : !usage.notice ? (
            <View style={{ gap: spacing.sm }}>
              <Notice tone="warning" icon="information-circle">
                {planActive ? "Photo limit reached for your plan." : "Your plan has expired. Renew to keep accepting bookings."}
              </Notice>
              <Button label="View plans" variant="outline" size="sm" onPress={() => router.push('/plans')} />
            </View>
          ) : (
            <Button label="View plans" variant="outline" size="sm" onPress={() => router.push('/plans')} />
          )}

          {photos.length > 0 ? (
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: GAP, marginHorizontal: 0, borderRadius: radii.input, overflow: 'hidden' }}>
              {canAdd ? addTile : null}
              {photos.map((p, i) => {
                const uri = resolveImageUrl(p.photo_url);
                return (
                  <Pressable key={p.id} onPress={() => setOpenId(p.id)} accessibilityRole="button" accessibilityLabel={`Photo ${i + 1}`} style={{ width: cell, height: cell, backgroundColor: colors.surfaceAlt }}>
                    {uri ? <Image source={{ uri }} style={{ width: '100%', height: '100%' }} resizeMode="cover" /> : null}
                    {i === 0 ? (
                      <View style={{ position: 'absolute', left: 6, top: 6, backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: 999, paddingHorizontal: 8, paddingVertical: 2 }}>
                        <Text style={{ color: '#fff', fontSize: 10, fontFamily: 'Inter_700Bold' }}>First</Text>
                      </View>
                    ) : null}
                  </Pressable>
                );
              })}
            </View>
          ) : canAdd ? (
            <Pressable
              onPress={() => setAddOpen(true)}
              accessibilityRole="button"
              style={{ height: 150, borderRadius: radii.card, borderWidth: 1.5, borderStyle: 'dashed', borderColor: colors.primaryBorder, backgroundColor: colors.primaryContainer, alignItems: 'center', justifyContent: 'center', gap: 8 }}
            >
              <Ionicons name="images-outline" size={30} color={colors.primary} />
              <Text style={[typography.bodyStrong, { color: colors.primary }]}>Add your first photo</Text>
              <Text style={[typography.caption, { color: colors.textSecondary }]}>Photos help customers decide to book with you.</Text>
            </Pressable>
          ) : null}
        </>
      ) : null}

      <PhotoSheet visible={addOpen} onClose={() => setAddOpen(false)} aspect={[1, 1]} onPicked={add} />

      <PhotoViewer
        photo={current ?? null}
        index={currentIndex}
        total={photos.length}
        busy={busy}
        onClose={() => setOpenId(null)}
        onReplace={() => setReplaceOpen(true)}
        onMakeFirst={makeFirst}
        onDelete={() => setConfirmDelete(true)}
      >
        {/* Sheets live inside the viewer's modal so they stack correctly on iOS. */}
        <PhotoSheet visible={replaceOpen} onClose={() => setReplaceOpen(false)} aspect={[1, 1]} onPicked={replace} />
        <ConfirmSheet visible={confirmDelete} title="Delete this photo?" message="It will be removed from your business page." confirmLabel="Delete photo" destructive loading={busy} onConfirm={remove} onClose={() => setConfirmDelete(false)} />
      </PhotoViewer>
    </Screen>
  );
}

function PhotoViewer({ photo, index, total, busy, onClose, onReplace, onMakeFirst, onDelete, children }: {
  children?: React.ReactNode;
  photo: BusinessPhoto | null; index: number; total: number; busy: boolean;
  onClose: () => void; onReplace: () => void; onMakeFirst: () => void; onDelete: () => void;
}) {
  const { colors, typography, spacing } = useTheme();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  if (!photo) return null;
  const uri = resolveImageUrl(photo.photo_url);
  return (
    <Modal visible animationType="slide" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', paddingTop: insets.top + spacing.md, paddingHorizontal: spacing.lg, paddingBottom: spacing.md, backgroundColor: colors.surface, borderBottomWidth: 1, borderBottomColor: colors.border }}>
          <Pressable onPress={onClose} accessibilityRole="button" accessibilityLabel="Close" style={{ width: 40, height: 40, marginLeft: -8, alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name="arrow-back" size={24} color={colors.textPrimary} />
          </Pressable>
          <View style={{ flex: 1, marginLeft: spacing.sm }}>
            <Text style={[typography.h1, { color: colors.textPrimary }]}>Photo</Text>
            <Text style={[typography.caption, { color: colors.textSecondary }]}>{index === 0 ? 'First photo on your business page' : `Photo ${index + 1} of ${total}`}</Text>
          </View>
        </View>
        <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + spacing.xl }}>
          {uri ? <Image source={{ uri }} style={{ width, height: width, backgroundColor: colors.surfaceAlt }} resizeMode="cover" /> : null}
          <View style={{ padding: spacing.lg, gap: spacing.md }}>
            <Text style={[typography.caption, { color: colors.textSecondary }]}>Customers see this photo on your business page.</Text>
            <View style={{ flexDirection: 'row', gap: spacing.sm }}>
              <View style={{ flex: 1 }}><Button label="Replace" icon="pencil" size="sm" variant="outline" disabled={busy} onPress={onReplace} /></View>
              {index > 0 ? <View style={{ flex: 1 }}><Button label="Make first" icon="arrow-up" size="sm" variant="outline" disabled={busy} onPress={onMakeFirst} /></View> : null}
            </View>
            <Button label="Delete photo" icon="trash-outline" size="sm" variant="destructive-outline" disabled={busy} onPress={onDelete} />
          </View>
        </ScrollView>
        {children}
      </View>
    </Modal>
  );
}
