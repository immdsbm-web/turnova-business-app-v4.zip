import React, { useState } from 'react';
import { Text, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Avatar } from '@/src/components/Avatar';
import { Button } from '@/src/components/Button';
import { Card } from '@/src/components/Card';
import { ConfirmSheet } from '@/src/components/ConfirmSheet';
import { ErrorState } from '@/src/components/ErrorState';
import { formatShort } from '@/src/components/DateStrip';
import { LoadingState } from '@/src/components/LoadingState';
import { Screen } from '@/src/components/Screen';
import { StatusBadge } from '@/src/components/StatusBadge';
import { useTheme } from '@/src/theme';
import { deleteStaff, fetchStaff, toggleStaffActive } from '@/src/api/business';
import { useAction } from '@/src/features/common/useAction';
import { useSession } from '@/src/auth/session';
import { formatTime12, truthy } from '@/src/utils/format';

/** One staff member: every detail from the old list card, plus Edit, Activate / Deactivate and Delete. */
export default function StaffDetailScreen() {
  const { colors, typography, spacing } = useTheme();
  const router = useRouter();
  const qc = useQueryClient();
  const { busy, run } = useAction();
  const { id } = useLocalSearchParams<{ id: string }>();
  const query = useQuery({ queryKey: ['staff'], queryFn: fetchStaff });
  const [deleting, setDeleting] = useState(false);

  const s = (query.data?.staff ?? []).find((x) => x.id === Number(id));
  const reload = () => {
    qc.invalidateQueries({ queryKey: ['staff'] });
    useSession.getState().refreshMe().catch(() => undefined);
  };

  if (query.isLoading) return <Screen title="Staff profile" back><LoadingState /></Screen>;
  if (!s) {
    return (
      <Screen title="Staff profile" back>
        <ErrorState message={query.isError ? "Couldn't load this staff member." : 'This staff member no longer exists.'} onRetry={() => query.refetch()} />
      </Screen>
    );
  }

  const Row = ({ label, value }: { label: string; value: string }) => (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 10, gap: spacing.md }}>
      <Text style={[typography.body, { color: colors.textSecondary }]}>{label}</Text>
      <Text style={[typography.bodyStrong, { color: colors.textPrimary, flex: 1, textAlign: 'right' }]}>{value}</Text>
    </View>
  );
  const Sep = () => <View style={{ height: 1, backgroundColor: colors.border }} />;

  const rows: Array<[string, string]> = [];
  if (s.email) rows.push(['Email', s.email]);
  if (s.phone) rows.push(['Phone', s.phone]);
  if (s.working_hours_start) rows.push(['Working hours', `${formatTime12(s.working_hours_start)} – ${formatTime12(s.working_hours_end)}`]);
  if (truthy(s.is_on_leave)) rows.push(['Today', 'On leave']);
  if ((s.services ?? []).length > 0) rows.push(['Services', (s.services ?? []).map((x) => x.name).join(', ')]);
  if ((s.upcoming_leaves ?? []).length > 0) rows.push(['Upcoming leave', (s.upcoming_leaves ?? []).map((l) => formatShort(l.leave_date)).join(', ')]);

  return (
    <Screen title="Staff profile" back>
      <View style={{ gap: spacing.lg }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
          <Avatar uri={s.photo_url} name={s.name} size={64} />
          <View style={{ flex: 1, gap: 6 }}>
            <Text style={[typography.h2, { color: colors.textPrimary }]} numberOfLines={1}>{s.name}</Text>
            <Text style={[typography.caption, { color: colors.textSecondary }]} numberOfLines={1}>{s.role ?? 'Staff'}</Text>
            <View style={{ flexDirection: 'row' }}>
              {truthy(s.is_active) ? <StatusBadge status="active" label="Active" /> : <StatusBadge status="skipped" label="Inactive" />}
            </View>
          </View>
        </View>

        {rows.length > 0 ? (
          <Card padded={false} style={{ paddingHorizontal: spacing.lg }}>
            {rows.map(([l, v], i) => (
              <React.Fragment key={l}>
                {i > 0 ? <Sep /> : null}
                <Row label={l} value={v} />
              </React.Fragment>
            ))}
          </Card>
        ) : null}

        <Button label="Edit" variant="outline" onPress={() => router.push({ pathname: '/more/staff-form', params: { id: String(s.id) } })} />
        <Button label={truthy(s.is_active) ? 'Deactivate' : 'Activate'} variant="outline" disabled={busy} onPress={() => run(() => toggleStaffActive(s.id)).then(reload)} />
        <Button label="Delete" variant="destructive-outline" onPress={() => setDeleting(true)} />
      </View>

      <ConfirmSheet
        visible={deleting}
        title="Delete this staff member?"
        message={`${s.name} will be removed and can no longer sign in.`}
        confirmLabel="Delete"
        destructive
        loading={busy}
        onConfirm={async () => {
          const ok = await run(() => deleteStaff(s.id));
          if (ok) { setDeleting(false); reload(); router.back(); }
        }}
        onClose={() => setDeleting(false)}
      />
    </Screen>
  );
}
