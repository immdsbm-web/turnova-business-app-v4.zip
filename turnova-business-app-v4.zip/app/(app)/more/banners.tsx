import React, { useEffect, useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { BannerPreview } from '@/src/components/BannerPreview';
import { Button } from '@/src/components/Button';
import { Card } from '@/src/components/Card';
import { ConfirmSheet } from '@/src/components/ConfirmSheet';
import { ErrorState } from '@/src/components/ErrorState';
import { LoadingState } from '@/src/components/LoadingState';
import { PhotoSheet } from '@/src/components/PhotoSheet';
import { Screen } from '@/src/components/Screen';
import { TextField } from '@/src/components/TextField';
import { Notice, SectionTitle } from '@/src/components/Ui';
import { useToast } from '@/src/components/Toast';
import { useTheme } from '@/src/theme';
import { useSession } from '@/src/auth/session';
import { ApiError } from '@/src/api/types';
import { deleteBanner, fetchBanner, Picked, saveBanner } from '@/src/api/business';
import { resolveImageUrl } from '@/src/utils/media';

/** Banner crop frame: the business page ratio. The crop is done once, in the same system editor as profile photos. */
const BANNER_ASPECT: [number, number] = [19, 10];

/** Banner: ONE image per business (every plan), shown on the business page and home list in the customer app. */
export default function BannersScreen() {
  const { colors, typography, spacing, radii } = useTheme();
  const qc = useQueryClient();
  const toast = useToast();
  const businessName = useSession((s) => s.me?.business.name) ?? 'Your business';
  const query = useQuery({ queryKey: ['banner'], queryFn: fetchBanner, staleTime: 0 });
  const saved = query.data?.banner ?? null;

  const [picked, setPicked] = useState<Picked | null>(null);
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [zoom, setZoom] = useState(1);
  const [x, setX] = useState(50);
  const [y, setY] = useState(50);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [sheetOpen, setSheetOpen] = useState(false);

  // Load the saved banner into the editor whenever it changes.
  useEffect(() => {
    if (query.data) {
      setPicked(null);
      setTitle(saved?.title ?? '');
      setSubtitle(saved?.subtitle ?? '');
      setZoom(saved ? Number(saved.zoom) || 1 : 1);
      setX(saved ? Number(saved.x) : 50);
      setY(saved ? Number(saved.y) : 50);
    }
  }, [query.data, saved?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const uri = picked?.uri ?? resolveImageUrl(saved?.image_url ?? null);
  const dirty = !!picked || (saved ? title !== (saved.title ?? '') || subtitle !== (saved.subtitle ?? '') : false);

  const onPicked = (p: Picked) => {
    setError(null);
    if (p.mime && !['image/jpeg', 'image/png', 'image/webp'].includes(p.mime.toLowerCase())) {
      setError('Please choose a JPG, PNG or WebP image.');
      return;
    }
    setPicked(p);
    // The photo is already cropped, so it is shown as-is: no zoom, centred.
    setZoom(1); setX(50); setY(50);
  };
  const choose = () => { setError(null); setSheetOpen(true); };

  const save = async () => {
    if (!uri) { setError('Choose a banner image first.'); return; }
    setError(null);
    setSaving(true);
    try {
      const res = await saveBanner({ title: title.trim(), subtitle: subtitle.trim(), zoom, x, y }, picked);
      qc.setQueryData(['banner'], { banner: res.banner });
      toast.show(res.message || 'Banner saved.', 'success');
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Could not save the banner. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const remove = async () => {
    setDeleting(true);
    try {
      const res = await deleteBanner();
      qc.setQueryData(['banner'], { banner: null });
      setConfirmDelete(false);
      toast.show(res.message || 'Banner removed.', 'success');
    } catch (e) {
      setConfirmDelete(false);
      setError(e instanceof ApiError ? e.message : 'Could not remove the banner.');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <Screen title="Banner" subtitle="Shown to customers in the Turnova app" back>
      {query.isLoading ? <LoadingState /> : null}
      {query.isError && !query.data ? <ErrorState message="Couldn't load your banner." onRetry={() => query.refetch()} /> : null}

      {query.data ? (
        <>
          <Notice tone="info" icon="image-outline">One banner per business. JPG, PNG or WebP, up to 5 MB. You crop the image right after choosing it.</Notice>
          {error ? <Notice tone="danger">{error}</Notice> : null}

          <SectionTitle>{uri ? 'Preview' : 'Add your banner'}</SectionTitle>
          {uri ? (
            <>
              <Text style={[typography.caption, { color: colors.textSecondary }]}>Business page</Text>
              <BannerPreview uri={uri} title={title} subtitle={subtitle} zoom={zoom} x={x} y={y} ratio={1.9} />
              <Text style={[typography.caption, { color: colors.textSecondary }]}>Home list</Text>
              <Card padded={false}>
                <BannerPreview uri={uri} title={title} subtitle={subtitle} zoom={zoom} x={x} y={y} ratio={2.8} radius={0} />
                <View style={{ padding: spacing.md }}>
                  <Text style={[typography.titleSmall, { color: colors.textPrimary }]} numberOfLines={1}>{businessName}</Text>
                  <Text style={[typography.caption, { color: colors.textSecondary }]}>How it appears in the home list</Text>
                </View>
              </Card>
            </>
          ) : (
            <Pressable onPress={choose} accessibilityRole="button" accessibilityLabel="Choose banner image"
              style={{ height: 150, borderRadius: radii.card, borderWidth: 1.5, borderStyle: 'dashed', borderColor: colors.primaryBorder, backgroundColor: colors.primaryContainer, alignItems: 'center', justifyContent: 'center', gap: 8 }}>
              <Ionicons name="cloud-upload-outline" size={30} color={colors.primary} />
              <Text style={[typography.bodyStrong, { color: colors.primary }]}>Choose banner image</Text>
            </Pressable>
          )}

          {uri ? (
            <>
              <Button label="Change image" variant="outline" icon="image-outline" onPress={choose} />

              <SectionTitle>Text</SectionTitle>
              <TextField label="Title (optional)" value={title} onChangeText={(t) => setTitle(t.slice(0, 60))} maxLength={60} />
              <TextField label="Subtitle (optional)" value={subtitle} onChangeText={(t) => setSubtitle(t.slice(0, 120))} maxLength={120} />
            </>
          ) : null}

          <Button label={saved ? 'Save changes' : 'Save banner'} loading={saving} disabled={!uri || (!!saved && !dirty)} onPress={save} />
          {saved ? <Button label="Remove banner" variant="destructive-outline" icon="trash-outline" onPress={() => setConfirmDelete(true)} /> : null}
        </>
      ) : null}

      <PhotoSheet visible={sheetOpen} onClose={() => setSheetOpen(false)} aspect={BANNER_ASPECT} onPicked={onPicked} />

      <ConfirmSheet visible={confirmDelete} title="Remove this banner?" message="Customers will stop seeing it." confirmLabel="Remove" destructive loading={deleting} onConfirm={remove} onClose={() => setConfirmDelete(false)} />
    </Screen>
  );
}
