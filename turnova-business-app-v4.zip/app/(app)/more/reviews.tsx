import React, { useState } from 'react';
import { View } from 'react-native';
import { useInfiniteQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/src/components/Button';
import { ActionSheet } from '@/src/components/ActionSheet';
import { ListRow } from '@/src/components/ListRow';
import { EmptyState } from '@/src/components/EmptyState';
import { ErrorState } from '@/src/components/ErrorState';
import { LoadingState } from '@/src/components/LoadingState';
import { Screen } from '@/src/components/Screen';
import { fetchReviews, setReviewHidden } from '@/src/api/business';
import { ReviewRow } from '@/src/api/types';
import { useAction } from '@/src/features/common/useAction';
import { formatDateLong, truthy } from '@/src/utils/format';

export default function ReviewsScreen() {
  const qc = useQueryClient();
  const { busy, run } = useAction();
  const [picked, setPicked] = useState<ReviewRow | null>(null);

  const query = useInfiniteQuery({
    queryKey: ['reviews'],
    initialPageParam: 1,
    queryFn: ({ pageParam }) => fetchReviews(pageParam),
    getNextPageParam: (last) => (last.result.page < last.result.total_pages ? last.result.page + 1 : undefined),
  });

  const first = query.data?.pages[0]?.result;
  const rows = query.data?.pages.flatMap((p) => p.result.rows) ?? [];
  const average = first?.average_rating;

  return (
    <Screen
      title="Reviews"
      subtitle={first ? `${first.review_count} review${Number(first.review_count) === 1 ? '' : 's'}${average != null ? ` · ${Number(average).toFixed(1)} ★ average` : ''}` : undefined}
      back
      refreshing={query.isRefetching && !query.isFetchingNextPage}
      onRefresh={() => query.refetch()}
    >
      {query.isLoading ? <LoadingState /> : null}
      {query.isError && rows.length === 0 ? <ErrorState message="Couldn't load reviews." onRetry={() => query.refetch()} /> : null}
      {query.data && rows.length === 0 ? <EmptyState icon="star-outline" title="No reviews yet" subtitle="Customer reviews will show up here." /> : null}

      <View>
        {rows.map((r, i) => (
          <ListRow
            key={r.id}
            name={r.user_name ?? 'Customer'}
            title={r.user_name ?? 'Customer'}
            status={truthy(r.is_hidden) ? 'skipped' : undefined}
            statusLabel="Hidden"
            lines={[`${'★'.repeat(Math.round(Number(r.rating)))}${'☆'.repeat(5 - Math.round(Number(r.rating)))} · ${formatDateLong(r.created_at)}`, r.comment]}
            last={i === rows.length - 1}
            onPress={() => setPicked(r)}
          />
        ))}
      </View>

      <ActionSheet
        visible={picked !== null}
        title={picked?.user_name ?? 'Customer'}
        subtitle={picked?.comment ?? undefined}
        onClose={() => setPicked(null)}
        actions={picked ? [{
          label: truthy(picked.is_hidden) ? 'Show review' : 'Hide review',
          destructive: !truthy(picked.is_hidden),
          disabled: busy,
          onPress: () => run(() => setReviewHidden(picked.id, !truthy(picked.is_hidden))).then(() => qc.invalidateQueries({ queryKey: ['reviews'] })),
        }] : []}
      />

      {query.hasNextPage ? <Button label="Load more" variant="outline" loading={query.isFetchingNextPage} onPress={() => query.fetchNextPage()} /> : null}
    </Screen>
  );
}
