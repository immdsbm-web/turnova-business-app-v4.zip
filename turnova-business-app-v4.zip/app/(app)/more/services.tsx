import React, { useState } from 'react';
import { Text, View } from 'react-native';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/src/components/Button';
import { ActionSheet } from '@/src/components/ActionSheet';
import { ListRow } from '@/src/components/ListRow';
import { ConfirmSheet } from '@/src/components/ConfirmSheet';
import { BottomSheet } from '@/src/components/BottomSheet';
import { EmptyState } from '@/src/components/EmptyState';
import { ErrorState } from '@/src/components/ErrorState';
import { LoadingState } from '@/src/components/LoadingState';
import { Screen } from '@/src/components/Screen';
import { StatusBadge } from '@/src/components/StatusBadge';
import { TextField } from '@/src/components/TextField';
import { useTheme } from '@/src/theme';
import { deleteService, fetchServices, saveService, toggleServicePause } from '@/src/api/business';
import { ApiError, ServiceRow } from '@/src/api/types';
import { useAction } from '@/src/features/common/useAction';
import { formatDuration, rupees, truthy } from '@/src/utils/format';

export default function ServicesScreen() {
  const { colors, typography, spacing } = useTheme();
  const qc = useQueryClient();
  const { busy, run } = useAction();
  const query = useQuery({ queryKey: ['services'], queryFn: fetchServices });
  const services = query.data?.services ?? [];

  const [editing, setEditing] = useState<ServiceRow | 'new' | null>(null);
  const [form, setForm] = useState({ name: '', duration_minutes: '30', price: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [deleting, setDeleting] = useState<ServiceRow | null>(null);
  const [picked, setPicked] = useState<ServiceRow | null>(null);

  const reload = () => qc.invalidateQueries({ queryKey: ['services'] });

  const openForm = (s: ServiceRow | 'new') => {
    setErrors({});
    setForm(s === 'new' ? { name: '', duration_minutes: '30', price: '' } : { name: s.name, duration_minutes: String(s.duration_minutes), price: String(Number(s.price)) });
    setEditing(s);
  };

  const submit = async () => {
    setErrors({});
    const id = editing && editing !== 'new' ? editing.id : null;
    try {
      await saveService(id, form);
      setEditing(null);
      reload();
    } catch (e) {
      if (e instanceof ApiError && e.code === 'VALIDATION_ERROR') setErrors(e.details as Record<string, string>);
      else setErrors({ name: e instanceof ApiError ? e.message : 'Could not save the service.' });
    }
  };

  return (
    <Screen title="Services" subtitle={`${services.length} service${services.length === 1 ? '' : 's'}`} back refreshing={query.isRefetching} onRefresh={() => query.refetch()}>
      <Button label="Add service" icon="add-outline" onPress={() => openForm('new')} />
      {query.isLoading ? <LoadingState /> : null}
      {query.isError && !query.data ? <ErrorState message="Couldn't load services." onRetry={() => query.refetch()} /> : null}
      {query.data && services.length === 0 ? <EmptyState icon="cut-outline" title="No services yet" subtitle="Add the services customers can book." /> : null}

      <View>
        {services.map((s, i) => (
          <ListRow
            key={s.id}
            name={s.name}
            title={s.name}
            status={truthy(s.is_paused) ? 'skipped' : 'active'}
            statusLabel={truthy(s.is_paused) ? 'Paused' : 'Live'}
            lines={[`${formatDuration(s.duration_minutes)} · ${rupees(s.price)}`]}
            last={i === services.length - 1}
            onPress={() => setPicked(s)}
          />
        ))}
      </View>

      <ActionSheet
        visible={picked !== null}
        title={picked?.name}
        onClose={() => setPicked(null)}
        actions={picked ? [
          { label: 'Edit', onPress: () => openForm(picked) },
          { label: truthy(picked.is_paused) ? 'Resume' : 'Pause', disabled: busy, onPress: () => run(() => toggleServicePause(picked.id)).then(reload) },
          { label: 'Delete', destructive: true, onPress: () => setDeleting(picked) },
        ] : []}
      />

      <BottomSheet visible={editing !== null} onClose={() => setEditing(null)}>
        <View style={{ padding: spacing.xl, gap: spacing.md }}>
          <Text style={[typography.h2, { color: colors.textPrimary }]}>{editing === 'new' ? 'Add service' : 'Edit service'}</Text>
          <TextField label="Name" value={form.name} onChangeText={(v) => setForm((f) => ({ ...f, name: v }))} error={errors.name} />
          <TextField label="Duration (minutes, 5 to 480)" value={form.duration_minutes} onChangeText={(v) => setForm((f) => ({ ...f, duration_minutes: v.replace(/\D/g, '').slice(0, 3) }))} keyboardType="number-pad" error={errors.duration_minutes} />
          <TextField label="Price (₹)" value={form.price} onChangeText={(v) => setForm((f) => ({ ...f, price: v.replace(/[^0-9.]/g, '') }))} keyboardType="decimal-pad" error={errors.price} />
          <Button label="Save" onPress={submit} />
          <Button label="Cancel" variant="outline" onPress={() => setEditing(null)} />
        </View>
      </BottomSheet>

      <ConfirmSheet
        visible={deleting !== null}
        title="Delete this service?"
        message={deleting ? `"${deleting.name}" will be removed from your business.` : undefined}
        confirmLabel="Delete"
        destructive
        loading={busy}
        onConfirm={async () => {
          if (!deleting) return;
          const ok = await run(() => deleteService(deleting.id));
          if (ok) { setDeleting(null); reload(); }
        }}
        onClose={() => setDeleting(null)}
      />
    </Screen>
  );
}
