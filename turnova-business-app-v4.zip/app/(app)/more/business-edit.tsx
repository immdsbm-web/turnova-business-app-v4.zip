import React, { useEffect, useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/src/components/Button';
import { LocationPicker } from '@/src/components/LocationPicker';
import { ChipRow } from '@/src/components/ChipRow';
import { ErrorState } from '@/src/components/ErrorState';
import { LoadingState } from '@/src/components/LoadingState';
import { ProfileHeader } from '@/src/components/ProfileHeader';
import type { PickedPhoto } from '@/src/components/PhotoSheet';
import { resolveImageUrl } from '@/src/utils/media';
import { Screen } from '@/src/components/Screen';
import { TextField } from '@/src/components/TextField';
import { TimeField } from '@/src/components/TimeField';
import { Notice, SectionTitle } from '@/src/components/Ui';
import { useTheme } from '@/src/theme';
import { fetchBusinessProfile, saveBusinessProfile } from '@/src/api/business';
import { ApiError } from '@/src/api/types';
import { useToast } from '@/src/components/Toast';
import { useSession } from '@/src/auth/session';
import { DAYS } from '@/src/utils/days';
import { isValidIndianMobile, stripToDigits } from '@/src/utils/phone';

const hhmm = (t: string | null | undefined) => (t ? t.slice(0, 5) : '');

export default function BusinessEditScreen() {
  const { colors, typography, spacing } = useTheme();
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const query = useQuery({ queryKey: ['business-profile'], queryFn: fetchBusinessProfile });
  const data = query.data;

  const [form, setForm] = useState({
    business_name: '', category_id: '', address: '', city: '', district: '', state: '',
    open_time: '', close_time: '', cancellation_cutoff_hours: '2',
    whatsapp_number: '',
    facebook_url: '', instagram_url: '', youtube_url: '', linkedin_url: '', x_url: '',
  });
  const [days, setDays] = useState<string[]>([]);
  const [lat, setLat] = useState('');
  const [lng, setLng] = useState('');
  const [logo, setLogo] = useState<PickedPhoto | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const b = data?.business;
    if (!b) return;
    setForm({
      business_name: b.name ?? '', category_id: b.category_id != null ? String(b.category_id) : '', address: b.address ?? '', city: b.city ?? '',
      district: b.district ?? '', state: b.state ?? '', open_time: hhmm(b.working_hours_start), close_time: hhmm(b.working_hours_end),
      cancellation_cutoff_hours: String(b.cancellation_cutoff_hours ?? 2),
      whatsapp_number: b.whatsapp_local ?? '',
      facebook_url: b.facebook_url ?? '', instagram_url: b.instagram_url ?? '', youtube_url: b.youtube_url ?? '',
      linkedin_url: b.linkedin_url ?? '', x_url: b.x_url ?? '',
    });
    setDays(b.days ?? []);
    setLat(b.lat != null ? String(b.lat) : '');
    setLng(b.lng != null ? String(b.lng) : '');
  }, [data?.business]);

  const set = (key: keyof typeof form) => (v: string) => setForm((f) => ({ ...f, [key]: v }));

  const submit = async () => {
    // WhatsApp is optional; if something is typed it must be a valid 10-digit mobile number (+91 is fixed).
    if (form.whatsapp_number !== '' && !isValidIndianMobile(form.whatsapp_number)) {
      setErrors({ whatsapp_number: 'Enter a valid 10-digit WhatsApp number (without +91).' });
      return;
    }
    setSaving(true);
    setErrors({});
    try {
      await saveBusinessProfile({ ...form, days, lat, lng }, logo);
      qc.invalidateQueries({ queryKey: ['business-profile'] });
      qc.invalidateQueries({ queryKey: ['dashboard'] });
      useSession.getState().refreshMe().catch(() => undefined);
      toast.show('Business details updated.', 'success');
      router.back();
    } catch (e) {
      if (e instanceof ApiError && e.code === 'VALIDATION_ERROR') setErrors(e.details as Record<string, string>);
      else if (e instanceof ApiError) toast.show(e.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  const ownerName = useSession((st) => st.me?.account.name) ?? '';
  const logoUri = logo?.uri ?? resolveImageUrl(data?.business.logo_url ?? null);

  return (
    <Screen
      title="Edit business"
      back
      footer={data ? <Button label="Save changes" loading={saving} onPress={submit} /> : undefined}
    >
      {query.isLoading ? <LoadingState /> : null}
      {query.isError && !data ? <ErrorState message="Couldn't load your business." onRetry={() => query.refetch()} /> : null}

      {data ? (
        <>
          {Object.keys(errors).length > 0 ? <Notice tone="danger">Please fix the highlighted fields.</Notice> : null}

          {/* Same header as the Customer App's Edit Profile: the picture is the business logo; the owner sits under the business name. */}
          <ProfileHeader
            uri={logoUri}
            initialName={form.business_name}
            title={form.business_name.trim() || 'Your business'}
            subtitle={ownerName ? `${ownerName} · Owner` : 'Owner'}
            photoLabel="business logo"
            onPicked={setLogo}
          />
          {errors.logo ? <Text style={[typography.caption, { color: colors.danger }]}>{errors.logo}</Text> : null}

          <TextField label="Business name" value={form.business_name} onChangeText={set('business_name')} error={errors.business_name} />
          <Text style={[typography.caption, { color: colors.textSecondary, fontFamily: 'Inter_600SemiBold' }]}>Category</Text>
          <ChipRow items={data.categories.map((c) => ({ value: String(c.id), label: c.name }))} selected={form.category_id} onSelect={set('category_id')} />
          {errors.category_id ? <Text style={[typography.caption, { color: colors.danger }]}>{errors.category_id}</Text> : null}
          <TextField label="Address" value={form.address} onChangeText={set('address')} error={errors.address} />
          <TextField label="City" value={form.city} onChangeText={set('city')} error={errors.city} />
          <TextField label="District" value={form.district} onChangeText={set('district')} />
          <TextField label="State" value={form.state} onChangeText={set('state')} />
          <TextField
            label="WhatsApp number (optional)"
            prefix="+91"
            value={form.whatsapp_number}
            onChangeText={(t) => set('whatsapp_number')(stripToDigits(t).slice(0, 10))}
            keyboardType="number-pad"
            placeholder="10-digit number"
            error={errors.whatsapp_number}
          />
          <Text style={[typography.caption, { color: colors.textSecondary, marginTop: -8 }]}>
            Shown on your business page. Leave empty to hide.
          </Text>

          <SectionTitle>Social media links (optional)</SectionTitle>
          <Text style={[typography.caption, { color: colors.textSecondary, marginTop: -8 }]}>
            Paste the full link (https://). Empty fields stay hidden.
          </Text>
          {([
            ['facebook_url', 'Facebook', 'https://facebook.com/yourpage'],
            ['instagram_url', 'Instagram', 'https://instagram.com/yourpage'],
            ['youtube_url', 'YouTube', 'https://youtube.com/@yourchannel'],
            ['linkedin_url', 'LinkedIn', 'https://linkedin.com/company/yourpage'],
            ['x_url', 'X', 'https://x.com/yourpage'],
          ] as const).map(([key, label, example]) => (
            <TextField
              key={key}
              label={label}
              value={form[key]}
              onChangeText={set(key)}
              keyboardType="url"
              autoCapitalize="none"
              autoCorrect={false}
              placeholder={example}
              error={errors[key]}
            />
          ))}

          <SectionTitle>Location</SectionTitle>
          <LocationPicker
            initialLat={data.business.lat != null ? String(data.business.lat) : ''}
            initialLng={data.business.lng != null ? String(data.business.lng) : ''}
            onChange={(la, ln) => { setLat(la); setLng(ln); }}
            error={errors.location}
          />

          <SectionTitle>Opening hours</SectionTitle>
          <TimeField label="Opens" value={form.open_time} onChange={set('open_time')} />
          <TimeField label="Closes" value={form.close_time} onChange={set('close_time')} />
          {errors.hours ? <Text style={[typography.caption, { color: colors.danger }]}>{errors.hours}</Text> : null}
          <Text style={[typography.caption, { color: colors.textSecondary, fontFamily: 'Inter_600SemiBold' }]}>Operating days</Text>
          <ChipRow
            items={DAYS}
            selected=""
            isSelected={(v) => days.includes(v)}
            onSelect={(v) => setDays((d) => (d.includes(v) ? d.filter((x) => x !== v) : [...d, v]))}
          />
          {errors.days ? <Text style={[typography.caption, { color: colors.danger }]}>{errors.days}</Text> : null}

          <TextField
            label="Cancellation cutoff (hours before opening)"
            value={form.cancellation_cutoff_hours}
            onChangeText={(v) => set('cancellation_cutoff_hours')(v.replace(/\D/g, ''))}
            keyboardType="number-pad"
            error={errors.cancellation_cutoff_hours}
          />
        </>
      ) : null}
    </Screen>
  );
}
