import React, { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/src/components/Button';
import { CalendarSheet } from '@/src/components/CalendarSheet';
import { Card } from '@/src/components/Card';
import { ActionSheet } from '@/src/components/ActionSheet';
import { ListRow } from '@/src/components/ListRow';
import { UnderlineTabs } from '@/src/components/UnderlineTabs';
import { ChipRow } from '@/src/components/ChipRow';
import { EmptyState } from '@/src/components/EmptyState';
import { ErrorState } from '@/src/components/ErrorState';
import { formatYmd, toYmd } from '@/src/components/DateStrip';
import { LoadingState } from '@/src/components/LoadingState';
import { Screen } from '@/src/components/Screen';
import { TextField } from '@/src/components/TextField';
import { useToast } from '@/src/components/Toast';
import { IconTile, SectionTitle } from '@/src/components/Ui';
import { useTheme } from '@/src/theme';
import { addHoliday, addStaffLeave, fetchDatesCapacity, fetchStaff, removeHoliday, removeStaffLeave } from '@/src/api/business';
import { ApiError } from '@/src/api/types';
import { useAction } from '@/src/features/common/useAction';

type Tab = 'biz' | 'leave';

/** Holiday: business-wide holidays and per-staff leave, in two tabs. Moved here from Dates & Breaks and Edit Staff. */
export default function HolidayScreen() {
  const { colors, typography, spacing, radii } = useTheme();
  const qc = useQueryClient();
  const toast = useToast();
  const { busy, run } = useAction();
  const [tab, setTab] = useState<Tab>('biz');
  const [holDate, setHolDate] = useState(toYmd(new Date()));
  const [reason, setReason] = useState('');
  const [leaveStaffId, setLeaveStaffId] = useState(0);
  const [leaveDate, setLeaveDate] = useState(toYmd(new Date()));
  const [calendar, setCalendar] = useState<null | 'biz' | 'leave'>(null);
  const [pickedHoliday, setPickedHoliday] = useState<{ id: number; date: string; reason?: string | null } | null>(null);
  const [pickedLeave, setPickedLeave] = useState<string | null>(null);

  const dates = useQuery({ queryKey: ['dates-capacity'], queryFn: () => fetchDatesCapacity() });
  const staffQ = useQuery({ queryKey: ['staff'], queryFn: fetchStaff });
  const holidays = [...(dates.data?.holidays ?? [])].sort((a, b) => a.date.localeCompare(b.date));
  const staff = staffQ.data?.staff ?? [];
  const selected = staff.find((s) => s.id === leaveStaffId) ?? staff[0];
  const leaves = [...(selected?.upcoming_leaves ?? [])].map((l) => l.leave_date).sort();

  const reloadHolidays = () => qc.invalidateQueries({ queryKey: ['dates-capacity'] });
  const reloadStaff = () => {
    qc.invalidateQueries({ queryKey: ['staff'] });
    qc.invalidateQueries({ queryKey: ['staff-form'] });
    qc.invalidateQueries({ queryKey: ['dashboard'] });
    qc.invalidateQueries({ queryKey: ['bookings'] });
  };

  const DateButton = ({ value, onPress }: { value: string; onPress: () => void }) => (
    <View style={{ gap: 6 }}>
      <Text style={[typography.caption, { color: colors.textSecondary, fontFamily: 'Inter_600SemiBold' }]}>Date</Text>
      <Pressable
        onPress={onPress}
        accessibilityRole="button"
        accessibilityLabel={`Date: ${formatYmd(value)}`}
        style={{ minHeight: 52, flexDirection: 'row', alignItems: 'center', gap: spacing.sm, borderWidth: 1, borderColor: colors.border, borderRadius: radii.input, backgroundColor: colors.surface, paddingHorizontal: spacing.md }}
      >
        <Ionicons name="calendar-outline" size={18} color={colors.textSecondary} />
        <Text style={[typography.body, { color: colors.textPrimary, flex: 1 }]}>{formatYmd(value)}</Text>
        <Ionicons name="chevron-down" size={16} color={colors.textMuted} />
      </Pressable>
    </View>
  );

  const markLeave = async () => {
    if (!selected) return;
    if (leaves.includes(leaveDate)) { toast.show('Already on leave that day.', 'error'); return; }
    const ok = await run(() => addStaffLeave(selected.id, leaveDate), 'Marked on leave.');
    if (ok) reloadStaff();
  };

  return (
    <Screen
      title="Holiday"
      subtitle="Business holidays and staff leave"
      back
      refreshing={dates.isRefetching || staffQ.isRefetching}
      onRefresh={() => { dates.refetch(); staffQ.refetch(); }}
    >
      <UnderlineTabs
        value={tab}
        onChange={setTab}
        items={[{ value: 'biz', label: 'Business Holidays' }, { value: 'leave', label: 'Staff Leave' }]}
      />

      {tab === 'biz' ? (
        <>
          {dates.isLoading ? <LoadingState /> : null}
          {dates.isError && !dates.data ? <ErrorState message="Couldn't load holidays." onRetry={() => dates.refetch()} /> : null}
          <Card style={{ gap: spacing.md }}>
            <Text style={[typography.titleSmall, { color: colors.textPrimary }]}>Add a business holiday</Text>
            <Text style={[typography.caption, { color: colors.textSecondary }]}>Customers cannot book any staff member on a holiday.</Text>
            <DateButton value={holDate} onPress={() => setCalendar('biz')} />
            <TextField label="Reason (optional)" value={reason} onChangeText={setReason} placeholder="e.g. Diwali" />
            <Button
              label="Add holiday"
              icon="add"
              disabled={busy}
              onPress={async () => {
                if (holidays.some((h) => h.date === holDate)) { toast.show('That date is already a holiday.', 'error'); return; }
                const ok = await run(() => addHoliday(holDate, reason), 'Holiday added.');
                if (ok) { setReason(''); reloadHolidays(); }
              }}
            />
          </Card>

          <SectionTitle>Upcoming holidays</SectionTitle>
          {!dates.isLoading && holidays.length === 0 ? <EmptyState icon="sunny-outline" title="No holidays set" subtitle="Add dates when your business is closed." /> : null}
          <View>
            {holidays.map((h, i) => (
              <ListRow
                key={h.id}
                tile={<IconTile icon="sunny-outline" tone="warning" size={48} />}
                title={formatYmd(h.date)}
                lines={[h.reason]}
                last={i === holidays.length - 1}
                onPress={() => setPickedHoliday(h)}
              />
            ))}
          </View>
        </>
      ) : (
        <>
          {staffQ.isLoading ? <LoadingState /> : null}
          {staffQ.isError && !staffQ.data ? <ErrorState message={staffQ.error instanceof ApiError ? staffQ.error.message : "Couldn't load staff."} onRetry={() => staffQ.refetch()} /> : null}
          {staffQ.data && staff.length === 0 ? <EmptyState icon="people-outline" title="No staff yet" subtitle="Add a staff member first, then mark their leave here." /> : null}
          {selected ? (
            <>
              <ChipRow items={staff.map((s) => ({ value: s.id, label: s.name }))} selected={selected.id} onSelect={setLeaveStaffId} />
              <Card style={{ gap: spacing.md }}>
                <Text style={[typography.titleSmall, { color: colors.textPrimary }]}>Mark {selected.name} on leave</Text>
                <Text style={[typography.caption, { color: colors.textSecondary }]}>Bookings on a leave day are flagged for reassignment.</Text>
                <DateButton value={leaveDate} onPress={() => setCalendar('leave')} />
                <Button label="Mark on leave" icon="calendar-outline" variant="outline" disabled={busy} onPress={markLeave} />
              </Card>

              <SectionTitle>{`${selected.name}'s leave`}</SectionTitle>
              {leaves.length === 0 ? <EmptyState icon="calendar-outline" title="No leave days" subtitle={`${selected.name} has no upcoming leave.`} /> : null}
              <View>
                {leaves.map((d, i) => (
                  <ListRow
                    key={d}
                    tile={<IconTile icon="calendar-outline" tone="danger" size={48} />}
                    title={formatYmd(d)}
                    lines={[`${selected.name} is on leave`]}
                    last={i === leaves.length - 1}
                    onPress={() => setPickedLeave(d)}
                  />
                ))}
              </View>
            </>
          ) : null}
        </>
      )}

      <ActionSheet
        visible={pickedHoliday !== null}
        title={pickedHoliday ? formatYmd(pickedHoliday.date) : undefined}
        subtitle={pickedHoliday?.reason ?? undefined}
        onClose={() => setPickedHoliday(null)}
        actions={pickedHoliday ? [{ label: 'Remove', destructive: true, disabled: busy, onPress: () => run(() => removeHoliday(pickedHoliday.id), 'Holiday removed.').then((ok) => ok && reloadHolidays()) }] : []}
      />
      <ActionSheet
        visible={pickedLeave !== null}
        title={pickedLeave ? formatYmd(pickedLeave) : undefined}
        subtitle={selected ? `${selected.name} is on leave` : undefined}
        onClose={() => setPickedLeave(null)}
        actions={pickedLeave && selected ? [{ label: 'Remove', destructive: true, disabled: busy, onPress: () => run(() => removeStaffLeave(selected.id, pickedLeave), 'Leave removed.').then((ok) => ok && reloadStaff()) }] : []}
      />

      <CalendarSheet
        visible={calendar !== null}
        title={calendar === 'leave' ? 'Leave date' : 'Holiday date'}
        value={calendar === 'leave' ? leaveDate : holDate}
        min={toYmd(new Date())}
        marks={calendar === 'leave' ? leaves : holidays.map((h) => h.date)}
        onClose={() => setCalendar(null)}
        onPick={(y) => (calendar === 'leave' ? setLeaveDate(y) : setHolDate(y))}
      />
    </Screen>
  );
}
