import React, { useEffect, useState } from 'react';
import { Text, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/src/components/Button';
import { ChipRow } from '@/src/components/ChipRow';
import { ErrorState } from '@/src/components/ErrorState';
import { LoadingState } from '@/src/components/LoadingState';
import { ProfileHeader } from '@/src/components/ProfileHeader';
import type { PickedPhoto } from '@/src/components/PhotoSheet';
import { resolveImageUrl } from '@/src/utils/media';
import { Screen } from '@/src/components/Screen';
import { TextField } from '@/src/components/TextField';
import { TimeField } from '@/src/components/TimeField';
import { Notice, SectionTitle } from '@/src/components/Ui';
import { useTheme } from '@/src/theme';
import { fetchStaffForm, saveStaff } from '@/src/api/business';
import { ApiError } from '@/src/api/types';
import { useToast } from '@/src/components/Toast';
import { stripToDigits } from '@/src/utils/phone';

const hhmm = (t: string | null | undefined) => (t ? t.slice(0, 5) : '');

export default function StaffFormScreen() {
  const { colors, typography, spacing } = useTheme();
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const params = useLocalSearchParams<{ id?: string }>();
  const id = Number(params.id ?? 0);
  const editing = id > 0;

  const query = useQuery({ queryKey: ['staff-form', id], queryFn: () => fetchStaffForm(id), retry: false });
  const data = query.data;

  const [form, setForm] = useState({ name: '', role: '', email: '', phone: '', password: '', working_hours_start: '09:00', working_hours_end: '18:00' });
  const [serviceIds, setServiceIds] = useState<string[]>([]);
  const [picked, setPicked] = useState<PickedPhoto | null>(null);
  const [removePhoto, setRemovePhoto] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const s = data?.staff;
    if (s) {
      setForm({
        name: s.name ?? '', role: s.role ?? '', email: s.email ?? '', phone: s.phone ?? '', password: '',
        working_hours_start: hhmm(s.working_hours_start) || '09:00', working_hours_end: hhmm(s.working_hours_end) || '18:00',
      });
      setServiceIds((s.service_ids ?? []).map(String));
    }
  }, [data?.staff]);

  const set = (key: keyof typeof form) => (v: string) => setForm((f) => ({ ...f, [key]: v }));

  const submit = async () => {
    setSaving(true);
    setErrors({});
    try {
      await saveStaff(
        editing ? id : null,
        { ...form, phone: stripToDigits(form.phone), service_ids: serviceIds, remove_photo: removePhoto && !picked ? '1' : '' },
        picked
      );
      qc.invalidateQueries({ queryKey: ['staff'] });
      qc.invalidateQueries({ queryKey: ['staff-form'] });
      toast.show(editing ? 'Staff member updated.' : 'Staff member added.', 'success');
      router.back();
    } catch (e) {
      if (e instanceof ApiError && e.code === 'VALIDATION_ERROR') setErrors(e.details as Record<string, string>);
      else if (e instanceof ApiError) toast.show(e.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  const shownPhoto = picked?.uri ?? (removePhoto ? null : resolveImageUrl(data?.staff?.photo_url ?? null));
  const savedPhone = stripToDigits(form.phone);

  return (
    <Screen
      title={editing ? 'Edit staff member' : 'Add staff member'}
      back
      footer={data ? <Button label={editing ? 'Save changes' : 'Add staff member'} loading={saving} onPress={submit} /> : undefined}
    >
      {query.isLoading ? <LoadingState /> : null}
      {query.isError ? (
        <ErrorState message={query.error instanceof ApiError ? query.error.message : "Couldn't load the form."} onRetry={() => query.refetch()} />
      ) : null}

      {data ? (
        <>
          <ProfileHeader
            uri={shownPhoto}
            initialName={form.name}
            title={form.name.trim() || 'New staff member'}
            subtitle={savedPhone ? `+91 ${savedPhone}` : 'Add a mobile number below'}
            photoLabel="staff photo"
            onPicked={(p) => { setPicked(p); setRemovePhoto(false); }}
            onRemove={() => { setPicked(null); setRemovePhoto(true); }}
          />
          {errors.photo ? <Text style={[typography.caption, { color: colors.danger }]}>{errors.photo}</Text> : null}

          <TextField label="Name" value={form.name} onChangeText={set('name')} error={errors.name} />
          <TextField label="Role (e.g. Barber)" value={form.role} onChangeText={set('role')} />
          <TextField label="Email (their sign-in)" value={form.email} onChangeText={set('email')} autoCapitalize="none" keyboardType="email-address" error={errors.email} />
          <TextField label="Mobile number" prefix="+91" value={form.phone} onChangeText={(t) => set('phone')(stripToDigits(t).slice(0, 10))} keyboardType="number-pad" />
          <TextField
            label={editing ? 'New password (leave empty to keep)' : 'Password'}
            value={form.password}
            onChangeText={set('password')}
            secureTextEntry
            autoCapitalize="none"
            error={errors.password}
          />

          <SectionTitle>Working hours</SectionTitle>
          <TimeField label="Starts" value={form.working_hours_start} onChange={set('working_hours_start')} />
          <TimeField label="Ends" value={form.working_hours_end} onChange={set('working_hours_end')} />

          <SectionTitle>Services they perform</SectionTitle>
          {data.services.length === 0 ? (
            <Notice tone="primary">Add services first (Manage → Services), then assign them here.</Notice>
          ) : (
            <ChipRow
              items={data.services.map((s) => ({ value: String(s.id), label: s.name }))}
              selected=""
              isSelected={(v) => serviceIds.includes(v)}
              onSelect={(v) => setServiceIds((cur) => (cur.includes(v) ? cur.filter((x) => x !== v) : [...cur, v]))}
            />
          )}
        </>
      ) : null}
    </Screen>
  );
}
