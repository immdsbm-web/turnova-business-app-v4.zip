import React from 'react';
import { Redirect, Stack } from 'expo-router';
import { useSession } from '@/src/auth/session';
import { useTheme } from '@/src/theme';
import { slideTransition } from '@/src/navigation/transitions';

/** Owner-only management screens opened from the Manage tab. */
export default function MoreLayout() {
  const role = useSession((s) => s.me?.account.role);
  const { colors } = useTheme();
  if (role !== 'owner') return <Redirect href="/my-queue" />;
  return <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.background }, ...slideTransition }} />;
}
