import React from 'react';
import { Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/src/components/Button';
import { ListRow } from '@/src/components/ListRow';
import { EmptyState } from '@/src/components/EmptyState';
import { ErrorState } from '@/src/components/ErrorState';
import { LoadingState } from '@/src/components/LoadingState';
import { Screen } from '@/src/components/Screen';
import { StatusBadge } from '@/src/components/StatusBadge';
import { Notice } from '@/src/components/Ui';
import { useTheme } from '@/src/theme';
import { fetchStaff } from '@/src/api/business';

export default function StaffScreen() {
  const { colors, typography, spacing } = useTheme();
  const router = useRouter();
  const query = useQuery({ queryKey: ['staff'], queryFn: fetchStaff });

  const staff = query.data?.staff ?? [];
  const usage = query.data?.usage;
  return (
    <Screen
      title="Staff"
      subtitle={usage ? `${staff.length} staff${usage.plan_name ? ` · ${usage.plan_name} plan allows ${usage.max_staff ?? 'unlimited'}` : ''}` : undefined}
      back
      refreshing={query.isRefetching}
      onRefresh={() => query.refetch()}
    >
      {usage?.staff_limit_reached ? (
        <Notice tone="danger">Staff limit reached. Upgrade your plan to add more.</Notice>
      ) : (
        <Button label="Add staff member" icon="person-add-outline" onPress={() => router.push('/more/staff-form')} />
      )}

      {query.isLoading ? <LoadingState /> : null}
      {query.isError && !query.data ? <ErrorState message="Couldn't load staff." onRetry={() => query.refetch()} /> : null}
      {query.data && staff.length === 0 ? <EmptyState icon="people-outline" title="No staff yet" subtitle="Add your first staff member to start taking bookings." /> : null}

      <View>
        {staff.map((s, i) => (
          <ListRow
            key={s.id}
            uri={s.photo_url}
            name={s.name}
            title={s.name}
            lines={[s.role ?? 'Staff']}
            last={i === staff.length - 1}
            onPress={() => router.push({ pathname: '/more/staff-detail', params: { id: String(s.id) } })}
          />
        ))}
      </View>
    </Screen>
  );
}
