import React, { useEffect, useState } from 'react';
import { Text, View } from 'react-native';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/src/components/Button';
import { Card } from '@/src/components/Card';
import { ConfirmSheet } from '@/src/components/ConfirmSheet';
import { ErrorState } from '@/src/components/ErrorState';
import { LoadingState } from '@/src/components/LoadingState';
import { Screen } from '@/src/components/Screen';
import { TextField } from '@/src/components/TextField';
import { TimeField } from '@/src/components/TimeField';
import { SectionTitle } from '@/src/components/Ui';
import { useToast } from '@/src/components/Toast';
import { useTheme } from '@/src/theme';
import { addBreak, deleteBreak, fetchDatesCapacity, saveBreaks, updateBreak } from '@/src/api/business';
import { ApiError } from '@/src/api/types';
import { formatTime12 } from '@/src/utils/format';
import { useAction } from '@/src/features/common/useAction';

/** "Dates & Breaks": several business breaks (booking periods are the working hours between them) and the gap between appointments. Holidays and staff leave live on the Holiday screen. */
export default function DatesCapacityScreen() {
  const { colors, typography, spacing } = useTheme();
  const qc = useQueryClient();
  const { busy, run } = useAction();
  const [gap, setGap] = useState('0');
  const toast = useToast();
  const [breakStart, setBreakStart] = useState('');
  const [breakEnd, setBreakEnd] = useState('');
  const [editingId, setEditingId] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [overlap, setOverlap] = useState<number | null>(null); // upcoming bookings the break would overlap (asks for confirmation)

  const query = useQuery({ queryKey: ['dates-capacity'], queryFn: () => fetchDatesCapacity() });

  // Load the saved break settings into the form whenever fresh data arrives.
  useEffect(() => {
    const b = query.data?.breaks;
    if (!b) return;
    setGap(String(b.break_between_minutes ?? 0));
  }, [query.data]);

  const reload = () => qc.invalidateQueries({ queryKey: ['dates-capacity'] });
  const breaks = query.data?.breaks.items ?? [];

  const resetBreakForm = () => {
    setBreakStart('');
    setBreakEnd('');
    setEditingId(null);
    setOverlap(null);
  };

  // Saves a new/edited break. If it overlaps upcoming bookings the server saves nothing and
  // reports how many; the owner then confirms. Bookings are never cancelled or moved.
  const submitBreak = async (confirm: boolean) => {
    setSaving(true);
    try {
      const res = editingId ? await updateBreak(editingId, breakStart, breakEnd, confirm) : await addBreak(breakStart, breakEnd, confirm);
      if (!res.saved) {
        setOverlap(res.affected_bookings);
        return;
      }
      toast.show(editingId ? 'Break updated.' : 'Break added.', 'success');
      resetBreakForm();
      reload();
    } catch (e) {
      setOverlap(null);
      toast.show(e instanceof ApiError ? e.message : 'Something went wrong. Please try again.', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Screen title="Dates & Breaks" subtitle="Breaks and booking periods" back refreshing={query.isRefetching} onRefresh={() => query.refetch()}>
      {query.isLoading ? <LoadingState /> : null}
      {query.isError && !query.data ? <ErrorState message="Couldn't load the settings." onRetry={() => query.refetch()} /> : null}

      <SectionTitle>Breaks</SectionTitle>
      <Card style={{ gap: spacing.md }}>
        <Text style={[typography.caption, { color: colors.textSecondary }]}>
          Add as many breaks as you need. Customers book the time between them. Example: 9 AM–9 PM with breaks 12–1 and 5–6 gives three periods.
        </Text>
        {breaks.length === 0 && !query.isLoading ? (
          <Text style={[typography.body, { color: colors.textSecondary }]}>No breaks set — each day is one booking period.</Text>
        ) : null}
        {breaks.map((b) => (
          <View key={b.id} style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md }}>
            <Text style={[typography.titleSmall, { color: colors.textPrimary, flex: 1 }]}>{formatTime12(b.start)} – {formatTime12(b.end)}</Text>
            <Button label="Edit" size="sm" variant="outline" style={{ width: 'auto' }} disabled={busy || saving} onPress={() => { setEditingId(b.id); setBreakStart(b.start); setBreakEnd(b.end); }} />
            <Button
              label="Remove"
              size="sm"
              variant="destructive-outline"
              style={{ width: 'auto' }}
              disabled={busy || saving}
              onPress={() => run(() => deleteBreak(b.id), 'Break removed.').then((ok) => { if (ok) { if (editingId === b.id) resetBreakForm(); reload(); } })}
            />
          </View>
        ))}
        <Text style={[typography.bodyStrong, { color: colors.textPrimary }]}>{editingId ? 'Edit break' : 'Add a break'}</Text>
        <TimeField label="Break starts" value={breakStart} onChange={setBreakStart} />
        <TimeField label="Break ends" value={breakEnd} onChange={setBreakEnd} />
        <Button label={editingId ? 'Save break' : 'Add break'} disabled={saving || !breakStart || !breakEnd} loading={saving && overlap === null} onPress={() => submitBreak(false)} />
        {editingId ? <Button label="Cancel" variant="ghost" disabled={saving} onPress={resetBreakForm} /> : null}
      </Card>

      <SectionTitle>Break between appointments</SectionTitle>
      <Card style={{ gap: spacing.md }}>
        <TextField
          label="Minutes"
          value={gap}
          onChangeText={(t) => setGap(t.replace(/\D/g, '').slice(0, 3))}
          keyboardType="number-pad"
          placeholder="0 = no break"
        />
        <Text style={[typography.caption, { color: colors.textMuted }]}>0 = no break. Kept free after every appointment.</Text>
        <Button
          label="Save"
          disabled={busy}
          onPress={() => run(() => saveBreaks(gap), 'Break settings saved.').then((ok) => ok && reload())}
        />
      </Card>

      <ConfirmSheet
        visible={overlap !== null}
        title={`This break overlaps ${overlap ?? 0} booking${overlap === 1 ? '' : 's'}`}
        message={`${overlap ?? 0} appointment${overlap === 1 ? '' : 's'} fall${overlap === 1 ? 's' : ''} inside this break. They stay as they are. Only new bookings are blocked.`}
        confirmLabel="Save the break anyway"
        loading={saving}
        onConfirm={() => submitBreak(true)}
        onClose={() => setOverlap(null)}
      />
    </Screen>
  );
}
