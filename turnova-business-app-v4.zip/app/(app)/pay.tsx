import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Text, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useQueryClient } from '@tanstack/react-query';
import { Button } from '@/src/components/Button';
import { Screen } from '@/src/components/Screen';
import { StatusIcon } from '@/src/components/BrandMark';
import { useTheme } from '@/src/theme';
import { confirmPayment, createUpiOrder } from '@/src/api/business';
import { ApiError } from '@/src/api/types';
import { useSession } from '@/src/auth/session';
import { payWithUpi } from '@/src/features/billing/cashfree';
import { formatDateLong, rupees } from '@/src/utils/format';

type Phase = 'starting' | 'checking' | 'success' | 'pending' | 'failed';

/**
 * One month's payment, straight into the phone's UPI apps.
 *   1. server creates a Cashfree order       (POST /billing/pay method=order)
 *   2. Cashfree SDK opens GPay / PhonePe ... (UPI intent)
 *   3. back in the app, the SERVER asks Cashfree if it is paid (POST /billing/confirm)
 */
export default function PayScreen() {
  const { colors, typography, spacing } = useTheme();
  const router = useRouter();
  const qc = useQueryClient();
  const { planId } = useLocalSearchParams<{ planId?: string }>();
  const id = Number(planId ?? 0);

  const [phase, setPhase] = useState<Phase>('starting');
  const [message, setMessage] = useState<string | null>(null);
  const [amount, setAmount] = useState<number | null>(null);
  const [until, setUntil] = useState<string | null>(null);
  const orderRef = useRef<string | null>(null);
  const started = useRef(false);

  const verify = useCallback(async () => {
    const orderId = orderRef.current;
    if (!orderId) return;
    setPhase('checking');
    try {
      const res = await confirmPayment(orderId);
      if (res.status === 'paid') {
        await useSession.getState().refreshMe().catch(() => undefined);
        qc.invalidateQueries();
        setUntil(res.valid_until);
        setPhase('success');
      } else if (res.status === 'created') {
        setMessage("Awaiting bank confirmation. This can take a few minutes.");
        setPhase('pending');
      } else {
        setMessage(res.status === 'expired' ? 'The payment session expired.' : 'The payment was not completed. You have not been charged.');
        setPhase('failed');
      }
    } catch (e) {
      setMessage(e instanceof ApiError ? e.message : 'Could not check the payment. If money was deducted, your plan will update shortly.');
      setPhase('pending');
    }
  }, [qc]);

  const start = useCallback(async () => {
    setPhase('starting');
    setMessage(null);
    try {
      const order = await createUpiOrder(id);
      orderRef.current = order.order_id;
      setAmount(order.amount);
      const result = await payWithUpi(order);
      if (result.outcome === 'error' && result.message && /Expo Go|installed Turnova/.test(result.message)) {
        setMessage(result.message);
        setPhase('failed');
        return;
      }
      await verify(); // the server decides, whatever the SDK said
    } catch (e) {
      setMessage(e instanceof ApiError ? e.message : 'Could not start the payment. Please try again.');
      setPhase('failed');
    }
  }, [id, verify]);

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    start();
  }, [start]);

  const icon: keyof typeof Ionicons.glyphMap =
    phase === 'success' ? 'checkmark-circle' : phase === 'failed' ? 'close-circle' : phase === 'pending' ? 'time-outline' : 'phone-portrait-outline';
  const tint = phase === 'success' ? colors.success : phase === 'failed' ? colors.danger : colors.primary;
  const title = {
    starting: 'Opening your UPI app…',
    checking: 'Confirming your payment…',
    success: 'Payment successful',
    pending: 'Waiting for confirmation',
    failed: 'Payment not completed',
  }[phase];

  return (
    <Screen title="Pay" back={phase !== 'checking'} scroll>
      <View style={{ alignItems: 'center', gap: spacing.md, marginTop: spacing.xxxl }}>
        <StatusIcon tint={phase === 'success' ? colors.successBg : phase === 'failed' ? colors.dangerBg : colors.primaryContainer}>
          <Ionicons name={icon} size={52} color={tint} />
        </StatusIcon>
        <Text style={[typography.h1, { color: colors.textPrimary, textAlign: 'center' }]}>{title}</Text>
        {amount != null ? <Text style={[typography.titleSmall, { color: colors.textSecondary }]}>{rupees(amount)} · 1 month</Text> : null}
        {phase === 'success' ? (
          <Text style={[typography.body, { color: colors.textSecondary, textAlign: 'center' }]}>
            Your plan is active{until ? ` until ${formatDateLong(until)}` : ''}. Find the receipt in Billing.
          </Text>
        ) : null}
        {phase === 'checking' ? <Text style={[typography.body, { color: colors.textSecondary, textAlign: 'center' }]}>Confirming with your bank. Please keep the app open.</Text> : null}
        {message ? <Text style={[typography.body, { color: colors.textSecondary, textAlign: 'center' }]}>{message}</Text> : null}
      </View>

      {phase === 'success' ? <Button label="Go to Billing" onPress={() => router.replace('/billing')} /> : null}
      {phase === 'pending' ? (
        <>
          <Button label="Check again" icon="refresh-outline" onPress={verify} />
          <Button label="Back to Billing" variant="outline" onPress={() => router.replace('/billing')} />
        </>
      ) : null}
      {phase === 'failed' ? (
        <>
          <Button label="Try again" icon="refresh-outline" onPress={() => { started.current = true; start(); }} />
          <Button label="Back" variant="outline" onPress={() => router.back()} />
        </>
      ) : null}
    </Screen>
  );
}
