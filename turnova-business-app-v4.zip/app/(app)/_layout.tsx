import React, { useEffect } from 'react';
import { AppState } from 'react-native';
import { Redirect, Stack, usePathname } from 'expo-router';
import { useSession, isPlanRunning } from '@/src/auth/session';
import { useIsOnline } from '@/src/hooks/useIsOnline';
import { OfflineScreen } from '@/src/components/OfflineScreen';
import { ProfileLoading } from '@/src/components/ProfileLoading';
import { useTheme } from '@/src/theme';
import { slideTransition } from '@/src/navigation/transitions';

/** Screens that must stay reachable when the plan has expired, so the owner can renew. */
const ALLOWED_WHEN_BLOCKED = ['/billing', '/plans', '/change-plan', '/pay', '/plan-blocked'];

const REFRESH_MS = 30000;

export default function AppLayout() {
  const token = useSession((s) => s.token);
  const me = useSession((s) => s.me);
  const blockedMessage = useSession((s) => s.planBlockedMessage);
  const refreshMe = useSession((s) => s.refreshMe);
  const { isOnline, recheck } = useIsOnline();
  const { colors } = useTheme();
  const pathname = usePathname();

  // Keep plan state and the tab badges fresh: every 30 s, when the app comes
  // back to the foreground, and right after any "plan expired" answer.
  useEffect(() => {
    if (!token) return;
    const tick = () => refreshMe().catch(() => undefined);
    const timer = setInterval(tick, REFRESH_MS);
    const sub = AppState.addEventListener('change', (s) => s === 'active' && tick());
    return () => {
      clearInterval(timer);
      sub.remove();
    };
  }, [token, refreshMe]);

  useEffect(() => {
    if (blockedMessage) refreshMe().catch(() => undefined);
  }, [blockedMessage, refreshMe]);

  if (!token) return <Redirect href="/login" />;
  if (!isOnline) return <OfflineScreen onRetry={recheck} />;
  if (!me) return <ProfileLoading />;

  const blocked = !isPlanRunning(me.plan.state);
  const allowed = ALLOWED_WHEN_BLOCKED.some((p) => pathname === p || pathname.startsWith(p + '/'));
  if (blocked && !allowed) {
    return <Redirect href="/plan-blocked" />;
  }

  return (
    <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.background }, ...slideTransition }}>
      <Stack.Screen name="(owner)" />
      <Stack.Screen name="(staff)" />
    </Stack>
  );
}
