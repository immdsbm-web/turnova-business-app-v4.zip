import Constants from 'expo-constants';

const apiBaseUrl = (Constants.expoConfig?.extra?.apiBaseUrl as string) ?? '';

// The API base URL points at the versioned API root (e.g.
// "https://eaglecode.a1h.in/api/v1"), but relative media paths returned by
// the backend (e.g. "/assets/uploads/users/abc123.jpg") are served from the
// origin, not from under /api/v1. Strip that suffix once here so every
// relative path can be resolved against the plain origin.
const mediaOrigin = apiBaseUrl.replace(/\/api\/v1(\/business)?\/?$/, "");

/**
 * Resolve a possibly-relative media path (photo_url / logo_url /
 * user_photo_url / etc. as returned by the API) into a fully-qualified URL
 * that React Native's <Image> can load.
 *
 * - null/undefined/empty -> null (let callers fall back to an initials tile)
 * - already an absolute URL (http/https) -> returned as-is
 * - relative path -> prefixed with the media origin
 */
export function resolveImageUrl(path: string | null | undefined): string | null {
  if (!path) return null;
  const trimmed = path.trim();
  if (!trimmed) return null;
  // Local preview images (picked but not yet uploaded) load as-is.
  if (/^(file|content|data):/i.test(trimmed)) return trimmed;
  if (/^https?:\/\//i.test(trimmed)) {
    // Same host as the API but a different scheme (e.g. an upload response
    // returning http://): Android release builds block cleartext http, so
    // the image would silently fail to load. Use the origin's scheme.
    const abs = trimmed.match(/^https?:\/\/([^/]+)(.*)$/i);
    const origin = mediaOrigin.match(/^(https?):\/\/([^/]+)/i);
    if (abs && origin && abs[1].toLowerCase() === origin[2].toLowerCase()) {
      return `${origin[1]}://${abs[1]}${abs[2]}`;
    }
    return trimmed;
  }
  return `${mediaOrigin}${trimmed.startsWith('/') ? '' : '/'}${trimmed}`;
}
