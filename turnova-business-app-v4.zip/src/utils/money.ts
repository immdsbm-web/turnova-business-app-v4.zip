// ₹ symbol, no decimal places for whole amounts, comma thousands-separator.
export function formatMoney(amount: number): string {
  const rounded = Math.round(amount);
  return `₹${rounded.toLocaleString('en-IN')}`;
}
