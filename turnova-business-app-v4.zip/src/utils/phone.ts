// Phone numbers are stored/sent as digits only. Country code is fixed to
// India (+91) throughout — there is no country picker anywhere in the app.
// Per §0.6, /auth/otp/request accepts 7–15 digit-only phone strings and
// does the authoritative validation server-side; the client only needs a
// basic digits-only, sane-length check before enabling the Continue button.

export function stripToDigits(input: string): string {
  return input.replace(/\D/g, '');
}

export function isPlausiblePhoneLength(digitsOnly: string): boolean {
  return digitsOnly.length >= 10 && digitsOnly.length <= 15;
}

/** Exactly 10 digits, starting 6-9 — the valid Indian mobile number shape. */
export function isValidIndianMobile(digitsOnly: string): boolean {
  return /^[6-9]\d{9}$/.test(digitsOnly);
}

/** "8099462624" -> "+91 8099462624" */
export function formatPhone(digitsOnly: string): string {
  return `+91 ${digitsOnly}`;
}
