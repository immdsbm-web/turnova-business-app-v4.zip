/** "14:30:00" -> "2:30 PM" */
export function formatTime12(t: string | null | undefined): string {
  if (!t) return '';
  const [h, m] = t.split(':').map(Number);
  if (Number.isNaN(h)) return t;
  return `${h % 12 === 0 ? 12 : h % 12}:${String(m ?? 0).padStart(2, '0')} ${h >= 12 ? 'PM' : 'AM'}`;
}

/** Rupees with two decimals only when needed: 299 -> "₹299", 352.82 -> "₹352.82" */
export function rupees(v: string | number | null | undefined): string {
  const n = Number(v ?? 0);
  return '₹' + n.toLocaleString('en-IN', { minimumFractionDigits: Number.isInteger(n) ? 0 : 2, maximumFractionDigits: 2 });
}

/** "2026-10-08 14:30:00" -> "8 Oct 2026" */
export function formatDateLong(dt: string | null | undefined): string {
  if (!dt) return '—';
  const d = new Date(dt.replace(' ', 'T'));
  if (Number.isNaN(d.getTime())) return dt;
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

export function formatDateTime(dt: string | null | undefined): string {
  if (!dt) return '—';
  const d = new Date(dt.replace(' ', 'T'));
  if (Number.isNaN(d.getTime())) return dt;
  return `${formatDateLong(dt)}, ${d.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit', hour12: true })}`;
}

export const truthy = (v: unknown): boolean => v === true || v === 1 || v === '1';

/** Readable service length: 15 -> "15 min", 60 -> "1 hr", 75 -> "1 hr 15 min", 150 -> "2 hrs 30 min". */
export function formatDuration(minutes: number | string | null | undefined): string {
  const total = Math.round(Number(minutes ?? 0));
  if (!Number.isFinite(total) || total <= 0) return '';
  if (total < 60) return `${total} min`;
  const h = Math.floor(total / 60);
  const m = total % 60;
  const hours = `${h} ${h === 1 ? 'hr' : 'hrs'}`;
  return m === 0 ? hours : `${hours} ${m} min`;
}

/** "Fri, 23 Oct" from a YYYY-MM-DD booking date. */
export function formatBookingDay(ymd: string | null | undefined): string {
  if (!ymd) return '—';
  const d = new Date(`${ymd.slice(0, 10)}T12:00:00`);
  if (Number.isNaN(d.getTime())) return ymd;
  const wd = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][d.getDay()];
  const mo = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.getMonth()];
  return `${wd}, ${d.getDate()} ${mo}`;
}

/** "10:30 AM – 11:00 AM" (or just the start when there is no end). */
export function formatTimeRange12(start: string | null | undefined, end?: string | null): string {
  if (!start) return '';
  return end ? `${formatTime12(start)} – ${formatTime12(end)}` : formatTime12(start);
}
