// Design tokens from the Turnova redesign (turnova-redesign.html).
// Light and dark values are copied from that file's token table, so the app
// and the approved mockup stay one-to-one.
//
// Existing token names are kept wherever a call site already used one (so
// nothing outside the redesign needs to change); new tokens were added for
// the redesign's tinted status colours, input fill and inverse surfaces.
export const lightColors = {
  background: '#F8FAF9', // Warm Off-White
  surface: '#FFFFFF', // Pure White
  primary: '#075E4B', // Deep Emerald
  primaryDark: '#064E43', // Rich Dark Teal: pressed state, hero band
  primaryContainer: '#DDF5EB', // Soft Mint: selected backgrounds, time blocks
  primaryBorder: 'rgba(7,94,75,0.28)', // thin green border on mint selections
  primaryText: '#FFFFFF', // text/icons placed on `primary`
  textPrimary: '#14252B', // Deep Charcoal
  textSecondary: '#718096', // Muted Slate Grey
  textMuted: '#718096', // the redesign uses one muted grey for secondary text, icons and placeholders
  border: '#E6ECE9', // Soft Neutral Grey
  success: '#20A779', // Fresh Green
  successText: '#137A58', // text on the success tint (AA contrast)
  successBg: '#E1F5EC',
  danger: '#E45454', // Soft Red: errors, cancellations, destructive
  dangerText: '#C23B3B',
  dangerBg: '#FCEAEA',
  warning: '#E9A23B', // Warm Amber
  warningText: '#8A5A0B',
  warningBg: '#FBF0DB',
  info: '#0F8A92', // Teal: "Confirmed" status
  infoText: '#0A6B72',
  infoBg: '#DDF1F2',
  neutralBg: '#F1F5F3', // soft input fill, "Skipped" status
  skeleton: '#E9EEEC',
  hero: '#064E43', // business-profile header band
  inverse: '#14252B', // toast background
  inverseText: '#FFFFFF',
  scrim: 'rgba(20,37,43,0.45)',
  distanceBadgeBg: '#DDF1F2',
  distanceBadgeText: '#0A6B72',
  shadow: '#14252B',
  surfaceAlt: '#F1F5F3', // subtle panel inside a card
  overlay: 'rgba(20,37,43,0.45)',
};

export type ThemeColors = { [K in keyof typeof lightColors]: string };

export const darkColors: ThemeColors = {
  background: '#101A1A',
  surface: '#192625',
  primary: '#35B995',
  primaryDark: '#5ED3AB', // text/icons on dark surfaces
  primaryContainer: 'rgba(53,185,149,0.14)',
  primaryBorder: 'rgba(53,185,149,0.40)',
  primaryText: '#062019', // dark ink on the bright mint-green button
  textPrimary: '#F4F8F7',
  textSecondary: '#A7B8B4',
  textMuted: '#A7B8B4',
  border: '#30413E',
  success: '#4CC9A0',
  successText: '#5ED3AB',
  successBg: 'rgba(76,201,160,0.14)',
  danger: '#F06A6A',
  dangerText: '#FF8A8A',
  dangerBg: 'rgba(240,106,106,0.14)',
  warning: '#F2B45A',
  warningText: '#F2B45A',
  warningBg: 'rgba(242,180,90,0.14)',
  info: '#4FC3CB',
  infoText: '#6AD0D7',
  infoBg: 'rgba(79,195,203,0.14)',
  neutralBg: '#1F302E',
  skeleton: '#243533',
  hero: '#12342E',
  inverse: '#F4F8F7',
  inverseText: '#101A1A',
  scrim: 'rgba(0,0,0,0.6)',
  distanceBadgeBg: 'rgba(79,195,203,0.14)',
  distanceBadgeText: '#6AD0D7',
  shadow: '#000000',
  surfaceAlt: '#1F302E',
  overlay: 'rgba(0,0,0,0.6)',
};
