import { lightColors, darkColors, ThemeColors } from './colors';
import { typography } from './typography';
import { spacing, radii } from './spacing';
import { useThemeMode } from './ThemeModeContext';

export type Theme = {
  colors: ThemeColors;
  typography: typeof typography;
  spacing: typeof spacing;
  radii: typeof radii;
  isDark: boolean;
};

export function useTheme(): Theme {
  // Dark mode is a user-toggleable, persisted setting (§4.1) — not a raw
  // read of the system scheme. See ThemeModeContext for the "system
  // default until explicitly overridden" logic.
  const { isDark } = useThemeMode();
  return {
    colors: isDark ? darkColors : lightColors,
    typography,
    spacing,
    radii,
    isDark,
  };
}

export { lightColors, darkColors } from './colors';
export { typography } from './typography';
export { spacing, radii } from './spacing';
export { TAB_BAR_HEIGHT, TAB_BAR_MARGIN, TAB_BAR_CONTENT_CLEARANCE } from './layout';
export { ThemeModeProvider, useThemeMode } from './ThemeModeContext';
