import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { Appearance } from 'react-native';
import * as SecureStore from 'expo-secure-store';

const DARK_MODE_KEY = 'turnova.darkMode';

type ThemeModeContextValue = {
  isDark: boolean;
  toggleDarkMode: () => void;
};

const ThemeModeContext = createContext<ThemeModeContextValue | undefined>(undefined);

export function ThemeModeProvider({ children }: { children: React.ReactNode }) {
  // Synchronous initial guess from the system, so there's no flash of the
  // wrong theme before the persisted-choice check below resolves.
  const [isDark, setIsDark] = useState<boolean>(() => Appearance.getColorScheme() === 'dark');

  // The Settings switch is a manual override on top of the device theme: it
  // wins immediately, but only until the device's own theme next changes —
  // at that point the app goes back to following the device. `override`
  // holds the device scheme the override was made against, so the listener
  // below can tell "the device actually changed" apart from other
  // Appearance events that report the same scheme again (e.g. resume).
  const override = useRef<'light' | 'dark' | null>(null);

  useEffect(() => {
    (async () => {
      const stored = await SecureStore.getItemAsync(DARK_MODE_KEY).catch(() => null);
      // No stored value yet means the user has never toggled — keep
      // following the system default rather than overriding it.
      if (stored === 'true' || stored === 'false') {
        const value = stored === 'true';
        setIsDark(value);
        override.current = Appearance.getColorScheme() ?? 'light';
      }
    })();
  }, []);

  useEffect(() => {
    const subscription = Appearance.addChangeListener(({ colorScheme }) => {
      const scheme = colorScheme ?? 'light';
      if (override.current !== null && scheme === override.current) {
        // Same device theme reported again — the manual override still
        // applies, don't touch isDark.
        return;
      }
      // The device theme itself changed (or there was never an override):
      // follow it, and clear the stored choice so a later app resume
      // doesn't reapply the old override.
      override.current = null;
      setIsDark(scheme === 'dark');
      SecureStore.deleteItemAsync(DARK_MODE_KEY).catch(() => undefined);
    });
    return () => subscription.remove();
  }, []);

  const toggleDarkMode = useCallback(() => {
    setIsDark((prev) => {
      const next = !prev;
      SecureStore.setItemAsync(DARK_MODE_KEY, String(next)).catch(() => undefined);
      override.current = Appearance.getColorScheme() ?? 'light';
      return next;
    });
  }, []);

  return (
    <ThemeModeContext.Provider value={{ isDark, toggleDarkMode }}>
      {children}
    </ThemeModeContext.Provider>
  );
}

export function useThemeMode(): ThemeModeContextValue {
  const ctx = useContext(ThemeModeContext);
  if (!ctx) throw new Error('useThemeMode must be used within a ThemeModeProvider');
  return ctx;
}
