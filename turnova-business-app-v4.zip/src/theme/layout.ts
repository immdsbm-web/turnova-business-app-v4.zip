// Bottom tab bar is docked to the screen edge (no floating margin).
// Anything that must clear it (Toast, scroll padding) reads these values.
export const TAB_BAR_HEIGHT = 62;
export const TAB_BAR_MARGIN = 0;
/** Bottom padding for scrollable tab screen content so it clears the docked tab bar (the safe-area inset is added by the caller). */
export const TAB_BAR_CONTENT_CLEARANCE = TAB_BAR_HEIGHT + 20;
