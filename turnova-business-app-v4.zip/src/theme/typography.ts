import { TextStyle } from 'react-native';

// Type scale shared with the Customer app: Inter only. Each weight is an
// exact-weight font file loaded via useFonts in app/_layout.tsx, so fontFamily
// must name the specific weighted family; do not add a fontWeight on top of it
// (on Android a weight override on a single-weight custom font file does
// nothing useful and can clip glyphs).
const INTER_REGULAR = 'Inter_400Regular';
const INTER_MEDIUM = 'Inter_500Medium';
const INTER_SEMIBOLD = 'Inter_600SemiBold';
const INTER_BOLD = 'Inter_700Bold';

type TypeScale = Pick<TextStyle, 'fontSize' | 'fontWeight' | 'lineHeight' | 'fontFamily' | 'letterSpacing'>;

export type TypographyKey =
  | 'display' | 'displayTitle' | 'h1' | 'h2' | 'titleSmall' | 'body' | 'bodyStrong'
  | 'label' | 'caption' | 'captionStrong' | 'badge' | 'tab' | 'tabActive' | 'appBar' | 'button'
  | 'overline' | 'metric';

export const typography: Record<TypographyKey, TypeScale> = {
  display: { fontFamily: INTER_BOLD, fontSize: 44, lineHeight: 52, letterSpacing: -1.3 },
  // 28/34 Bold: large tab-screen titles ("Bookings", "Manage").
  displayTitle: { fontFamily: INTER_BOLD, fontSize: 28, lineHeight: 34, letterSpacing: -0.56 },
  // 26/32 Bold: business name, auth headlines.
  h1: { fontFamily: INTER_BOLD, fontSize: 26, lineHeight: 32, letterSpacing: -0.5 },
  // 20/26 SemiBold: section headings.
  h2: { fontFamily: INTER_SEMIBOLD, fontSize: 20, lineHeight: 26, letterSpacing: -0.2 },
  // 16/22 SemiBold: card and list-row titles.
  titleSmall: { fontFamily: INTER_SEMIBOLD, fontSize: 16, lineHeight: 22 },
  body: { fontFamily: INTER_REGULAR, fontSize: 15, lineHeight: 22 },
  bodyStrong: { fontFamily: INTER_SEMIBOLD, fontSize: 15, lineHeight: 22 },
  // 13/18 Medium: form labels.
  label: { fontFamily: INTER_MEDIUM, fontSize: 13, lineHeight: 18 },
  // 13/18 Regular: secondary and meta text.
  caption: { fontFamily: INTER_REGULAR, fontSize: 13, lineHeight: 18 },
  captionStrong: { fontFamily: INTER_SEMIBOLD, fontSize: 13, lineHeight: 18 },
  // 12/16 SemiBold: status badges, small tags.
  badge: { fontFamily: INTER_SEMIBOLD, fontSize: 12, lineHeight: 16 },
  // 11/14: tab-bar labels.
  tab: { fontFamily: INTER_MEDIUM, fontSize: 11, lineHeight: 14 },
  tabActive: { fontFamily: INTER_SEMIBOLD, fontSize: 11, lineHeight: 14 },
  // 18/24 SemiBold: app-bar title on pushed screens.
  appBar: { fontFamily: INTER_SEMIBOLD, fontSize: 18, lineHeight: 24, letterSpacing: -0.18 },
  // 16/22 SemiBold: button labels.
  button: { fontFamily: INTER_SEMIBOLD, fontSize: 16, lineHeight: 22 },
  // Small uppercase section labels ("TODAY") -- apply .toUpperCase() to the text.
  overline: { fontFamily: INTER_SEMIBOLD, fontSize: 11, lineHeight: 14, letterSpacing: 0.9 },
  // Big numbers on stat tiles.
  metric: { fontFamily: INTER_BOLD, fontSize: 28, lineHeight: 34, letterSpacing: -0.4 },
};
