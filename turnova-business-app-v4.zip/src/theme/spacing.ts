// 4pt grid, matching the Flutter reference app's AppSpacing exactly
// (lib/theme/app_spacing.dart).
export const spacing = {
  unit: 4,
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
  xxxxl: 40,
} as const;

// Crisp, corporate radii: small and consistent.
export const radii = {
  input: 14,
  button: 16,
  row: 16,
  card: 20,
  sheet: 24,
  chip: 999,
  full: 999,
} as const;
