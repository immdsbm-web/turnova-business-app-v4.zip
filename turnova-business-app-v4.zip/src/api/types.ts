// Shapes of what /api/v1/business/... returns. Numbers that come from the
// database may arrive as strings (e.g. prices), so screens convert with Number().

export type Role = 'owner' | 'staff';
export type PlanState = 'none' | 'trial' | 'active' | 'expired' | 'cancelled';

export type Me = {
  account: { id: number; name: string; email: string; role: Role };
  business: { id: number; name: string; status: string; address?: string | null; city?: string | null; state?: string | null };
  plan: { state: PlanState; name: string | null; days_left: number; valid_until: string | null; notice: string | null };
  badges: { flagged_for_reassignment: number; waiting_queue: number; unread_messages: number };
};

export type LoginResult = Me & { token: string };

export type BookingStatus = 'upcoming' | 'waiting' | 'called' | 'completed' | 'skipped' | 'cancelled' | 'no_show' | string;

// One of today's appointments for a staff member (time order).
export type Appointment = {
  booking_id: number;
  status: BookingStatus;
  booking_time: string | null; // "HH:MM:SS"
  end_time: string | null;
  customer_name: string;
  customer_phone: string;
  customer_photo_url: string | null;
  customer_verified_at: string | null; // customer scanned the staff QR ("arrived", optional)
  called_at: string | null;
  service_names: string | null;
};

// An appointment on a later day.
export type LaterAppointment = {
  booking_id: number;
  booking_date: string;
  booking_time: string | null;
  end_time: string | null;
  customer_name: string;
  customer_phone: string;
  customer_photo_url: string | null;
  service_names: string | null;
  flagged_for_reassignment: number | boolean;
};

export type StaffRef = { id: number; name: string; photo_url?: string | null };

export type QueueState = {
  staff_list: StaffRef[];
  active_staff_id: number | null;
  appointments: Appointment[];
  later_appointments: LaterAppointment[];
  server_time: string;
};

export type BookingRow = {
  id: number;
  /** The customer's user id; used to find the chat with them. */
  customer_id?: number;
  booking_date: string;
  booking_time: string | null;
  customer_name: string;
  customer_phone: string;
  customer_photo_url: string | null;
  end_time: string | null;
  service_names: string | null;
  staff_name: string | null;
  status: BookingStatus;
  flagged_for_reassignment: number | boolean;
};

export type Paginated<T> = { rows: T[]; total: number; page: number; total_pages: number };

export type BookingsResponse = {
  result: Paginated<BookingRow>;
  filters: { status: string; date_from: string; date_to: string; staff_id: number | null };
  today_only: boolean;
  staff_list: StaffRef[];
  active_staff_id: number | null;
};

export type FlaggedBooking = {
  id?: number; booking_date: string; booking_time: string | null; customer_name: string; customer_phone?: string;
  service_names?: string | null; staff_name?: string | null;
};

export type DashboardResponse = {
  business: { name: string; [k: string]: unknown };
  // Every value here is a plain COUNT (a number), exactly like the website's dashboard tiles.
  summary: {
    todays_bookings: number;
    current_queue_length: number;
    active_staff: number;
    upcoming_bookings: number;
    flagged_for_reassignment: number;
    staff_with_login: number;
  };
  flagged_bookings: FlaggedBooking[];
};

export type ServiceRow = { id: number; name: string; duration_minutes: number; price: string | number; is_paused: number | boolean };
export type ServiceInput = { name: string; duration_minutes: string; price: string };

export type StaffRow = {
  id: number; name: string; role: string | null; email: string | null; phone?: string | null; photo_url: string | null;
  is_active: number | boolean; is_on_leave: number | boolean; working_hours_start: string | null; working_hours_end: string | null;
  // The server sends these as lists, not text.
  services?: Array<{ id: number; name: string }>;
  upcoming_leaves?: Array<{ leave_date: string }>;
};

export type StaffFormData = {
  staff: (StaffRow & { service_ids?: number[]; leaves?: Array<{ leave_date: string }> }) | null;
  services: Array<{ id: number; name: string }>;
};

export type PlanUsage = {
  state: PlanState; plan_name: string | null; staff_count: number; max_staff: number | null; staff_limit_reached: boolean;
  // Photo limit of the current plan (max_photos null = unlimited).
  photo_count?: number; max_photos?: number | null; photos_over?: number; photos_notice?: string | null;
};

export type BusinessPhoto = { id: number; photo_url: string; sort_order: number };
export type PhotoUsage = {
  count: number; max: number | null; remaining: number | null; over_by: number; can_add: boolean;
  plan_name: string | null; state: PlanState; notice: string | null;
};
export type BusinessPhotosResponse = { photos: BusinessPhoto[]; usage: PhotoUsage };

export type BreakItem = { id: number; start: string; end: string }; // times as "HH:MM"
export type BreakSettings = { break_between_minutes: number; items: BreakItem[] };
/** saved=false + needs_confirmation=true: the break overlaps upcoming bookings and nothing was saved yet. */
export type BreakSaveResult = { saved: boolean; needs_confirmation: boolean; affected_bookings: number; message: string };
export type Holiday = { id: number; date: string; reason: string | null };

export type ReviewRow = {
  id: number; rating: number; comment: string | null; created_at: string; is_hidden: number | boolean; user_name: string | null; user_phone?: string | null;
};
export type ReviewsResponse = { result: Paginated<ReviewRow> & { average_rating: number | null; review_count: number } };

export type BusinessProfile = {
  name: string; category_id: number | null; address: string | null; city: string | null; district: string | null; state: string | null;
  lat: string | number | null; lng: string | number | null; working_hours_start: string | null; working_hours_end: string | null;
  days: string[]; cancellation_cutoff_hours: number; logo_url: string | null;
  // Optional. whatsapp_number is "+91XXXXXXXXXX"; whatsapp_local is just the 10 digits ('' when not set).
  whatsapp_number?: string | null; whatsapp_local?: string | null;
  // Optional social media links (full https:// URLs).
  facebook_url?: string | null; instagram_url?: string | null; youtube_url?: string | null;
  linkedin_url?: string | null; x_url?: string | null;
};

export type Breakdown = { base: number; gst: number; total: number };
export type PlanRow = {
  id: number; name: string; description: string | null; price_monthly: string | number;
  max_staff: number | null; trial_days: number;
  max_photos?: number | null;
};
export type PlanSettings = { gst_percent: number; prices_include_gst: boolean; payment_link_valid_days: number };
export type CurrentSubscription = {
  state: PlanState; valid_until: string | null; days_left: number;
  plan: PlanRow | null; subscription: { plan_activated_at?: string | null; created_at?: string } | null;
};

export type PlanCard = PlanRow & {
  breakdown: Breakdown; is_current: boolean; can_trial: boolean; fits: boolean; direction: 'upgrade' | 'downgrade' | 'change';
};
export type PlansResponse = {
  current: CurrentSubscription; cards: PlanCard[]; usage: PlanUsage; settings: PlanSettings; gateway_ready: boolean; has_paid_time: boolean;
};

export type PaymentRow = {
  id: number; plan_name: string; total_amount: string | number; gst_amount: string | number; status: string; link_url: string | null;
  link_expires_at: string | null; paid_at: string | null; created_at: string; period_start: string | null; period_end: string | null;
};
export type BillingResponse = {
  current: CurrentSubscription; breakdown: Breakdown | null; activated_at: string | null; usage: PlanUsage; settings: PlanSettings;
  payments: PaymentRow[]; totals: { total_paid: number; paid_count: number; last_paid_at: string | null };
  contact: { name: string; email: string; phone: string } | null; gateway_ready: boolean;
};

export type ChangePreview = {
  current: CurrentSubscription; target: PlanRow; direction: 'upgrade' | 'downgrade' | 'change';
  current_breakdown: Breakdown; target_breakdown: Breakdown; staff_count: number; fits: boolean;
  photo_count?: number; photo_limit?: number | null; photos_over?: number; photos_notice?: string | null;
  settings: PlanSettings; gateway_ready: boolean; is_trial: boolean;
};

export type PayOrder = {
  method: 'order'; payment_id: number; order_id: string; payment_session_id: string; environment: 'SANDBOX' | 'PRODUCTION'; amount: number;
};

export type QrResponse = {
  business: { id: number; name: string; address?: string | null; city?: string | null };
  staff_list: StaffRef[]; active_staff_id: number | null; staff_member: { id: number; name: string; qr_token: string } | null;
};

export type Category = { id: number; name: string };
export type RegistrationInput = {
  business_name: string; category_id: string; address: string; city: string; district: string; state: string;
  open_time: string; close_time: string; days: string[]; owner_name: string; owner_email: string; owner_phone: string;
  password: string; password_confirm: string;
};
export type BusinessStatus = { name: string; status: string; rejection_reason: string | null; suspension_reason: string | null };

export class ApiError extends Error {
  code: string;
  status: number;
  details: Record<string, any>;
  constructor(code: string, message: string, status = 0, details: Record<string, any> = {}) {
    super(message);
    this.code = code;
    this.status = status;
    this.details = details;
  }
}

// --- Messages (chat with customers) -------------------------------------------------------
export type ChatConversation = {
  id: number;
  customer: { id: number; name: string; photo_url: string | null };
  last_message_at: string | null;
  last_message_preview: string | null;
  unread: number;
};
export type ChatMessage = {
  id: number;
  sender_type: 'customer' | 'business' | 'system';
  sender_role: 'owner' | 'staff' | null;
  sender_name: string | null;
  kind: string; // text | booking_confirmed | opening_notice | reminder | your_turn | no_show | cancelled
  body: string;
  booking_id: number | null;
  created_at: string;
};

// --- Business banner (one per business, shown in the customer app) ---------------------------
export type BusinessBanner = {
  id: number;
  image_url: string;
  title: string | null;
  subtitle: string | null;
  /** 1.00 – 3.00 */
  zoom: number;
  /** Focal point, 0 – 100 (percent from the left / top). */
  x: number;
  y: number;
};
export type BannerResponse = { banner: BusinessBanner | null };
