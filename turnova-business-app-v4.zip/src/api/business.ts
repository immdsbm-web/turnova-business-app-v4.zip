import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { API_BASE_URL, get, getAuthToken, post, postForm } from './client';
import {
  BillingResponse, BookingsResponse, ChatConversation, ChatMessage, BusinessPhotosResponse, BusinessProfile, BusinessStatus, BreakSaveResult, BreakSettings, Category, ChangePreview, DashboardResponse, Holiday,
  LoginResult, BannerResponse, Me, PayOrder, PlansResponse, QrResponse, QueueState, RegistrationInput, ReviewsResponse, ServiceRow, StaffFormData, StaffRow, PlanUsage,
} from './types';

export type Picked = { uri: string; mime?: string | null; name?: string | null };

// --- Auth + registration ---------------------------------------------------------
export const login = (email: string, password: string, deviceLabel: string) =>
  post<LoginResult>('/auth/login', { email, password, client: 'app', device_label: deviceLabel });
export const logout = () => post<{ logged_out: boolean }>('/auth/logout');
export const fetchMe = () => get<Me>('/auth/me');
export const fetchCategories = () => get<{ categories: Category[] }>('/registration/categories');
export const registerBusiness = (input: RegistrationInput) => post<{ business_id: number }>('/registration', input);
export const fetchRegistrationStatus = (businessId: number) =>
  get<{ business: BusinessStatus }>('/registration/status', { business_id: businessId });

// --- Dashboard, bookings, queue ----------------------------------------------------
export const fetchDashboard = () => get<DashboardResponse>('/dashboard');
export const fetchBookings = (params: Record<string, unknown>) => get<BookingsResponse>('/bookings', params);
export const cancelBooking = (id: number, reason: string) => post<{ message: string }>(`/bookings/${id}/cancel`, { reason });

export const fetchQueue = (staffId?: number | null) => get<QueueState>('/queue', staffId ? { staff_id: staffId } : undefined);
/** Call Next Customer: marks the next upcoming appointment "called" and notifies that customer. Throws "No customers are waiting." when there is none. */
export const callNext = (staffId?: number | null) => post<{ message: string }>('/queue/call-next', staffId ? { staff_id: staffId } : {});
/** Complete only marks the appointment completed (no notification). */
export const queueAction = (action: 'complete' | 'no-show', bookingId: number, staffId?: number | null) =>
  post<{ message: string }>(`/queue/${bookingId}/${action}`, staffId ? { staff_id: staffId } : {});

// --- Services, break settings, holidays -----------------------------------------------------
export const fetchServices = () => get<{ services: ServiceRow[] }>('/services');
export const saveService = (id: number | null, input: { name: string; duration_minutes: string; price: string }) =>
  post<{ message: string }>(id ? `/services/${id}` : '/services', input);
export const deleteService = (id: number) => post<{ message: string }>(`/services/${id}/delete`);
export const toggleServicePause = (id: number) => post<{ message: string }>(`/services/${id}/toggle-pause`);

export const fetchDatesCapacity = () =>
  get<{ breaks: BreakSettings; holidays: Holiday[] }>('/dates-capacity');
/** Gap kept free between two appointments (minutes). */
export const saveBreaks = (breakBetweenMinutes: string) =>
  post<{ message: string }>('/breaks', { break_between_minutes: breakBetweenMinutes });
/** Several breaks per business. When one overlaps upcoming bookings it is NOT saved until confirm = true. */
export const addBreak = (start: string, end: string, confirm: boolean) =>
  post<BreakSaveResult>('/breaks/add', { start, end, confirm: confirm ? '1' : '0' });
export const updateBreak = (id: number, start: string, end: string, confirm: boolean) =>
  post<BreakSaveResult>(`/breaks/${id}`, { start, end, confirm: confirm ? '1' : '0' });
export const deleteBreak = (id: number) => post<{ message: string }>(`/breaks/${id}/delete`);
export const addHoliday = (date: string, reason: string) => post<{ message: string }>('/holidays', { date, reason });
export const removeHoliday = (id: number) => post<{ message: string }>(`/holidays/${id}/delete`);

// --- Staff -------------------------------------------------------------------------------
export const fetchStaff = () => get<{ staff: StaffRow[]; usage: PlanUsage }>('/staff');
export const fetchStaffForm = (id: number) => get<StaffFormData>('/staff/form', { id });
export const saveStaff = (id: number | null, fields: Record<string, string | string[] | undefined>, photo?: Picked | null) =>
  postForm<{ id: number; message: string }>(id ? `/staff/${id}` : '/staff', fields, photo ? { field: 'photo', ...photo } : undefined);
export const toggleStaffActive = (id: number) => post<{ message: string }>(`/staff/${id}/toggle-active`);
export const deleteStaff = (id: number) => post<{ message: string }>(`/staff/${id}/delete`);
export const addStaffLeave = (staffId: number, date: string) => post<{ message: string }>('/staff/leave', { staff_id: staffId, date });
export const removeStaffLeave = (staffId: number, date: string) => post<{ message: string }>('/staff/leave/remove', { staff_id: staffId, date });

// --- Reviews, profiles, QR ---------------------------------------------------------------------
export const fetchReviews = (page: number) => get<ReviewsResponse>('/reviews', { page });
export const setReviewHidden = (id: number, hidden: boolean) => post<{ message: string }>(`/reviews/${id}/${hidden ? 'hide' : 'unhide'}`);

export const fetchBusinessProfile = () => get<{ business: BusinessProfile; categories: Category[] }>('/profile');

// --- Business photos (photos only; the plan decides how many) -----------------------------------
export const fetchBusinessPhotos = () => get<BusinessPhotosResponse>('/photos');
/** Uploads ONE photo. Throws ApiError (code PLAN_LIMIT when the plan's photo limit is reached). */
export const uploadBusinessPhoto = (photo: Picked) =>
  postForm<BusinessPhotosResponse & { message: string }>('/photos', {}, { field: 'photo', ...photo });
export const deleteBusinessPhoto = (id: number) => post<BusinessPhotosResponse & { message: string }>(`/photos/${id}/delete`);
/** Swaps the picture of one photo, keeping its place in the gallery. */
export const replaceBusinessPhoto = (id: number, photo: Picked) =>
  postForm<BusinessPhotosResponse & { message: string }>(`/photos/${id}/replace`, {}, { field: 'photo', ...photo });
/** Moves one photo to the first position. */
export const makeBusinessPhotoFirst = (id: number) => post<BusinessPhotosResponse & { message: string }>(`/photos/${id}/make-first`);

export const saveBusinessProfile = (fields: Record<string, string | string[] | undefined>, logo?: Picked | null) =>
  postForm<{ message: string }>('/profile', fields, logo ? { field: 'logo', ...logo } : undefined);

export const fetchMyProfile = () => get<{ staff: { id: number; name: string; role: string | null; photo_url: string | null } }>('/my-profile');
export const saveMyPhoto = (photo?: Picked | null, remove = false) =>
  postForm<{ staff: { id: number; name: string; role: string | null; photo_url: string | null }; message: string }>(
    '/my-profile', { remove_photo: remove ? '1' : '' }, photo ? { field: 'photo', ...photo } : undefined
  );

export const fetchQr = (staffId?: number | null) => get<QrResponse>('/qr', staffId ? { staff_id: staffId } : undefined);

// --- Billing, plans, payments ---------------------------------------------------------------
export const fetchBilling = () => get<BillingResponse>('/billing');
export const fetchPlans = () => get<PlansResponse>('/plans');
export const fetchChangePreview = (planId: number) => get<ChangePreview>('/plans/change-preview', { plan_id: planId });
export const selectPlan = (planId: number) =>
  post<{ mode: 'trial' | 'trial_kept' | 'payment_required'; message?: string }>('/plans/select', { plan_id: planId });
export const changePlan = (planId: number) =>
  post<{ mode: 'trial_kept' | 'payment_required'; message?: string }>('/plans/change', { plan_id: planId, confirm: '1' });
export const createUpiOrder = (planId: number) => post<PayOrder>('/billing/pay', { plan_id: planId, method: 'order' });
export const confirmPayment = (orderId: string) =>
  post<{ status: string; plan_state: string; plan_name: string | null; valid_until: string | null }>('/billing/confirm', { order_id: orderId });

/** Downloads a PDF receipt to the phone and opens the share / save sheet. */
export async function downloadReceipt(paymentId: number): Promise<void> {
  const token = getAuthToken();
  const target = `${FileSystem.cacheDirectory}Turnova-Receipt-${String(paymentId).padStart(6, '0')}.pdf`;
  const result = await FileSystem.downloadAsync(`${API_BASE_URL}/billing/receipts/${paymentId}`, target, {
    headers: { Authorization: `Bearer ${token}`, Accept: 'application/pdf' },
  });
  if (result.status !== 200) {
    throw new Error('Could not download the receipt. Please try again.');
  }
  if (await Sharing.isAvailableAsync()) {
    await Sharing.shareAsync(result.uri, { mimeType: 'application/pdf', dialogTitle: 'Receipt', UTI: 'com.adobe.pdf' });
  } else {
    throw new Error('Sharing is not available on this device.');
  }
}

// --- Messages: owner sees every chat, staff only their own customers' --------------------------------
export const fetchChats = () => get<{ conversations: ChatConversation[]; unread: number }>('/chats');
export const fetchChatUnread = () => get<{ unread: number }>('/chats/unread');
export const fetchChatMessages = (id: number) =>
  get<{ conversation: { id: number; customer: ChatConversation['customer'] }; messages: ChatMessage[] }>(`/chats/${id}/messages`);
export const sendChatMessage = (id: number, body: string) => post<{ message_id: number }>(`/chats/${id}/messages`, { body });
export const markChatRead = (id: number) => post<{ unread: number }>(`/chats/${id}/read`);

// --- Banner (ONE per business, every plan) -----------------------------------------------------
export const fetchBanner = () => get<BannerResponse>('/banner');
/** Creates / edits the banner. `image` is required only when there is no banner yet. */
export const saveBanner = (
  fields: { title: string; subtitle: string; zoom: number; x: number; y: number },
  image?: Picked | null
) =>
  postForm<BannerResponse & { message: string }>(
    '/banner',
    { title: fields.title, subtitle: fields.subtitle, zoom: fields.zoom.toFixed(2), x: String(Math.round(fields.x)), y: String(Math.round(fields.y)) },
    image ? { field: 'image', ...image } : undefined
  );
export const deleteBanner = () => post<BannerResponse & { message: string }>('/banner/delete');
