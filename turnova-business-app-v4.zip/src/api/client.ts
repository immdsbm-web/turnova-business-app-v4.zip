import axios, { AxiosError, AxiosRequestConfig } from 'axios';
import Constants from 'expo-constants';
import { ApiError } from './types';

const baseURL = (Constants.expoConfig?.extra?.apiBaseUrl as string) ?? '';

/**
 * Hooks the session store plugs in (kept here so this file has no import
 * cycle with the store):
 *  - getToken: the signed-in user's bearer token
 *  - onUnauthenticated: token expired / revoked -> sign out
 *  - onPlanBlocked: the plan expired (402) -> show the "plan expired" screen
 */
type Handlers = {
  getToken: () => string | null;
  onUnauthenticated: () => void;
  onPlanBlocked: (code: string, message: string) => void;
};

let handlers: Handlers = { getToken: () => null, onUnauthenticated: () => {}, onPlanBlocked: () => {} };

export function configureApi(h: Handlers) {
  handlers = h;
}

export const http = axios.create({ baseURL, timeout: 30000, headers: { Accept: 'application/json' } });

http.interceptors.request.use((config) => {
  const token = handlers.getToken();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

function toApiError(e: unknown): ApiError {
  const err = e as AxiosError<any>;
  if (err.response) {
    const body = err.response.data;
    const apiErr = body && typeof body === 'object' ? body.error : null;
    return new ApiError(
      apiErr?.code ?? 'SERVER_ERROR',
      apiErr?.message ?? 'Something went wrong. Please try again.',
      err.response.status,
      apiErr?.details ?? {}
    );
  }
  if (err.code === 'ECONNABORTED') return new ApiError('NETWORK_ERROR', 'The server took too long to answer. Please try again.', 0);
  return new ApiError('NETWORK_ERROR', "Can't reach the server. Check your internet connection and try again.", 0);
}

/** Unwraps {success, data, error}; throws ApiError; applies the global 401 / 402 handling. */
export async function request<T>(config: AxiosRequestConfig): Promise<T> {
  try {
    const res = await http.request<{ success: boolean; data: T }>(config);
    return res.data.data;
  } catch (e) {
    const apiError = toApiError(e);
    // Only sign out for a 401 that was for the CURRENT token; a late 401 from an
    // old request must not log out a newer session.
    const sent = (e as AxiosError).config?.headers?.Authorization as string | undefined;
    const stale = !!sent && sent !== `Bearer ${handlers.getToken()}`;
    if (apiError.code === 'UNAUTHENTICATED' && !stale) handlers.onUnauthenticated();
    if (apiError.code === 'PLAN_EXPIRED' || apiError.code === 'PLAN_REQUIRED') {
      handlers.onPlanBlocked(apiError.code, apiError.message);
    }
    throw apiError;
  }
}

export const get = <T>(url: string, params?: Record<string, unknown>) => request<T>({ method: 'GET', url, params });
export const post = <T>(url: string, data?: unknown) => request<T>({ method: 'POST', url, data: data ?? {} });

/** Multipart upload; `file` is an image picked with expo-image-picker. */
export function postForm<T>(
  url: string,
  fields: Record<string, string | string[] | undefined>,
  file?: { field: string; uri: string; mime?: string | null; name?: string | null }
) {
  const form = new FormData();
  Object.entries(fields).forEach(([k, v]) => {
    if (v === undefined) return;
    if (Array.isArray(v)) v.forEach((item) => form.append(`${k}[]`, item));
    else form.append(k, v);
  });
  if (file) {
    form.append(file.field, {
      uri: file.uri,
      name: file.name ?? `${file.field}.jpg`,
      type: file.mime ?? 'image/jpeg',
    } as unknown as Blob);
  }
  return request<T>({ method: 'POST', url, data: form, headers: { 'Content-Type': 'multipart/form-data' } });
}

export const API_BASE_URL = baseURL;
export const getAuthToken = () => handlers.getToken();
