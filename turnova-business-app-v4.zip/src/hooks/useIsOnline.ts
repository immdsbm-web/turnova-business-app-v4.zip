import { useCallback, useEffect, useRef, useState } from 'react';
import * as Network from 'expo-network';

const POLL_INTERVAL_MS = 5000;

/**
 * expo-network's built-in `useNetworkState()` hook doesn't reliably push
 * updates on every platform/Expo Go combination, so this polls
 * `getNetworkStateAsync()` on an interval instead — simple, Expo-Go-safe,
 * and gives the offline screen's "Try Again" button something concrete to
 * trigger (an immediate re-check rather than waiting for the next tick).
 */
export function useIsOnline() {
  const [isOnline, setIsOnline] = useState(true);
  const mounted = useRef(true);

  const check = useCallback(async () => {
    try {
      const state = await Network.getNetworkStateAsync();
      const online = Boolean(state.isConnected && (state.isInternetReachable ?? true));
      if (mounted.current) setIsOnline(online);
    } catch {
      // If the check itself fails, don't flip to offline on a false
      // negative — leave the last known state alone.
    }
  }, []);

  useEffect(() => {
    mounted.current = true;
    check();
    const id = setInterval(check, POLL_INTERVAL_MS);
    return () => {
      mounted.current = false;
      clearInterval(id);
    };
  }, [check]);

  return { isOnline, recheck: check };
}
