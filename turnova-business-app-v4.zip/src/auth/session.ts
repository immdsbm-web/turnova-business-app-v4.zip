import * as SecureStore from 'expo-secure-store';
import { create } from 'zustand';
import { configureApi } from '@/src/api/client';
import { fetchMe, logout as apiLogout } from '@/src/api/business';
import { LoginResult, Me, PlanState } from '@/src/api/types';

const TOKEN_KEY = 'sqb_token';

type SessionState = {
  /** false until the saved token has been read from secure storage. */
  hydrated: boolean;
  token: string | null;
  me: Me | null;
  /** Set when the API answered "plan expired / required" (402). */
  planBlockedMessage: string | null;

  hydrate: () => Promise<void>;
  signIn: (result: LoginResult) => Promise<void>;
  signOut: () => Promise<void>;
  refreshMe: () => Promise<void>;
  clearPlanBlocked: () => void;
};

export const useSession = create<SessionState>((set, get) => ({
  hydrated: false,
  token: null,
  me: null,
  planBlockedMessage: null,

  async hydrate() {
    try {
      const token = await SecureStore.getItemAsync(TOKEN_KEY);
      set({ token });
      if (token) {
        try {
          set({ me: await fetchMe() });
        } catch {
          // A 401 clears the session through the API client's handler.
        }
      }
    } finally {
      set({ hydrated: true });
    }
  },

  async signIn(result) {
    const { token, ...me } = result;
    await SecureStore.setItemAsync(TOKEN_KEY, token);
    set({ token, me, planBlockedMessage: null });
  },

  async signOut() {
    const token = get().token;
    set({ token: null, me: null, planBlockedMessage: null });
    await SecureStore.deleteItemAsync(TOKEN_KEY).catch(() => {});
    if (token) {
      // Best effort: revoke the token on the server (needs the old token, so send it directly).
      try {
        set({ token });
        await apiLogout();
      } catch {
        // ignore: the token is already forgotten on this phone
      } finally {
        set({ token: null });
      }
    }
  },

  async refreshMe() {
    if (!get().token) return;
    const me = await fetchMe();
    set((s) => ({
      me,
      // A running plan clears any old "expired" block.
      planBlockedMessage: me.plan.state === 'trial' || me.plan.state === 'active' ? null : s.planBlockedMessage,
    }));
  },

  clearPlanBlocked: () => set({ planBlockedMessage: null }),
}));

configureApi({
  getToken: () => useSession.getState().token,
  onUnauthenticated: () => {
    if (useSession.getState().token) {
      SecureStore.deleteItemAsync(TOKEN_KEY).catch(() => {});
      useSession.setState({ token: null, me: null });
    }
  },
  onPlanBlocked: (_code, message) => useSession.setState({ planBlockedMessage: message }),
});

export const isPlanRunning = (state: PlanState | undefined): boolean => state === 'trial' || state === 'active';
