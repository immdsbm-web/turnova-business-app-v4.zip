// One shared set of screen-transition settings so every navigator in the app
// animates the same way. These are native animations (react-native-screens),
// so they run on the UI thread and stay smooth even while a screen is busy
// loading data.
//
// - slide: moving forward/back inside a flow (login -> OTP -> profile ->
//   address, business details, booking, settings sub-pages, ...).
// - fade: swapping between whole areas (splash -> login/home, login -> app,
//   logout -> login), where a sideways slide would feel wrong.
// - tab: switching between the bottom tabs.
//
// Android's native durations are fixed by the OS animation resources;
// `animationDuration` only applies on iOS.

export const slideTransition = {
  animation: 'slide_from_right' as const,
};

export const fadeTransition = {
  animation: 'fade' as const,
  animationDuration: 250,
};

export const tabTransition = {
  animation: 'fade' as const,
};
