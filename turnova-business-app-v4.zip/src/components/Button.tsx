import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View, ViewStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/src/theme';

type Variant = 'primary' | 'secondary' | 'outline' | 'destructive-outline' | 'ghost';

type Props = {
  label: string;
  onPress: () => void;
  variant?: Variant;
  /** 'md' = main actions (54 px); 'sm' = compact actions inside rows and sheets (40 px). */
  size?: 'md' | 'sm';
  loading?: boolean;
  disabled?: boolean;
  style?: ViewStyle;
  testID?: string;
  icon?: keyof typeof Ionicons.glyphMap;
};

/**
 * primary      solid emerald -- the one main action on a screen
 * secondary    soft emerald tint -- supporting actions
 * outline      same mint tint as secondary (the Customer app's outline button)
 * destructive-outline   red text + thin red border -- delete / cancel / no-show
 * ghost        text only -- low-emphasis links
 */
export function Button({ label, onPress, variant = 'primary', size = 'md', loading = false, disabled = false, style, testID, icon }: Props) {
  const { colors, radii, typography, spacing } = useTheme();
  const isDisabled = disabled || loading;
  const compact = size === 'sm';

  // Same palette as the Customer app: solid emerald, mint "outline", soft red destructive, text link.
  let backgroundColor = colors.primary;
  let pressedBg = colors.primaryDark;
  let textColor = colors.primaryText;

  switch (variant) {
    case 'secondary':
    case 'outline':
      backgroundColor = colors.primaryContainer;
      pressedBg = colors.primaryContainer;
      textColor = colors.primary;
      break;
    case 'destructive-outline':
      backgroundColor = colors.dangerBg;
      pressedBg = colors.dangerBg;
      textColor = colors.dangerText;
      break;
    case 'ghost':
      backgroundColor = 'transparent';
      pressedBg = 'transparent';
      textColor = colors.primary;
      break;
  }

  return (
    <Pressable
      testID={testID}
      onPress={onPress}
      disabled={isDisabled}
      accessibilityRole="button"
      accessibilityState={{ disabled: isDisabled, busy: loading }}
      style={({ pressed }) => [
        styles.base,
        {
          backgroundColor: pressed && !isDisabled ? pressedBg : backgroundColor,
          borderRadius: compact ? 12 : radii.button,
          height: variant === 'ghost' ? 44 : compact ? 40 : 54,
          paddingHorizontal: compact ? spacing.md : spacing.lg,
          opacity: disabled && !loading ? 0.4 : loading ? 0.85 : pressed && variant !== 'primary' ? 0.8 : 1,
        },
        style,
      ]}
    >
      <View style={styles.content}>
        {loading ? <ActivityIndicator size="small" color={textColor} style={{ marginRight: spacing.sm }} /> : null}
        {icon && !loading ? <Ionicons name={icon} size={compact ? 16 : 20} color={textColor} style={{ marginRight: 8 }} /> : null}
        <Text style={[typography.button, compact && { fontSize: 14, lineHeight: 20 }, { color: textColor }]} numberOfLines={1}>{label}</Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: { width: '100%', alignItems: 'center', justifyContent: 'center' },
  content: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
});
