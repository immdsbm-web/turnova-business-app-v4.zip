import React, { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Avatar } from '@/src/components/Avatar';
import { PhotoSheet, PickedPhoto } from '@/src/components/PhotoSheet';
import { useTheme } from '@/src/theme';

type Props = {
  /** Image shown in the circle (a picked local uri, a saved url, or null for initials). */
  uri: string | null;
  /** Used for the initial when there is no picture. */
  initialName: string;
  title: string;
  subtitle?: string;
  photoLabel: string;
  onPicked: (p: PickedPhoto) => void;
  onRemove?: () => void;
};

/**
 * The Customer App's Edit Profile header: 72 px picture with a camera badge,
 * title and one line of detail beside it. Tapping opens the photo sheet.
 */
export function ProfileHeader({ uri, initialName, title, subtitle, photoLabel, onPicked, onRemove }: Props) {
  const { colors, typography } = useTheme();
  const [open, setOpen] = useState(false);
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
      <Pressable onPress={() => setOpen(true)} accessibilityRole="button" accessibilityLabel={`Change ${photoLabel}`} style={{ position: 'relative' }}>
        <Avatar uri={uri} name={initialName} size={72} />
        <View style={{ position: 'absolute', bottom: -2, right: -2, width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center', borderWidth: 2, backgroundColor: colors.primary, borderColor: colors.background }}>
          <Ionicons name="camera" size={14} color={colors.primaryText} />
        </View>
      </Pressable>
      <View style={{ marginLeft: 16, flex: 1 }}>
        <Text style={[typography.h2, { color: colors.textPrimary }]} numberOfLines={1}>{title}</Text>
        {subtitle ? <Text style={[typography.caption, { color: colors.textSecondary }]} numberOfLines={1}>{subtitle}</Text> : null}
      </View>
      <PhotoSheet visible={open} onClose={() => setOpen(false)} aspect={[1, 1]} onPicked={onPicked} onRemove={uri ? onRemove : undefined} />
    </View>
  );
}
