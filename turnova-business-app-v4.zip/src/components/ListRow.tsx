import React from 'react';
import { Pressable, Text, View } from 'react-native';
import { useTheme } from '@/src/theme';
import { Avatar } from './Avatar';
import { StatusBadge } from './StatusBadge';

type Props = {
  /** Image URL for the tile; falls back to the first letter of `name`. */
  uri?: string | null;
  /** Used for the initial on the tile. */
  name?: string | null;
  /** Custom tile instead of the avatar (e.g. an icon tile). */
  tile?: React.ReactNode;
  title: string;
  /** Up to a few caption lines under the title. Falsy entries are skipped. */
  lines?: Array<string | null | undefined | false>;
  /** Status key shown as a pill at the right of the title. */
  status?: string;
  statusLabel?: string;
  /** Anything shown at the right of the title instead of / next to the pill. */
  right?: React.ReactNode;
  /** Content below the lines (e.g. inline action buttons). */
  footer?: React.ReactNode;
  onPress?: () => void;
  /** Hide the thin divider under the row (last row in a list). */
  last?: boolean;
  dim?: boolean;
};

/**
 * One list row used by Bookings, Services, Staff, Holiday, Reviews and Appointments:
 * 48 dp square tile, title + pill on the first line, caption lines below, thin grey
 * divider. Same row as the Customer app's My Bookings list.
 */
export function ListRow({ uri, name, tile, title, lines = [], status, statusLabel, right, footer, onPress, last, dim }: Props) {
  const { colors, typography } = useTheme();
  const body = (
    <View style={{ flexDirection: 'row', alignItems: 'flex-start', paddingVertical: 14, opacity: dim ? 0.6 : 1 }}>
      {tile ?? <Avatar uri={uri} name={name ?? title} size={48} shape="tile" />}
      <View style={{ flex: 1, marginLeft: 14 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Text style={[typography.titleSmall, { color: colors.textPrimary, flex: 1, marginRight: 8 }]} numberOfLines={1}>{title}</Text>
          {status ? <StatusBadge status={status} label={statusLabel} /> : null}
          {right}
        </View>
        {lines.filter(Boolean).map((l, i) => (
          <Text key={i} style={[typography.caption, { color: i === 0 ? colors.textSecondary : colors.textPrimary }]} numberOfLines={2}>{l as string}</Text>
        ))}
        {footer}
      </View>
    </View>
  );
  const divider = last ? undefined : { borderBottomWidth: 1, borderBottomColor: colors.border };
  if (!onPress) return <View style={divider}>{body}</View>;
  return (
    <Pressable onPress={onPress} accessibilityRole="button" style={({ pressed }) => [divider, { opacity: pressed ? 0.7 : 1 }]}>
      {body}
    </Pressable>
  );
}
