import React from 'react';
import { Pressable, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useTheme } from '@/src/theme';

type IconName = keyof typeof Ionicons.glyphMap;
export type QuickAction = { icon: IconName; label: string; to: string; badge?: number };

/** The four owner shortcuts. Same list on Home and Manage so they never drift apart. */
export function quickActions(flaggedForReassignment?: number): QuickAction[] {
  return [
    { icon: 'qr-code-outline', label: 'Verification QR', to: '/more/qr' },
    { icon: 'cut-outline', label: 'Service', to: '/more/services' },
    { icon: 'person-add-outline', label: 'Staff', to: '/more/staff', badge: flaggedForReassignment },
    { icon: 'sunny-outline', label: 'Holiday', to: '/more/holiday' },
  ];
}

const LABEL_LINES = 2;

// Android's Inter renders the "ff" in "Staff" as one ligature glyph that is measured too wide, so the
// word wrapped as "Staf / f". A zero-width non-joiner between the two f's prevents the ligature.
const ZWNJ = '\u200C';
export const quickLabel = (label: string) => label.replace('ff', 'f' + ZWNJ + 'f');

/**
 * Four equal columns. Every tile has the same icon size, the same label size
 * and a fixed label height (room for two lines), so "Verification QR" wrapping
 * never changes the layout and "Staff" never breaks mid-word.
 */
export function QuickActionsRow({ items, variant }: { items: QuickAction[]; variant: 'card' | 'circle' }) {
  const { colors, typography, spacing, radii } = useTheme();
  const router = useRouter();
  const labelStyle = [typography.caption, { color: colors.textPrimary, fontFamily: 'Inter_600SemiBold', textAlign: 'center' as const, fontSize: 12, lineHeight: 16, height: 16 * LABEL_LINES }];
  return (
    <View style={{ flexDirection: 'row', gap: variant === 'card' ? spacing.sm + 2 : 6 }}>
      {items.map((q) => {
        const icon = (
          <View
            style={
              variant === 'card'
                ? { width: 44, height: 44, borderRadius: 14, backgroundColor: colors.primaryContainer, alignItems: 'center', justifyContent: 'center' }
                : { width: 56, height: 56, borderRadius: 28, backgroundColor: colors.primaryContainer, alignItems: 'center', justifyContent: 'center' }
            }
          >
            <Ionicons name={q.icon} size={24} color={colors.primary} />
            {q.badge ? (
              <View style={{ position: 'absolute', top: -2, right: -2, minWidth: 18, height: 18, borderRadius: 9, backgroundColor: colors.danger, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 4 }}>
                <Text style={{ color: '#fff', fontSize: 10, fontFamily: 'Inter_700Bold' }}>{q.badge}</Text>
              </View>
            ) : null}
          </View>
        );
        return (
          <Pressable
            key={q.label}
            onPress={() => router.push(q.to as never)}
            accessibilityRole="button"
            accessibilityLabel={q.label}
            style={{ flex: 1, minWidth: 0 }}
          >
            {variant === 'card' ? (
              <View
                style={{
                  alignItems: 'center', gap: spacing.sm, paddingTop: spacing.md, paddingBottom: spacing.sm + 2, paddingHorizontal: 2,
                  backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: radii.card,
                }}
              >
                {icon}
                <Text style={labelStyle} numberOfLines={LABEL_LINES}>{quickLabel(q.label)}</Text>
              </View>
            ) : (
              <View style={{ alignItems: 'center', gap: 8 }}>
                {icon}
                <Text style={labelStyle} numberOfLines={LABEL_LINES}>{quickLabel(q.label)}</Text>
              </View>
            )}
          </Pressable>
        );
      })}
    </View>
  );
}
