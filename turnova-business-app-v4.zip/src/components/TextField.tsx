import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, TextInputProps, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/src/theme';

type Props = TextInputProps & {
  label: string;
  error?: string | null;
  /** Fixed text shown before the input, e.g. "+91" for phone fields. */
  prefix?: string;
  /** Optional leading icon shown before the input. */
  icon?: keyof typeof Ionicons.glyphMap;
  /** Optional element shown at the end of the field (e.g. the show/hide password toggle). */
  right?: React.ReactNode;
};

/**
 * Same field as the Customer app: label above, 52 dp soft-filled input (radius 14).
 * Focus draws a 1 dp emerald border on a white fill with a soft mint ring; errors
 * use a red border on a red tint with the message below.
 */
export function TextField({ label, error, prefix, icon, right, style, onFocus, onBlur, multiline, ...inputProps }: Props) {
  const { colors, typography, spacing, radii } = useTheme();
  const [isFocused, setIsFocused] = useState(false);

  const borderColor = error ? colors.danger : isFocused ? colors.primary : 'transparent';
  const backgroundColor = error ? colors.dangerBg : isFocused ? colors.surface : colors.neutralBg;

  return (
    <View>
      <Text style={[typography.label, { color: colors.textSecondary, marginBottom: 6 }]}>{label}</Text>
      {/* Mint "focus ring": a slightly larger tinted layer behind the field. */}
      <View style={{ margin: -3, padding: 3, borderRadius: radii.input + 3, backgroundColor: isFocused && !error ? colors.primaryContainer : 'transparent' }}>
        <View
          style={[
            styles.box,
            {
              borderColor,
              backgroundColor,
              borderRadius: radii.input,
              paddingHorizontal: 16,
              minHeight: multiline ? 96 : 52,
              alignItems: multiline ? 'flex-start' : 'center',
            },
          ]}
        >
          {icon ? <Ionicons name={icon} size={18} color={colors.textMuted} style={{ marginRight: spacing.sm }} /> : null}
          {prefix ? <Text style={[typography.body, { color: colors.textPrimary, marginRight: spacing.xs }]}>{prefix}</Text> : null}
          <TextInput
            {...inputProps}
            multiline={multiline}
            placeholderTextColor={colors.textMuted}
            selectionColor={colors.primary}
            onFocus={(e) => {
              setIsFocused(true);
              onFocus?.(e);
            }}
            onBlur={(e) => {
              setIsFocused(false);
              onBlur?.(e);
            }}
            style={[typography.body, styles.input, { color: colors.textPrimary, fontSize: 16 }, multiline && { textAlignVertical: 'top', paddingVertical: 14 }, style]}
          />
          {right}
        </View>
      </View>
      {error ? <Text style={[typography.caption, { color: colors.dangerText, marginTop: 6, fontSize: 12 }]}>{error}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  box: { flexDirection: 'row', borderWidth: 1 },
  input: { flex: 1, paddingVertical: 0 },
});
