import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import NoConnection from '@/src/assets/illustrations/No_connection-pana.svg';
import { Button } from './Button';
import { useTheme } from '@/src/theme';

type Props = {
  onRetry: () => void;
  title?: string;
  subtitle?: string;
};

export function OfflineScreen({ onRetry, title = 'No Internet Connection', subtitle = 'Check your connection and try again.' }: Props) {
  const { colors, typography, spacing } = useTheme();
  return (
    <View style={[styles.container, { backgroundColor: colors.background, padding: spacing.xl }]}>
      <NoConnection width={220} height={220} />
      <Text
        style={[
          typography.h1,
          { color: colors.textPrimary, marginTop: spacing.xl, marginBottom: spacing.sm },
        ]}
      >
        {title}
      </Text>
      <Text
        style={[
          typography.body,
          { color: colors.textSecondary, textAlign: 'center', marginBottom: spacing.xxl },
        ]}
      >
        {subtitle}
      </Text>
      <Button label="Try Again" onPress={onRetry} style={{ maxWidth: 240 }} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
