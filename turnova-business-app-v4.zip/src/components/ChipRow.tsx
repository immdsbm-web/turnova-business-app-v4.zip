import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/src/theme';

export type ChipItem<T> = { value: T; label: string; icon?: keyof typeof Ionicons.glyphMap };

type Props<T> = {
  items: ChipItem<T>[];
  selected: T;
  onSelect: (value: T) => void;
  /** Optional override when chips aren't a single-select group (multi-select days, services ...). */
  isSelected?: (value: T) => boolean;
};

/**
 * Horizontally scrolling choice chips, same look as the Customer app: white chip with
 * a thin grey border; selected = 2 dp emerald border and emerald semibold label (the
 * chip keeps exactly the same size: border +1, horizontal padding -1).
 */
export function ChipRow<T,>({ items, selected, onSelect, isSelected: isSelectedFn }: Props<T>) {
  const { colors, typography, radii, spacing } = useTheme();

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      // Only as tall as its chips; bleeds to the screen edges so scrolling feels natural.
      style={{ flexGrow: 0, marginHorizontal: -spacing.xl }}
      contentContainerStyle={{ paddingHorizontal: spacing.xl, paddingVertical: 2, gap: spacing.sm }}
    >
      {items.map((item, index) => {
        const isSelected = isSelectedFn ? isSelectedFn(item.value) : item.value === selected;
        const fg = isSelected ? colors.primary : colors.textPrimary;
        return (
          <Pressable
            key={index}
            onPress={() => onSelect(item.value)}
            accessibilityRole="button"
            accessibilityState={{ selected: isSelected }}
            style={[
              styles.chip,
              {
                borderRadius: radii.chip,
                backgroundColor: colors.surface,
                borderColor: isSelected ? colors.primary : colors.border,
                borderWidth: isSelected ? 2 : 1,
                paddingHorizontal: isSelected ? 13 : 14,
              },
            ]}
          >
            {item.icon ? <Ionicons name={item.icon} size={16} color={fg} style={{ marginRight: 6 }} /> : null}
            <Text style={[isSelected ? typography.captionStrong : typography.caption, { color: fg, fontSize: 14 }]} numberOfLines={1}>
              {item.label}
            </Text>
          </Pressable>
        );
      })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  chip: { height: 36, alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', borderWidth: 1 },
});
