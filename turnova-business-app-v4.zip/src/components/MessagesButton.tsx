import React from 'react';
import { Pressable, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useTheme } from '@/src/theme';
import { useSession } from '@/src/auth/session';
import { useChatUnread } from '@/src/features/chat/useChatUnread';

/** Messages icon for the top-right of the main screens, with the unread count. */
export function MessagesButton({ color }: { color?: string }) {
  const { colors } = useTheme();
  const router = useRouter();
  // Unread INCOMING customer messages only (the server never counts our own or automatic notices).
  const badge = useSession((s) => s.me?.badges?.unread_messages);
  const unread = useChatUnread().data?.unread ?? badge ?? 0;

  return (
    <Pressable
      onPress={() => router.push('/messages')}
      accessibilityRole="button"
      accessibilityLabel={unread > 0 ? `Messages, ${unread} unread` : 'Messages'}
      hitSlop={8}
      style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center' }}
    >
      <Ionicons name="chatbubble-ellipses-outline" size={24} color={color ?? colors.textPrimary} />
      {unread > 0 ? (
        <View style={{ position: 'absolute', top: 2, right: 0, minWidth: 18, height: 18, borderRadius: 9, paddingHorizontal: 4, backgroundColor: colors.danger, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ color: '#fff', fontSize: 11, fontFamily: 'Inter_700Bold' }}>{unread > 99 ? '99+' : unread}</Text>
        </View>
      ) : null}
    </Pressable>
  );
}
