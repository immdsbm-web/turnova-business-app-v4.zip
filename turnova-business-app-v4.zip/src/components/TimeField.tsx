import React, { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/src/theme';
import { BottomSheet } from './BottomSheet';

type Period = 'AM' | 'PM';
type Part = 'hour' | 'minute' | 'period';

const pad = (n: number) => (n < 10 ? `0${n}` : String(n));

/** "14:30" -> { hour: 2, minute: 30, period: 'PM' } ; empty / invalid -> all null */
function split(value: string): { hour: number | null; minute: number | null; period: Period | null } {
  const m = /^(\d{1,2}):(\d{2})/.exec(value ?? '');
  if (!m) return { hour: null, minute: null, period: null };
  const h24 = Number(m[1]);
  return { hour: h24 % 12 === 0 ? 12 : h24 % 12, minute: Number(m[2]), period: h24 >= 12 ? 'PM' : 'AM' };
}

/** 12-hour parts -> "HH:MM" (24-hour), the format the server stores. */
function join(hour: number, minute: number, period: Period): string {
  return `${pad((hour % 12) + (period === 'PM' ? 12 : 0))}:${pad(minute)}`;
}

const HOURS = Array.from({ length: 12 }, (_, i) => ({ label: String(i + 1), value: i + 1 }));
const MINUTES = Array.from({ length: 60 }, (_, i) => ({ label: pad(i), value: i }));
const PERIODS: Array<{ label: Period; value: Period }> = [{ label: 'AM', value: 'AM' }, { label: 'PM', value: 'PM' }];

type Props = {
  label: string;
  /** Time as 24-hour "HH:MM" (what the server uses). Shown to the person in 12-hour AM/PM format. */
  value: string;
  onChange: (value24h: string) => void;
  error?: string | null;
};

/**
 * 12-hour time picker (hour : minute AM/PM) -- the same three choices as the
 * website's time picker. Each box opens a list to pick from.
 */
export function TimeField({ label, value, onChange, error }: Props) {
  const { colors, typography, spacing, radii } = useTheme();
  const [open, setOpen] = useState<Part | null>(null);
  const parts = split(value);

  const choose = (part: Part, picked: number | Period) => {
    const hour = part === 'hour' ? (picked as number) : parts.hour ?? 12;
    const minute = part === 'minute' ? (picked as number) : parts.minute ?? 0;
    const period = part === 'period' ? (picked as Period) : parts.period ?? 'AM';
    onChange(join(hour, minute, period));
    setOpen(null);
  };

  const box = (part: Part, text: string | null, flex: number, placeholder: string) => (
    <Pressable
      onPress={() => setOpen(part)}
      accessibilityRole="button"
      accessibilityLabel={`${label} ${part}`}
      style={[
        styles.box,
        { flex, borderColor: error ? colors.danger : colors.border, backgroundColor: colors.surface, borderRadius: radii.input },
      ]}
    >
      <Text style={[typography.body, { color: text ? colors.textPrimary : colors.textMuted, fontSize: 15 }]}>{text ?? placeholder}</Text>
      <Ionicons name="chevron-down" size={16} color={colors.textMuted} />
    </Pressable>
  );

  const sheetTitle = open === 'hour' ? 'Hour' : open === 'minute' ? 'Minute' : 'AM or PM';
  const options = open === 'hour' ? HOURS : open === 'minute' ? MINUTES : PERIODS;
  const current = open === 'hour' ? parts.hour : open === 'minute' ? parts.minute : parts.period;

  return (
    <View>
      <Text style={[typography.caption, { color: colors.textSecondary, marginBottom: 6, fontFamily: 'Inter_600SemiBold' }]}>{label}</Text>
      <View style={styles.row}>
        {box('hour', parts.hour != null ? String(parts.hour) : null, 1, 'Hr')}
        <Text style={[typography.h2, { color: colors.textSecondary }]}>:</Text>
        {box('minute', parts.minute != null ? pad(parts.minute) : null, 1, 'Min')}
        {box('period', parts.period, 1, 'AM/PM')}
      </View>
      {error ? <Text style={[typography.caption, { color: colors.danger, marginTop: 4 }]}>{error}</Text> : null}

      <BottomSheet visible={open !== null} onClose={() => setOpen(null)}>
        <View style={{ paddingHorizontal: spacing.xl, paddingTop: spacing.md, paddingBottom: spacing.xl }}>
          <Text style={[typography.h2, { color: colors.textPrimary, marginBottom: spacing.sm }]}>{sheetTitle}</Text>
          <ScrollView style={{ maxHeight: 340 }} showsVerticalScrollIndicator={false}>
            {options.map((o) => {
              const selected = o.value === current;
              return (
                <Pressable
                  key={String(o.value)}
                  onPress={() => open && choose(open, o.value as number | Period)}
                  accessibilityRole="button"
                  accessibilityState={{ selected }}
                  style={[styles.option, { borderBottomColor: colors.border, backgroundColor: selected ? colors.primaryContainer : 'transparent' }]}
                >
                  <Text style={[typography.body, { color: selected ? colors.primaryDark : colors.textPrimary, fontFamily: selected ? 'Inter_700Bold' : 'Inter_400Regular', fontSize: 16, flex: 1 }]}>{o.label}</Text>
                  {selected ? <Ionicons name="checkmark" size={18} color={colors.primaryDark} /> : null}
                </Pressable>
              );
            })}
          </ScrollView>
        </View>
      </BottomSheet>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  box: { minHeight: 48, borderWidth: 1, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  option: { flexDirection: 'row', alignItems: 'center', paddingVertical: 13, paddingHorizontal: 12, borderBottomWidth: StyleSheet.hairlineWidth, borderRadius: 8 },
});
