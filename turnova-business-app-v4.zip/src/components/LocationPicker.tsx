import React, { useMemo, useRef, useState } from 'react';
import { Text, View } from 'react-native';
import Constants from 'expo-constants';
import * as Location from 'expo-location';
import { WebView, WebViewMessageEvent } from 'react-native-webview';
import { useTheme } from '@/src/theme';
import { Button } from './Button';

type Props = {
  /** Where the pin starts (text, e.g. "17.385044"); empty = no location yet, map shows India. */
  initialLat: string;
  initialLng: string;
  /** Called with 7-decimal strings, from the GPS button OR from tapping / dragging on the map. */
  onChange: (lat: string, lng: string) => void;
  error?: string | null;
};

// Same behaviour and settings as the website's pin-drop map (assets/js/location-capture.js):
// Leaflet 1.9.4, OpenStreetMap tiles, centred on India until a location exists,
// tap the map or drag the pin to set the location.
const LEAFLET_CSS = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
const LEAFLET_JS = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';

function buildHtml(lat: number | null, lng: number | null): string {
  const start = JSON.stringify({ lat, lng });
  return `<!DOCTYPE html>
<html><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="referrer" content="strict-origin-when-cross-origin">
<link rel="stylesheet" href="${LEAFLET_CSS}">
<style>
  html, body, #map { height: 100%; margin: 0; padding: 0; }
  body { font-family: -apple-system, Roboto, sans-serif; background: #e9e6df; }
  .msg { padding: 18px; color: #5B6270; font-size: 14px; line-height: 1.4; }
</style>
</head><body>
<div id="map"><div class="msg">Loading map…</div></div>
<script src="${LEAFLET_JS}"></script>
<script>
(function () {
  var DEFAULT_CENTER = [22.9734, 78.6569]; // India
  var DEFAULT_ZOOM = 5;
  var PINNED_ZOOM = 15;
  var start = ${start};
  function post(o) { window.ReactNativeWebView.postMessage(JSON.stringify(o)); }

  if (typeof L === 'undefined') {
    document.getElementById('map').innerHTML = '<div class="msg">Map couldn\\'t load (check your internet connection). You can still use "Use my current location" above.</div>';
    post({ type: 'error' });
    return;
  }
  document.getElementById('map').innerHTML = '';

  var hasExisting = start.lat !== null && start.lng !== null;
  var map = L.map('map').setView(hasExisting ? [start.lat, start.lng] : DEFAULT_CENTER, hasExisting ? PINNED_ZOOM : DEFAULT_ZOOM);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    maxZoom: 19
  }).addTo(map);

  var marker = null;
  function placeMarker(lat, lng, recenter) {
    var latlng = L.latLng(lat, lng);
    if (marker) {
      marker.setLatLng(latlng);
    } else {
      marker = L.marker(latlng, { draggable: true }).addTo(map);
      marker.on('dragend', function () {
        var p = marker.getLatLng();
        post({ type: 'location', lat: p.lat, lng: p.lng });
      });
    }
    if (recenter) map.setView(latlng, Math.max(map.getZoom(), PINNED_ZOOM));
  }
  if (hasExisting) placeMarker(start.lat, start.lng, false);

  map.on('click', function (e) {
    placeMarker(e.latlng.lat, e.latlng.lng, false);
    post({ type: 'location', lat: e.latlng.lat, lng: e.latlng.lng });
  });

  // Called by the app when the GPS button sets the location, so the pin follows.
  window.moveMarker = function (lat, lng) { placeMarker(lat, lng, true); };

  setTimeout(function () { map.invalidateSize(); }, 200);
  window.addEventListener('resize', function () { map.invalidateSize(); });
  post({ type: 'ready' });
})();
</script>
</body></html>`;
}

const toNum = (v: string): number | null => {
  const n = parseFloat(v);
  return v.trim() !== '' && Number.isFinite(n) ? n : null;
};

/**
 * "Use my current location" button + the website's Leaflet pin-drop map, with
 * the same status messages. Used on Register and Edit business.
 */
export function LocationPicker({ initialLat, initialLng, onChange, error }: Props) {
  const { colors, typography, spacing, radii } = useTheme();
  const webRef = useRef<WebView>(null);
  const [hasLocation, setHasLocation] = useState(toNum(initialLat) !== null && toNum(initialLng) !== null);
  const [busy, setBusy] = useState(false);
  const [problem, setProblem] = useState<string | null>(null);
  const [mapFailed, setMapFailed] = useState(false);

  // Built once: later pin moves must not reload the page.
  const html = useMemo(() => buildHtml(toNum(initialLat), toNum(initialLng)), []); // eslint-disable-line react-hooks/exhaustive-deps
  const origin = ((Constants.expoConfig?.extra?.apiBaseUrl as string) ?? '').replace(/\/api\/v1(\/business)?\/?$/, '');

  const setLocation = (lat: number, lng: number, fromMap: boolean) => {
    onChange(lat.toFixed(7), lng.toFixed(7));
    setHasLocation(true);
    setProblem(null);
    if (!fromMap) webRef.current?.injectJavaScript(`window.moveMarker && window.moveMarker(${lat}, ${lng}); true;`);
  };

  const useGps = async () => {
    setBusy(true);
    setProblem(null);
    try {
      const perm = await Location.requestForegroundPermissionsAsync();
      if (!perm.granted) {
        setProblem('Location access was denied. Allow it in your phone settings, or drop a pin on the map below instead.');
        return;
      }
      const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      setLocation(pos.coords.latitude, pos.coords.longitude, false);
    } catch {
      setProblem('Your phone could not determine its location right now (no GPS or network signal). Try again in a moment, or drop a pin on the map below instead.');
    } finally {
      setBusy(false);
    }
  };

  const onMessage = (e: WebViewMessageEvent) => {
    try {
      const msg = JSON.parse(e.nativeEvent.data);
      if (msg.type === 'location') setLocation(Number(msg.lat), Number(msg.lng), true);
      if (msg.type === 'error') setMapFailed(true);
    } catch {
      // ignore malformed messages
    }
  };

  const statusText = problem
    ?? (hasLocation
      ? 'Location set — customers will be able to find you in Nearby search.'
      : 'Required so customers can find you in Nearby search. Use "Use my current location" or drop a pin on the map below.');
  const statusColor = problem || error ? colors.danger : hasLocation ? colors.success : colors.textSecondary;

  return (
    <View style={{ gap: spacing.md }}>
      <Text style={[typography.body, { color: statusColor }]}>{statusText}</Text>
      {error && !problem ? <Text style={[typography.caption, { color: colors.danger }]}>{error}</Text> : null}

      <Button label={busy ? 'Getting your location…' : 'Use my current location'} icon="locate-outline" variant="outline" loading={busy} onPress={useGps} />

      <Text style={[typography.caption, { color: colors.textSecondary }]}>Or tap the map (or drag the pin) to set your location manually:</Text>
      <View style={{ height: 300, borderRadius: radii.card, overflow: 'hidden', borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surfaceAlt }}>
        <WebView
          ref={webRef}
          source={{ html, baseUrl: origin || 'https://localhost' }}
          originWhitelist={['*']}
          javaScriptEnabled
          domStorageEnabled
          scrollEnabled={false}
          nestedScrollEnabled
          overScrollMode="never"
          onMessage={onMessage}
          onError={() => setMapFailed(true)}
          onHttpError={() => setMapFailed(true)}
          style={{ backgroundColor: 'transparent' }}
        />
      </View>
      {mapFailed ? (
        <Text style={[typography.caption, { color: colors.textSecondary }]}>
          The map couldn't load (check your internet connection). You can still use "Use my current location".
        </Text>
      ) : null}
    </View>
  );
}
