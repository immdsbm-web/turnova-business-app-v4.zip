import React, { useEffect, useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { BottomSheet } from '@/src/components/BottomSheet';
import { Button } from '@/src/components/Button';
import { toYmd } from '@/src/components/DateStrip';
import { useTheme } from '@/src/theme';

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const WD = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

type Props = {
  visible: boolean;
  title?: string;
  /** Currently selected date (YYYY-MM-DD) or null. */
  value: string | null;
  /** Earliest selectable date. Leave undefined to allow past dates. */
  min?: string;
  /** Dates to mark with a dot (e.g. existing holidays). */
  marks?: string[];
  onClose: () => void;
  onPick?: (ymd: string) => void;
  /** Range mode: pick a start and an end date, with quick presets. */
  range?: boolean;
  rangeValue?: { from: string; to: string } | null;
  onPickRange?: (from: string, to: string) => void;
  onClearRange?: () => void;
};

function parse(ymd: string) { const [y, m, d] = ymd.split('-').map(Number); return new Date(y, m - 1, d); }

/** Month-grid date picker in a bottom sheet. No native date-picker dependency. */
export function CalendarSheet({ visible, title = 'Select date', value, min, marks, onClose, onPick, range, rangeValue, onPickRange, onClearRange }: Props) {
  const { colors, typography, spacing, radii } = useTheme();
  const todayYmd = toYmd(new Date());
  const [pick, setPick] = useState<string | null>(value);
  // Range mode: `pick` is the start; `pickEnd` is the end (null while the second tap is pending).
  const [pickEnd, setPickEnd] = useState<string | null>(null);
  const base = parse((range ? rangeValue?.from : value) ?? value ?? todayYmd);
  const [view, setView] = useState(new Date(base.getFullYear(), base.getMonth(), 1));

  useEffect(() => {
    if (visible) {
      const b = parse((range ? rangeValue?.from : value) ?? value ?? todayYmd);
      setPick(range ? rangeValue?.from ?? null : value);
      setPickEnd(range ? rangeValue?.to ?? null : null);
      setView(new Date(b.getFullYear(), b.getMonth(), 1));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible]);

  const first = view.getDay();
  const days = new Date(view.getFullYear(), view.getMonth() + 1, 0).getDate();
  const cells: Array<number | null> = [...Array(first).fill(null), ...Array.from({ length: days }, (_, i) => i + 1)];
  while (cells.length % 7) cells.push(null);
  const tap = (ymd: string) => {
    if (!range) { setPick(ymd); return; }
    if (!pick || pickEnd) { setPick(ymd); setPickEnd(null); return; }
    if (ymd < pick) { setPickEnd(pick); setPick(ymd); } else setPickEnd(ymd);
  };
  const addDays = (ymd: string, n: number) => { const d = parse(ymd); d.setDate(d.getDate() + n); return toYmd(d); };
  const presets: Array<{ label: string; from: string; to: string }> = (() => {
    const t = parse(todayYmd);
    const mFirst = new Date(t.getFullYear(), t.getMonth(), 1);
    const mLast = new Date(t.getFullYear(), t.getMonth() + 1, 0);
    const pFirst = new Date(t.getFullYear(), t.getMonth() - 1, 1);
    const pLast = new Date(t.getFullYear(), t.getMonth(), 0);
    return [
      { label: 'Last 7 days', from: addDays(todayYmd, -6), to: todayYmd },
      { label: 'This month', from: toYmd(mFirst), to: toYmd(mLast) },
      { label: 'Last month', from: toYmd(pFirst), to: toYmd(pLast) },
      { label: 'Next 30 days', from: todayYmd, to: addDays(todayYmd, 30) },
    ];
  })();
  const usePreset = (p: { from: string; to: string }) => {
    setPick(p.from); setPickEnd(p.to);
    const b = parse(p.from); setView(new Date(b.getFullYear(), b.getMonth(), 1));
  };
  const inRange = (ymd: string) => !!range && !!pick && !!pickEnd && ymd > pick && ymd < pickEnd;
  const move = (n: number) => setView(new Date(view.getFullYear(), view.getMonth() + n, 1));

  return (
    <BottomSheet visible={visible} onClose={onClose}>
      <View style={{ padding: spacing.lg, gap: spacing.md }}>
        <Text style={[typography.h2, { color: colors.textPrimary }]}>{title}</Text>
        {range ? (
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
            {presets.map((p) => {
              const on = pick === p.from && pickEnd === p.to;
              return (
                <Pressable key={p.label} onPress={() => usePreset(p)} accessibilityRole="button" accessibilityState={{ selected: on }}
                  style={{ minHeight: 36, paddingHorizontal: on ? 13 : 14, borderRadius: 18, alignItems: 'center', justifyContent: 'center', borderWidth: on ? 2 : 1, borderColor: on ? colors.primary : colors.border, backgroundColor: colors.surface }}>
                  <Text style={[on ? typography.captionStrong : typography.caption, { color: on ? colors.primary : colors.textPrimary }]}>{p.label}</Text>
                </Pressable>
              );
            })}
          </View>
        ) : null}
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Pressable onPress={() => move(-1)} accessibilityRole="button" accessibilityLabel="Previous month" style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name="chevron-back" size={20} color={colors.textPrimary} />
          </Pressable>
          <Text style={[typography.titleSmall, { color: colors.textPrimary, flex: 1, textAlign: 'center' }]}>{MONTHS[view.getMonth()]} {view.getFullYear()}</Text>
          <Pressable onPress={() => move(1)} accessibilityRole="button" accessibilityLabel="Next month" style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name="chevron-forward" size={20} color={colors.textPrimary} />
          </Pressable>
        </View>
        <View style={{ flexDirection: 'row' }}>
          {WD.map((w, i) => (
            <Text key={i} style={[typography.caption, { flex: 1, textAlign: 'center', color: colors.textMuted }]}>{w}</Text>
          ))}
        </View>
        {Array.from({ length: cells.length / 7 }, (_, r) => (
          <View key={r} style={{ flexDirection: 'row' }}>
            {cells.slice(r * 7, r * 7 + 7).map((d, c) => {
              if (!d) return <View key={c} style={{ flex: 1, height: 42 }} />;
              const ymd = toYmd(new Date(view.getFullYear(), view.getMonth(), d));
              const disabled = !!min && ymd < min;
              const sel = ymd === pick || (!!range && ymd === pickEnd);
              const mid = inRange(ymd);
              const isToday = ymd === todayYmd;
              return (
                <Pressable
                  key={c}
                  disabled={disabled}
                  onPress={() => tap(ymd)}
                  accessibilityRole="button"
                  accessibilityState={{ selected: sel, disabled }}
                  accessibilityLabel={ymd}
                  style={{ flex: 1, height: 42, alignItems: 'center', justifyContent: 'center' }}
                >
                  <View style={{ width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center', backgroundColor: sel ? colors.primary : mid ? colors.primaryContainer : 'transparent', borderWidth: isToday && !sel ? 1 : 0, borderColor: colors.primary, opacity: disabled ? 0.35 : 1 }}>
                    <Text style={[typography.bodyStrong, { color: sel ? colors.primaryText : colors.textPrimary }]}>{d}</Text>
                    {marks?.includes(ymd) && !sel ? <View style={{ position: 'absolute', bottom: 4, width: 4, height: 4, borderRadius: 2, backgroundColor: colors.warning }} /> : null}
                  </View>
                </Pressable>
              );
            })}
          </View>
        ))}
        {range && pick ? (
          <Text style={[typography.caption, { color: colors.textSecondary, textAlign: 'center' }]}>
            {pickEnd ? `${pick} to ${pickEnd}` : `${pick}: now pick the end date`}
          </Text>
        ) : null}
        <View style={{ flexDirection: 'row', gap: spacing.sm, marginTop: spacing.sm }}>
          <View style={{ flex: 1 }}>
            {range && rangeValue ? (
              <Button label="Clear" variant="outline" onPress={() => { onClearRange?.(); onClose(); }} />
            ) : (
              <Button label="Cancel" variant="outline" onPress={onClose} />
            )}
          </View>
          <View style={{ flex: 1 }}>
            <Button
              label="Apply"
              disabled={range ? !pick : !pick}
              onPress={() => {
                if (!pick) return;
                if (range) onPickRange?.(pick, pickEnd ?? pick);
                else onPick?.(pick);
                onClose();
              }}
            />
          </View>
        </View>
      </View>
    </BottomSheet>
  );
}
