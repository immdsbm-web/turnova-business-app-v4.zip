import React from 'react';
import { Image, View } from 'react-native';

/** The Turnova logo tile used on the sign-in screen (the app's "F" mark). */
export function BrandMark({ size = 64 }: { size?: number }) {
  return (
    <Image
      source={require('@/src/assets/brand-mark.png')}
      style={{ width: size, height: size, borderRadius: size * 0.29 }}
      resizeMode="cover"
    />
  );
}

/** Big round icon on a soft tinted disc, for status screens (pending approval, plan expired, payment result). */
export function StatusIcon({ children, tint }: { children: React.ReactNode; tint: string }) {
  return (
    <View style={{ width: 96, height: 96, borderRadius: 48, backgroundColor: tint, alignItems: 'center', justifyContent: 'center' }}>
      {children}
    </View>
  );
}
