import React from 'react';
import { RefreshControl, ScrollView, StyleProp, StyleSheet, Text, View, ViewStyle } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useTheme, TAB_BAR_CONTENT_CLEARANCE } from '@/src/theme';
import { BackButton } from './BackButton';

type Props = {
  title?: string;
  subtitle?: string;
  /** Show a back button (for screens pushed on the stack). */
  back?: boolean;
  /** Element on the right of the app bar. */
  right?: React.ReactNode;
  /** Leave room for the bottom tab bar. */
  tabs?: boolean;
  scroll?: boolean;
  refreshing?: boolean;
  onRefresh?: () => void;
  contentStyle?: StyleProp<ViewStyle>;
  /** Sticky footer pinned under the scrolling content (e.g. a Save button). */
  footer?: React.ReactNode;
  children: React.ReactNode;
};

/**
 * Standard page, same structure as the Customer app: a flat header on the page
 * background with no divider. Tab screens get the large 28 sp title with the
 * action on the right; pushed screens (back = true) get the back arrow and the
 * 18 sp app-bar title. An optional caption sits under the title.
 */
export function Screen({ title, subtitle, back, right, tabs, scroll = true, refreshing, onRefresh, contentStyle, footer, children }: Props) {
  const { colors, typography, spacing } = useTheme();
  const insets = useSafeAreaInsets();

  const bar = title ? (
    back ? (
      <View style={[styles.bar, { backgroundColor: colors.background, paddingTop: insets.top, paddingLeft: 8, paddingRight: 14, minHeight: 56 + insets.top }]}>
        <BackButton />
        <View style={{ flex: 1, marginLeft: 4 }}>
          <Text style={[typography.appBar, { color: colors.textPrimary }]} numberOfLines={1}>{title}</Text>
          {subtitle ? <Text style={[typography.caption, { color: colors.textSecondary }]} numberOfLines={1}>{subtitle}</Text> : null}
        </View>
        {right}
      </View>
    ) : (
      <View style={[styles.bar, { backgroundColor: colors.background, paddingTop: insets.top + 6, paddingLeft: spacing.xl, paddingRight: 14, paddingBottom: 8, minHeight: 60 + insets.top }]}>
        <View style={{ flex: 1 }}>
          <Text style={[typography.displayTitle, { color: colors.textPrimary }]} numberOfLines={1}>{title}</Text>
          {subtitle ? <Text style={[typography.caption, { color: colors.textSecondary }]} numberOfLines={1}>{subtitle}</Text> : null}
        </View>
        {right}
      </View>
    )
  ) : null;

  const bottom = tabs ? TAB_BAR_CONTENT_CLEARANCE + insets.bottom : footer ? spacing.xl : spacing.xxxl + insets.bottom;
  const topPad = title ? spacing.md : insets.top + spacing.lg;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      {bar}
      {scroll ? (
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={[{ paddingHorizontal: spacing.xl, paddingTop: topPad, paddingBottom: bottom, gap: spacing.md }, contentStyle]}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          refreshControl={onRefresh ? <RefreshControl refreshing={!!refreshing} onRefresh={onRefresh} tintColor={colors.primary} colors={[colors.primary]} /> : undefined}
        >
          {children}
        </ScrollView>
      ) : (
        <View style={[{ flex: 1, paddingHorizontal: spacing.xl, paddingTop: topPad, paddingBottom: bottom }, contentStyle]}>{children}</View>
      )}
      {footer ? (
        <View style={{ backgroundColor: colors.surface, borderTopWidth: 1, borderTopColor: colors.border, paddingHorizontal: spacing.xl, paddingTop: 12, paddingBottom: Math.max(insets.bottom, 12) }}>
          {footer}
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  bar: { flexDirection: 'row', alignItems: 'center' },
});
