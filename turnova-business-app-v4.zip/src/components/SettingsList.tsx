import React from 'react';
import { Pressable, Switch, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/src/theme';

type IconName = keyof typeof Ionicons.glyphMap;

/**
 * Settings rows in the Customer App's style: a plain green icon (27 dp in a
 * 32 dp box, no border or tile), the label, hairline dividers, no card.
 */
export function SettingsDivider() {
  const { colors } = useTheme();
  return <View style={{ height: 1, backgroundColor: colors.border }} />;
}

function IconBox({ name }: { name: IconName }) {
  const { colors } = useTheme();
  return (
    <View style={{ width: 32, height: 32, alignItems: 'center', justifyContent: 'center' }}>
      <Ionicons name={name} size={27} color={colors.primary} />
    </View>
  );
}

export function SettingsRow({ icon, label, onPress, badge }: { icon: IconName; label: string; onPress: () => void; badge?: number }) {
  const { colors, typography } = useTheme();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', minHeight: 56, paddingVertical: 10, opacity: pressed ? 0.7 : 1 })}
    >
      <IconBox name={icon} />
      <Text style={[typography.caption, { color: colors.textPrimary, flex: 1, marginLeft: 14, fontSize: 16, lineHeight: 22 }]}>{label}</Text>
      {badge && badge > 0 ? (
        <View style={{ minWidth: 20, height: 20, borderRadius: 10, backgroundColor: colors.danger, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 5, marginRight: 8 }}>
          <Text style={{ color: '#fff', fontSize: 11, fontFamily: 'Inter_700Bold' }}>{badge > 99 ? '99+' : badge}</Text>
        </View>
      ) : null}
      <Ionicons name="chevron-forward" size={20} color={colors.textSecondary} />
    </Pressable>
  );
}

export function SettingsSwitchRow({ icon, label, value, onValueChange }: { icon: IconName; label: string; value: boolean; onValueChange: () => void }) {
  const { colors, typography } = useTheme();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', minHeight: 56, paddingVertical: 10 }}>
      <IconBox name={icon} />
      <Text style={[typography.caption, { color: colors.textPrimary, flex: 1, marginLeft: 14, fontSize: 16, lineHeight: 22 }]}>{label}</Text>
      <Switch
        value={value}
        onValueChange={onValueChange}
        accessibilityLabel={label}
        trackColor={{ false: colors.border, true: colors.primary }}
        thumbColor={value ? colors.primaryText : '#FFFFFF'}
      />
    </View>
  );
}

/** Rows separated by hairlines inside a 20 dp page gutter. */
export function SettingsList({ children }: { children: React.ReactNode[] }) {
  const items = React.Children.toArray(children);
  return (
    <View style={{ paddingHorizontal: 4 }}>
      {items.map((c, i) => (
        <View key={i}>
          {i > 0 ? <SettingsDivider /> : null}
          {c}
        </View>
      ))}
    </View>
  );
}
