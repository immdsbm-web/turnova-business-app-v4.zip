import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/src/theme';

type Props = {
  rating: number; // 0-5, can be fractional in read-only mode
  size?: number;
  onChange?: (rating: number) => void; // presence makes it interactive
};

// Rating stars stay gold in every theme (they are not a brand-colour element).
const STAR_GOLD = '#F5A524';

export function StarRating({ rating, size = 20, onChange }: Props) {
  const { colors } = useTheme();
  const interactive = Boolean(onChange);

  // Interactive mode (the review-writing input) is an inherently whole-star
  // tap target, so it keeps the simple filled/outline-per-star rendering.
  if (interactive) {
    return (
      <View style={styles.row}>
        {[1, 2, 3, 4, 5].map((value) => {
          const filled = rating >= value;
          return (
            <Pressable key={value} onPress={() => onChange?.(value)} hitSlop={4}>
              <Ionicons
                name={filled ? 'star' : 'star-outline'}
                size={size}
                color={filled ? STAR_GOLD : colors.textMuted}
                style={styles.star}
              />
            </Pressable>
          );
        })}
      </View>
    );
  }

  // Read-only mode (aggregate rating summary, per-review rows) needs true
  // proportional/fractional fill — e.g. a 4.3 average fills the 5th star
  // ~30% of the way, not just the nearest whole/half star. Each star is
  // clipped by its own individual fill fraction (rating - i, clamped to
  // 0-1) rather than clipping the whole row by one overall width — the
  // same approach as the Flutter reference app's StarRatingDisplay —
  // since clipping the row as a whole would let the inter-star gaps eat
  // into the fill percentage instead of only the stars themselves.
  const clampedRating = Math.max(0, Math.min(5, rating));

  return (
    <View style={styles.row}>
      {[0, 1, 2, 3, 4].map((i) => {
        const fill = Math.max(0, Math.min(1, clampedRating - i));
        return (
          <View key={i} style={[styles.starSlot, { width: size, height: size, marginRight: i === 4 ? 0 : 2 }]}>
            <Ionicons name="star" size={size} color={colors.textMuted} style={styles.starBase} />
            <View style={[styles.starClip, { width: size * fill }]}>
              <Ionicons name="star" size={size} color={STAR_GOLD} style={styles.starBase} />
            </View>
          </View>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row' },
  star: { marginRight: 2 },
  starSlot: { position: 'relative' },
  starBase: { position: 'absolute', top: 0, left: 0 },
  starClip: {
    position: 'absolute',
    top: 0,
    left: 0,
    height: '100%',
    overflow: 'hidden',
  },
});
