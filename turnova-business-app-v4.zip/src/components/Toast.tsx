import React, { createContext, useCallback, useContext, useRef, useState } from 'react';
import { Animated, StyleSheet, Text } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useTheme } from '@/src/theme';
import { TAB_BAR_HEIGHT, TAB_BAR_MARGIN } from '@/src/theme/layout';

type ToastKind = 'success' | 'error' | 'info';
type ToastState = { id: number; message: string; kind: ToastKind } | null;

type ToastContextValue = {
  show: (message: string, kind?: ToastKind) => void;
};

const ToastContext = createContext<ToastContextValue | undefined>(undefined);

const DURATION_MS = 2500;

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toast, setToast] = useState<ToastState>(null);
  const opacity = useRef(new Animated.Value(0)).current;
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const { colors, typography, spacing } = useTheme();
  const insets = useSafeAreaInsets();

  const show = useCallback(
    (message: string, kind: ToastKind = 'info') => {
      if (hideTimer.current) clearTimeout(hideTimer.current);
      const id = Date.now();
      setToast({ id, message, kind });
      Animated.timing(opacity, { toValue: 1, duration: 200, useNativeDriver: true }).start();
      hideTimer.current = setTimeout(() => {
        Animated.timing(opacity, { toValue: 0, duration: 200, useNativeDriver: true }).start(() => {
          setToast((prev) => (prev?.id === id ? null : prev));
        });
      }, DURATION_MS);
    },
    [opacity],
  );

  const bg =
    toast?.kind === 'error' ? colors.danger : toast?.kind === 'success' ? colors.success : colors.inverse;

  return (
    <ToastContext.Provider value={{ show }}>
      {children}
      {toast ? (
        <Animated.View
          pointerEvents="none"
          style={[
            styles.toast,
            {
              opacity,
              // The floating tab bar sits at max(insets.bottom, TAB_BAR_MARGIN)
              // and is TAB_BAR_HEIGHT tall (see CustomTabBar), so the toast
              // must clear all of that plus a small visible gap — not just
              // the raw safe-area inset — or it renders behind/level with the
              // tab bar. ToastProvider is mounted once at the app root and
              // shown from screens both with and without the tab bar visible
              // underneath, so this offset is applied unconditionally rather
              // than per call site.
              bottom: Math.max(insets.bottom, TAB_BAR_MARGIN) + TAB_BAR_HEIGHT + 12,
              backgroundColor: bg,
              borderRadius: 10,
              paddingHorizontal: spacing.lg,
              paddingVertical: spacing.md,
            },
          ]}
        >
          <Text style={[typography.bodyStrong, { color: toast.kind === 'info' || !toast.kind ? colors.inverseText : '#FFFFFF' }]}>{toast.message}</Text>
        </Animated.View>
      ) : null}
    </ToastContext.Provider>
  );
}

export function useToast(): ToastContextValue {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within a ToastProvider');
  return ctx;
}

const styles = StyleSheet.create({
  toast: {
    position: 'absolute',
    left: 24,
    right: 24,
    alignItems: 'center',
  },
});
