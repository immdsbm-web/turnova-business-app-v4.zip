import React from 'react';
import { Alert, Pressable, Text, View } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import type { PickedPhoto } from '@/src/components/PhotoSheet';
import { useTheme } from '@/src/theme';
import { Avatar } from './Avatar';
import { Button } from './Button';
import { resolveImageUrl } from '@/src/utils/media';

export type { PickedPhoto } from '@/src/components/PhotoSheet';

type Props = {
  label: string;
  name?: string | null;
  currentUrl?: string | null;
  picked: PickedPhoto | null;
  removed?: boolean;
  onPick: (p: PickedPhoto) => void;
  /** Called when the user wants to clear the photo (current or picked). */
  onRemove?: () => void;
  size?: number;
};

/** Photo chooser with preview: pick from the gallery, or remove. */
export function PhotoField({ label, name, currentUrl, picked, removed, onPick, onRemove, size = 84 }: Props) {
  const { colors, typography, spacing } = useTheme();

  const choose = async () => {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('Permission needed', 'Allow photo access in your phone settings to choose a picture.');
      return;
    }
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });
    if (!res.canceled && res.assets[0]) {
      const a = res.assets[0];
      onPick({ uri: a.uri, mime: a.mimeType ?? 'image/jpeg', name: a.fileName ?? 'photo.jpg' });
    }
  };

  const shownUri = picked?.uri ?? (removed ? null : resolveImageUrl(currentUrl ?? null));

  return (
    <View style={{ gap: spacing.sm }}>
      <Text style={[typography.caption, { color: colors.textSecondary, fontFamily: 'Inter_600SemiBold' }]}>{label}</Text>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.lg }}>
        <Pressable onPress={choose} accessibilityRole="button" accessibilityLabel={`Choose ${label}`}>
          <Avatar uri={shownUri} name={name} size={size} />
        </Pressable>
        <View style={{ flex: 1, gap: spacing.sm }}>
          <Button label={shownUri ? 'Change photo' : 'Choose photo'} variant="outline" icon="image-outline" onPress={choose} />
          {onRemove && shownUri ? <Button label="Remove photo" variant="destructive-outline" onPress={onRemove} /> : null}
        </View>
      </View>
    </View>
  );
}
