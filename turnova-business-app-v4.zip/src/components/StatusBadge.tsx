import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useTheme } from '@/src/theme';

const LABELS: Record<string, string> = {
  upcoming: 'Upcoming', waiting: 'In queue', called: 'Called', completed: 'Completed',
  skipped: 'Skipped', cancelled: 'Cancelled', no_show: 'No-show',
  // plan / payment states
  trial: 'Free trial', active: 'Active', expired: 'Expired', none: 'No plan', paid: 'Paid',
  created: 'Awaiting payment', 'link expired': 'Link expired',
};

type Tone = 'info' | 'danger' | 'success' | 'neutral' | 'primary' | 'warning';
const TONES: Record<string, Tone> = {
  upcoming: 'info', waiting: 'info', called: 'primary', completed: 'success', skipped: 'neutral', cancelled: 'danger', no_show: 'danger',
  trial: 'primary', active: 'success', expired: 'danger', none: 'neutral', paid: 'success', created: 'primary', 'link expired': 'neutral',
};

/**
 * Pill status badge, same shape as the Customer app (24 dp, radius 12, dot + label).
 * "Called" is the one solid emerald badge so it stands out in lists.
 */
export function StatusBadge({ status, label }: { status: string; label?: string }) {
  const { colors, typography } = useTheme();
  const tone = TONES[status] ?? 'neutral';
  const { bg, fg } = {
    info: { bg: colors.infoBg, fg: colors.infoText },
    danger: { bg: colors.dangerBg, fg: colors.dangerText },
    success: { bg: colors.successBg, fg: colors.successText },
    warning: { bg: colors.warningBg, fg: colors.warningText },
    primary: status === 'called' ? { bg: colors.primary, fg: colors.primaryText } : { bg: colors.primaryContainer, fg: colors.primaryDark },
    neutral: { bg: colors.neutralBg, fg: colors.textSecondary },
  }[tone];

  return (
    <View style={[styles.pill, { backgroundColor: bg }]}>
      <View style={[styles.dot, { backgroundColor: fg }]} />
      <Text style={[typography.badge, { color: fg }]} numberOfLines={1}>
        {label ?? LABELS[status] ?? status.replace(/_/g, ' ')}
      </Text>
    </View>
  );
}

/** Colour used for a status stripe (Card accent). */
export function useStatusColor(status: string): string {
  const { colors } = useTheme();
  const tone = TONES[status] ?? 'neutral';
  return { info: colors.info, danger: colors.danger, success: colors.success, warning: colors.warning, primary: colors.primary, neutral: colors.textMuted }[tone];
}

const styles = StyleSheet.create({
  pill: { height: 24, borderRadius: 12, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start' },
  dot: { width: 6, height: 6, borderRadius: 3, marginRight: 6 },
});
