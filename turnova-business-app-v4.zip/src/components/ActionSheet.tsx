import React from 'react';
import { Pressable, Text, View } from 'react-native';
import { useTheme } from '@/src/theme';
import { BottomSheet } from './BottomSheet';
import { Button } from './Button';

export type SheetAction = { label: string; onPress: () => void; destructive?: boolean; disabled?: boolean };

type Props = {
  visible: boolean;
  title?: string;
  subtitle?: string;
  actions: SheetAction[];
  onClose: () => void;
};

/** Bottom sheet with a short list of actions for a tapped list row (Edit, Pause, Delete ...). */
export function ActionSheet({ visible, title, subtitle, actions, onClose }: Props) {
  const { colors, typography, spacing } = useTheme();
  return (
    <BottomSheet visible={visible} onClose={onClose}>
      <View style={{ padding: spacing.xl, gap: spacing.xs }}>
        {title ? <Text style={[typography.h2, { color: colors.textPrimary }]} numberOfLines={1}>{title}</Text> : null}
        {subtitle ? <Text style={[typography.caption, { color: colors.textSecondary }]} numberOfLines={2}>{subtitle}</Text> : null}
        <View style={{ marginTop: spacing.sm }}>
          {actions.map((a, i) => (
            <Pressable
              key={a.label}
              disabled={a.disabled}
              onPress={() => { onClose(); a.onPress(); }}
              accessibilityRole="button"
              style={({ pressed }) => ({ minHeight: 52, justifyContent: 'center', borderTopWidth: i === 0 ? 0 : 1, borderTopColor: colors.border, opacity: a.disabled ? 0.4 : pressed ? 0.7 : 1 })}
            >
              <Text style={[typography.bodyStrong, { color: a.destructive ? colors.dangerText : colors.textPrimary }]}>{a.label}</Text>
            </Pressable>
          ))}
        </View>
        <View style={{ marginTop: spacing.md }}><Button label="Close" variant="outline" onPress={onClose} /></View>
      </View>
    </BottomSheet>
  );
}
