import React from 'react';
import { Modal as RNModal, Pressable, StyleSheet, View } from 'react-native';
import { useTheme } from '@/src/theme';

type Props = {
  visible: boolean;
  onClose: () => void;
  children: React.ReactNode;
  /** 'sheet' anchors to the bottom (default); 'center' centers on screen. */
  variant?: 'sheet' | 'center';
};

/**
 * One reusable wrapper for both the bottom-sheet and centered-modal patterns
 * described in §0.7 ("Rate your experience", log-out confirmation, etc.) —
 * feature screens pass their own content as children.
 */
export function BottomSheet({ visible, onClose, children, variant = 'sheet' }: Props) {
  const { colors, radii } = useTheme();

  return (
    <RNModal visible={visible} transparent animationType="fade" onRequestClose={onClose} statusBarTranslucent>
      <Pressable style={[styles.backdrop, { backgroundColor: colors.scrim }]} onPress={onClose}>
        <View style={variant === 'sheet' ? styles.sheetWrap : styles.centerWrap}>
          {/* Stop taps on the content itself from closing the sheet. */}
          <Pressable onPress={(e) => e.stopPropagation()}>
            <View
              style={[
                styles.content,
                {
                  backgroundColor: colors.surface,
                  padding: variant === 'center' ? 24 : 0,
                  paddingBottom: variant === 'center' ? 16 : 0,
                  borderTopLeftRadius: variant === 'sheet' ? radii.sheet : radii.card,
                  borderTopRightRadius: variant === 'sheet' ? radii.sheet : radii.card,
                  borderBottomLeftRadius: variant === 'center' ? radii.card : 0,
                  borderBottomRightRadius: variant === 'center' ? radii.card : 0,
                },
                variant === 'center' && styles.centerContent,
              ]}
            >
              {variant === 'sheet' ? (
                <View style={{ alignItems: 'center', paddingTop: 10 }}>
                  <View style={{ width: 36, height: 4, borderRadius: 2, backgroundColor: colors.border }} />
                </View>
              ) : null}
              {children}
            </View>
          </Pressable>
        </View>
      </Pressable>
    </RNModal>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
  },
  sheetWrap: {
    marginTop: 'auto',
  },
  centerWrap: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  content: {
    width: '100%',
  },
  // Same centred dialog as the Customer app: 24 dp padding, 300 dp wide.
  centerContent: {
    width: 300,
    maxWidth: '100%',
  },
});
