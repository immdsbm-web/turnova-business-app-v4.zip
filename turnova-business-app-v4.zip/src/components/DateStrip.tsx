import React, { useEffect, useRef } from 'react';
import { Pressable, ScrollView, StyleSheet, Text } from 'react-native';
import { useTheme } from '@/src/theme';

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export function toYmd(d: Date): string {
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}

export function formatYmd(ymd: string): string {
  if (!ymd) return '';
  const [y, m, d] = ymd.split('-').map(Number);
  if (!y) return ymd;
  const date = new Date(y, m - 1, d);
  return `${WEEKDAYS[date.getDay()]}, ${d} ${MONTHS[m - 1]} ${y}`;
}

/** "12 Oct" */
export function formatShort(ymd: string): string {
  if (!ymd) return '';
  const [y, m, d] = ymd.split('-').map(Number);
  return y ? `${d} ${MONTHS[m - 1]}` : ymd;
}

type Props = { value: string; onChange: (ymd: string) => void; days?: number };

/** Horizontal strip of the next N days (today first). Avoids a native date-picker dependency. */
export function DateStrip({ value, onChange, days = 60 }: Props) {
  const { colors, typography, radii } = useTheme();
  const ref = useRef<ScrollView>(null);
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const items = Array.from({ length: days }, (_, i) => {
    const d = new Date(today);
    d.setDate(today.getDate() + i);
    return { ymd: toYmd(d), weekday: WEEKDAYS[d.getDay()], day: d.getDate(), month: MONTHS[d.getMonth()] };
  });

  useEffect(() => {
    const idx = items.findIndex((i) => i.ymd === value);
    if (idx > 2) ref.current?.scrollTo({ x: (idx - 2) * 64, animated: false });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <ScrollView ref={ref} horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingVertical: 4 }}>
      {items.map((i) => {
        const selected = i.ymd === value;
        return (
          <Pressable
            key={i.ymd}
            onPress={() => onChange(i.ymd)}
            accessibilityRole="button"
            accessibilityState={{ selected }}
            style={[styles.chip, {
              borderRadius: radii.input,
              backgroundColor: selected ? colors.primary : colors.surface,
              borderColor: selected ? colors.primary : colors.border,
            }]}
          >
            <Text style={[typography.caption, { color: selected ? colors.primaryText : colors.textSecondary }]}>{i.weekday}</Text>
            <Text style={[typography.titleSmall, { color: selected ? colors.primaryText : colors.textPrimary }]}>{i.day}</Text>
            <Text style={[typography.caption, { color: selected ? colors.primaryText : colors.textMuted }]}>{i.month}</Text>
          </Pressable>
        );
      })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  chip: { width: 56, alignItems: 'center', paddingVertical: 8, borderWidth: 1 },
});
