import React from 'react';
import { Alert, Pressable, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { BottomSheet } from '@/src/components/BottomSheet';
import { useTheme } from '@/src/theme';

export type PickedPhoto = { uri: string; mime?: string | null; name?: string | null };

/**
 * One photo flow for the whole app, identical to the Customer App's profile
 * photo: pick from the camera or gallery, then crop in the system editor.
 * `aspect` is the crop frame, e.g. [1, 1] for pictures or [19, 10] for banners.
 */
export async function pickPhoto(source: 'camera' | 'gallery', aspect: [number, number], quality = 0.8): Promise<PickedPhoto | null> {
  const perm = source === 'camera' ? await ImagePicker.requestCameraPermissionsAsync() : await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!perm.granted) {
    Alert.alert('Permission needed', source === 'camera' ? 'Allow camera access in your phone settings to take a photo.' : 'Allow photo access in your phone settings to choose a picture.');
    return null;
  }
  const options: ImagePicker.ImagePickerOptions = { mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, aspect, quality };
  const res = source === 'camera' ? await ImagePicker.launchCameraAsync(options) : await ImagePicker.launchImageLibraryAsync(options);
  if (res.canceled || !res.assets?.[0]) return null;
  const a = res.assets[0];
  const ext = (a.uri.split('.').pop() || 'jpg').toLowerCase();
  return { uri: a.uri, mime: a.mimeType ?? `image/${ext === 'jpg' ? 'jpeg' : ext}`, name: a.fileName ?? `photo.${ext}` };
}

function Row({ icon, label, destructive, onPress }: { icon: keyof typeof Ionicons.glyphMap; label: string; destructive?: boolean; onPress: () => void }) {
  const { colors, typography, spacing } = useTheme();
  return (
    <Pressable onPress={onPress} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: spacing.md, paddingHorizontal: spacing.lg }}>
      <Ionicons name={icon} size={20} color={destructive ? colors.danger : colors.textSecondary} />
      <Text style={[typography.body, { color: destructive ? colors.danger : colors.textPrimary, marginLeft: spacing.md }]}>{label}</Text>
    </Pressable>
  );
}

type Props = {
  visible: boolean;
  onClose: () => void;
  aspect: [number, number];
  onPicked: (p: PickedPhoto) => void;
  /** Show "Remove photo" when there is one to remove. */
  onRemove?: () => void;
};

/** Take photo / Choose from gallery / Remove photo, as in the Customer App. */
export function PhotoSheet({ visible, onClose, aspect, onPicked, onRemove }: Props) {
  const pick = async (source: 'camera' | 'gallery') => {
    onClose();
    // Let the sheet finish closing before the system picker opens.
    await new Promise((r) => setTimeout(r, 250));
    const p = await pickPhoto(source, aspect);
    if (p) onPicked(p);
  };
  return (
    <BottomSheet visible={visible} onClose={onClose}>
      <View style={{ paddingBottom: 12 }}>
        <Row icon="camera-outline" label="Take photo" onPress={() => pick('camera')} />
        <Row icon="image-outline" label="Choose from gallery" onPress={() => pick('gallery')} />
        {onRemove ? <Row icon="trash-outline" label="Remove photo" destructive onPress={() => { onClose(); onRemove(); }} /> : null}
      </View>
    </BottomSheet>
  );
}
