import React from 'react';
import { Pressable, StyleSheet, Text, View, ViewStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/src/theme';
import { Card } from './Card';

type IconName = keyof typeof Ionicons.glyphMap;
export type Tone = 'primary' | 'info' | 'success' | 'warning' | 'danger' | 'neutral';

export function useTone(tone: Tone) {
  const { colors } = useTheme();
  return {
    primary: { bg: colors.primaryContainer, fg: colors.primaryDark },
    info: { bg: colors.infoBg, fg: colors.infoText },
    success: { bg: colors.successBg, fg: colors.successText },
    warning: { bg: colors.warningBg, fg: colors.warningText },
    danger: { bg: colors.dangerBg, fg: colors.dangerText },
    neutral: { bg: colors.neutralBg, fg: colors.textSecondary },
  }[tone];
}

/** Heading above a group of cards, with an optional right-hand element (count, link). */
export function SectionTitle({ children, right }: { children: React.ReactNode; right?: React.ReactNode }) {
  const { colors, typography } = useTheme();
  return (
    <View style={styles.sectionRow}>
      <Text style={[typography.h2, { color: colors.textPrimary, flex: 1 }]}>{children}</Text>
      {right}
    </View>
  );
}

/** Small uppercase label for groups ("BUSINESS", "ACCOUNT"). */
export function Overline({ children }: { children: string }) {
  const { colors, typography } = useTheme();
  return <Text style={[typography.overline, { color: colors.textMuted, marginTop: 6 }]}>{children.toUpperCase()}</Text>;
}

/** Coloured square holding an icon. */
export function IconTile({ icon, tone = 'primary', size = 40 }: { icon: IconName; tone?: Tone; size?: number }) {
  const { bg, fg } = useTone(tone);
  return (
    <View style={{ width: size, height: size, borderRadius: size * 0.28, backgroundColor: bg, alignItems: 'center', justifyContent: 'center' }}>
      <Ionicons name={icon} size={size * 0.5} color={fg} />
    </View>
  );
}

/** Label + value pair used on billing / detail screens. */
export function InfoRow({ label, value, hint }: { label: string; value: string; hint?: string }) {
  const { colors, typography } = useTheme();
  return (
    <View style={{ flexBasis: '46%', flexGrow: 1, paddingVertical: 8 }}>
      <Text style={[typography.caption, { color: colors.textMuted }]}>{label}</Text>
      <Text style={[typography.bodyStrong, { color: colors.textPrimary, marginTop: 2 }]}>{value}</Text>
      {hint ? <Text style={[typography.caption, { color: colors.textSecondary, marginTop: 1 }]}>{hint}</Text> : null}
    </View>
  );
}

/** Dashboard number tile: coloured icon, big number, label. Two per row. */
export function StatTile({ label, value, icon, tone = 'primary' }: { label: string; value: string | number; icon: IconName; tone?: Tone }) {
  const { colors, typography } = useTheme();
  return (
    <Card style={{ flexBasis: '47%', flexGrow: 1, gap: 10 }}>
      <IconTile icon={icon} tone={tone} size={36} />
      <View>
        <Text style={[typography.metric, { color: colors.textPrimary }]}>{value}</Text>
        <Text style={[typography.caption, { color: colors.textSecondary, marginTop: 2 }]}>{label}</Text>
      </View>
    </Card>
  );
}

/** Settings-style grouped list: rows share one bordered card, separated by hairlines. */
export function NavGroup({ children }: { children: React.ReactNode }) {
  return <Card padded={false}>{children}</Card>;
}

export function NavRow({ icon, title, subtitle, onPress, badge, last, tone = 'primary', right }: {
  icon: IconName; title: string; subtitle?: string; onPress?: () => void; badge?: number; last?: boolean; tone?: Tone; right?: React.ReactNode;
}) {
  const { colors, typography } = useTheme();
  return (
    <Pressable
      onPress={onPress}
      disabled={!onPress}
      accessibilityRole="button"
      accessibilityLabel={title}
      style={({ pressed }) => [styles.navRow, { borderBottomWidth: last ? 0 : StyleSheet.hairlineWidth, borderBottomColor: colors.border, backgroundColor: pressed ? colors.surfaceAlt : 'transparent' }]}
    >
      <IconTile icon={icon} tone={tone} size={38} />
      <View style={{ flex: 1 }}>
        <Text style={[typography.titleSmall, { color: colors.textPrimary }]}>{title}</Text>
        {subtitle ? <Text style={[typography.caption, { color: colors.textSecondary, marginTop: 2 }]} numberOfLines={1}>{subtitle}</Text> : null}
      </View>
      {badge && badge > 0 ? (
        <View style={[styles.badge, { backgroundColor: colors.danger }]}><Text style={styles.badgeText}>{badge > 99 ? '99+' : badge}</Text></View>
      ) : null}
      {right ?? (onPress ? <Ionicons name="chevron-forward" size={18} color={colors.textMuted} /> : null)}
    </Pressable>
  );
}

/** Highlighted message with an icon and a coloured edge (warnings, plan notices, confirmations). */
export function Notice({ tone = 'info', children, style, icon }: { tone?: 'info' | 'danger' | 'success' | 'primary' | 'warning'; children: React.ReactNode; style?: ViewStyle; icon?: IconName }) {
  const { typography, spacing, radii } = useTheme();
  const { bg, fg } = useTone(tone);
  const defaultIcon: IconName = { info: 'information-circle', danger: 'alert-circle', success: 'checkmark-circle', primary: 'sparkles', warning: 'time' }[tone] as IconName;
  return (
    <View style={[{ backgroundColor: bg, borderRadius: radii.input, padding: spacing.md, flexDirection: 'row', gap: spacing.sm, alignItems: 'flex-start' }, style]}>
      <Ionicons name={icon ?? defaultIcon} size={18} color={fg} style={{ marginTop: 1 }} />
      <Text style={[typography.body, { color: fg, fontFamily: 'Inter_600SemiBold', flex: 1 }]}>{children}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  sectionRow: { flexDirection: 'row', alignItems: 'center', marginTop: 6 },
  navRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 14, paddingVertical: 12 },
  badge: { minWidth: 22, height: 22, borderRadius: 11, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6 },
  badgeText: { color: '#fff', fontSize: 11, fontFamily: 'Inter_700Bold' },
});
