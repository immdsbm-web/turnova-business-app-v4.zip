import React from 'react';
import { Ionicons } from '@expo/vector-icons';
import { StyleSheet, Text, View } from 'react-native';
import { useTheme } from '@/src/theme';
import { Button } from './Button';

type Props = { message?: string; onRetry?: () => void };

export function ErrorState({ message = 'Something went wrong.', onRetry }: Props) {
  const { colors, typography, spacing } = useTheme();
  return (
    <View style={[styles.container, { paddingVertical: spacing.xxxl, paddingHorizontal: spacing.xl }]}>
      <View style={[styles.tile, { backgroundColor: colors.dangerBg }]}>
        <Ionicons name="alert-circle-outline" size={30} color={colors.danger} />
      </View>
      <Text style={[typography.body, { color: colors.textPrimary, textAlign: 'center', marginVertical: spacing.lg }]}>{message}</Text>
      {onRetry ? <Button label="Try again" variant="outline" icon="refresh-outline" onPress={onRetry} style={{ maxWidth: 200 }} /> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { alignItems: 'center', justifyContent: 'center' },
  tile: { width: 64, height: 64, borderRadius: 32, alignItems: 'center', justifyContent: 'center' },
});
