import React, { useEffect, useRef } from 'react';
import { Animated, StyleSheet, View } from 'react-native';
import { useTheme } from '@/src/theme';

export function LoadingSpinner() {
  const { colors } = useTheme();
  return (
    <View style={styles.center}>
      <Animated.View>
        <SkeletonBlock width={32} height={32} borderRadius={16} color={colors.neutralBg} />
      </Animated.View>
    </View>
  );
}

function SkeletonBlock({
  width,
  height,
  borderRadius = 8,
  color,
  style,
}: {
  width: number | string;
  height: number;
  borderRadius?: number;
  color?: string;
  style?: object;
}) {
  const { colors } = useTheme();
  const opacity = useRef(new Animated.Value(0.4)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, { toValue: 1, duration: 600, useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 0.4, duration: 600, useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [opacity]);

  return (
    <Animated.View
      style={[
        { width, height, borderRadius, backgroundColor: color ?? colors.neutralBg, opacity },
        style,
      ]}
    />
  );
}

/** A generic shimmering card skeleton — good default for list-item placeholders. */
export function SkeletonCard() {
  const { colors, radii, spacing } = useTheme();
  return (
    <View
      style={[
        styles.card,
        { backgroundColor: colors.surface, borderColor: colors.border, borderRadius: radii.card, padding: spacing.lg },
      ]}
    >
      <View style={styles.row}>
        <SkeletonBlock width={48} height={48} borderRadius={24} />
        <View style={{ marginLeft: spacing.md, flex: 1 }}>
          <SkeletonBlock width="70%" height={16} style={{ marginBottom: spacing.xs }} />
          <SkeletonBlock width="40%" height={12} />
        </View>
      </View>
    </View>
  );
}

/** Renders `count` shimmering skeleton cards, for a list's first-load state. */
export function LoadingState({ count = 3 }: { count?: number }) {
  return (
    <View>
      {Array.from({ length: count }).map((_, i) => (
        <View key={i} style={{ marginBottom: 12 }}>
          <SkeletonCard />
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  center: { alignItems: 'center', justifyContent: 'center', padding: 24 },
  card: { borderWidth: 1 },
  row: { flexDirection: 'row', alignItems: 'center' },
});
