import React, { useState } from 'react';
import { Image, LayoutChangeEvent, Text, View, ViewStyle } from 'react-native';
import { useTheme } from '@/src/theme';

type Props = {
  uri: string | null;
  title?: string | null;
  subtitle?: string | null;
  zoom: number;
  x: number;
  y: number;
  /** width / height of the frame */
  ratio?: number;
  radius?: number;
  style?: ViewStyle;
};

/**
 * How the banner looks in the customer app: a cover image, scaled by `zoom`
 * around the focal point (x, y as percentages), with the title and subtitle
 * on a dark gradient at the bottom. The same maths is used in the customer app.
 */
export function BannerPreview({ uri, title, subtitle, zoom, x, y, ratio = 2.4, radius = 16, style }: Props) {
  const { colors, typography } = useTheme();
  const [size, setSize] = useState({ w: 0, h: 0 });
  const onLayout = (e: LayoutChangeEvent) => setSize({ w: e.nativeEvent.layout.width, h: e.nativeEvent.layout.height });

  const z = Math.min(3, Math.max(1, zoom));
  const maxX = (size.w * (z - 1)) / 2;
  const maxY = (size.h * (z - 1)) / 2;
  const tx = Math.max(-maxX, Math.min(maxX, (0.5 - x / 100) * size.w * z));
  const ty = Math.max(-maxY, Math.min(maxY, (0.5 - y / 100) * size.h * z));

  return (
    <View onLayout={onLayout} style={[{ width: '100%', aspectRatio: ratio, borderRadius: radius, overflow: 'hidden', backgroundColor: colors.neutralBg }, style]}>
      {uri ? (
        <Image source={{ uri }} resizeMode="cover" style={{ width: '100%', height: '100%', transform: [{ translateX: tx }, { translateY: ty }, { scale: z }] }} />
      ) : null}
      {title || subtitle ? (
        <View style={{ position: 'absolute', left: 0, right: 0, bottom: 0, paddingHorizontal: 14, paddingTop: 26, paddingBottom: 10, backgroundColor: 'rgba(0,0,0,0.42)' }}>
          {title ? <Text style={[typography.titleSmall, { color: '#fff' }]} numberOfLines={1}>{title}</Text> : null}
          {subtitle ? <Text style={[typography.caption, { color: 'rgba(255,255,255,0.9)' }]} numberOfLines={1}>{subtitle}</Text> : null}
        </View>
      ) : null}
    </View>
  );
}
