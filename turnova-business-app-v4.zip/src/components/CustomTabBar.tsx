import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { BottomTabBarProps } from '@react-navigation/bottom-tabs';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useTheme, TAB_BAR_HEIGHT } from '@/src/theme';
import { useSession } from '@/src/auth/session';

type Dest = { icon: keyof typeof Ionicons.glyphMap; iconFilled: keyof typeof Ionicons.glyphMap; label: string };

// Owner tabs: home / appointments / bookings / manage (billing is inside Manage).  Staff tabs: my-queue / my-qr / my-profile.
const DESTINATIONS: Record<string, Dest> = {
  home: { icon: 'grid-outline', iconFilled: 'grid', label: 'Home' },
  queue: { icon: 'time-outline', iconFilled: 'time', label: 'Appointments' },
  bookings: { icon: 'list-outline', iconFilled: 'list', label: 'Bookings' },
  manage: { icon: 'settings-outline', iconFilled: 'settings', label: 'Manage' },
  'my-queue': { icon: 'time-outline', iconFilled: 'time', label: 'Appointments' },
  'my-qr': { icon: 'qr-code-outline', iconFilled: 'qr-code', label: 'QR code' },
  'my-profile': { icon: 'person-circle-outline', iconFilled: 'person-circle', label: 'Profile' },
};

/**
 * Docked bottom bar, same as the Customer app: plain surface, hairline on top,
 * emerald icon and label for the active tab (no indicator). A red count shows on Appointments (still to be served) and Manage
 * (bookings that need reassignment).
 */
export function CustomTabBar({ state, descriptors, navigation }: BottomTabBarProps) {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const badges = useSession((s) => s.me?.badges);

  const countFor = (route: string): number => {
    if (route === 'queue' || route === 'my-queue') return badges?.waiting_queue ?? 0;
    if (route === 'manage') return badges?.flagged_for_reassignment ?? 0;
    return 0;
  };

  return (
    <View
      style={[
        styles.container,
        { height: TAB_BAR_HEIGHT + insets.bottom, paddingBottom: insets.bottom, backgroundColor: colors.surface, borderTopColor: colors.border },
      ]}
    >
      {state.routes.map((route, index) => {
        const { options } = descriptors[route.key];
        const destination = DESTINATIONS[route.name];
        if (!destination) return null;
        const focused = state.index === index;
        const onPress = () => {
          const event = navigation.emit({ type: 'tabPress', target: route.key, canPreventDefault: true });
          if (!focused && !event.defaultPrevented) navigation.navigate(route.name);
        };
        return (
          <NavItem
            key={route.key}
            focused={focused}
            icon={focused ? destination.iconFilled : destination.icon}
            label={(options.title ?? destination.label) as string}
            count={countFor(route.name)}
            onPress={onPress}
          />
        );
      })}
    </View>
  );
}

function NavItem({ focused, icon, label, count, onPress }: {
  focused: boolean; icon: keyof typeof Ionicons.glyphMap; label: string; count: number; onPress: () => void;
}) {
  const { colors, typography } = useTheme();
  const tint = focused ? colors.primary : colors.textSecondary;

  return (
    <Pressable onPress={onPress} style={styles.item} accessibilityRole="button" accessibilityLabel={label} accessibilityState={{ selected: focused }}>
      <View>
        <Ionicons name={icon} size={24} color={tint} />
        {count > 0 ? (
          <View style={[styles.badge, { backgroundColor: colors.danger, borderColor: colors.surface }]}>
            <Text style={styles.badgeText}>{count > 99 ? '99+' : count}</Text>
          </View>
        ) : null}
      </View>
      <Text style={[focused ? typography.tabActive : typography.tab, { color: tint, marginTop: 3 }]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: { position: 'absolute', left: 0, right: 0, bottom: 0, borderTopWidth: 1, flexDirection: 'row', alignItems: 'flex-start' },
  item: { flex: 1, height: TAB_BAR_HEIGHT, alignItems: 'center', justifyContent: 'center', paddingTop: 2 },
  badge: { position: 'absolute', top: -5, right: -10, minWidth: 17, height: 17, borderRadius: 9, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 3, borderWidth: 1.5 },
  badgeText: { color: '#fff', fontSize: 9, fontFamily: 'Inter_700Bold' },
});
