import React, { useEffect, useState } from 'react';
import { useSession } from '@/src/auth/session';
import { LoadingState } from './LoadingState';
import { OfflineScreen } from './OfflineScreen';

/**
 * Shown while a signed-in person's account details are still loading. Keeps
 * retrying in the background; if it takes more than a few seconds, says plainly
 * that the internet is slow instead of an endless spinner. Never signs out.
 */
export function ProfileLoading() {
  const refreshMe = useSession((s) => s.refreshMe);
  const [slow, setSlow] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setSlow(true), 8000);
    const r = setInterval(() => refreshMe().catch(() => undefined), 4000);
    return () => { clearTimeout(t); clearInterval(r); };
  }, [refreshMe]);

  if (slow) {
    return (
      <OfflineScreen
        title="Slow Internet Connection"
        subtitle="Your internet is slow or unstable. You are still signed in. Please wait or try again."
        onRetry={() => refreshMe().catch(() => undefined)}
      />
    );
  }
  return <LoadingState />;
}
