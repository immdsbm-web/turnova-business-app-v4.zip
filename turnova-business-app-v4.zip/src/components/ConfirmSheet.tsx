import React from 'react';
import { Text, View } from 'react-native';
import { useTheme } from '@/src/theme';
import { BottomSheet } from './BottomSheet';
import { Button } from './Button';

type Props = {
  visible: boolean;
  title: string;
  message?: string;
  confirmLabel: string;
  destructive?: boolean;
  loading?: boolean;
  onConfirm: () => void;
  onClose: () => void;
  children?: React.ReactNode;
};

/** "Are you sure?" bottom sheet. Optional children (e.g. a reason field) go between the text and the buttons. */
export function ConfirmSheet({ visible, title, message, confirmLabel, destructive, loading, onConfirm, onClose, children }: Props) {
  const { colors, typography, spacing } = useTheme();
  return (
    <BottomSheet visible={visible} onClose={onClose}>
      <View style={{ paddingHorizontal: spacing.xl, paddingTop: spacing.lg, paddingBottom: spacing.xl, gap: spacing.md }}>
        <Text style={[typography.h2, { color: colors.textPrimary }]}>{title}</Text>
        {message ? <Text style={[typography.body, { color: colors.textSecondary }]}>{message}</Text> : null}
        {children}
        <Button label={confirmLabel} variant={destructive ? 'destructive-outline' : 'primary'} loading={loading} onPress={onConfirm} />
        <Button label="Cancel" variant="ghost" onPress={onClose} disabled={loading} />
      </View>
    </BottomSheet>
  );
}
