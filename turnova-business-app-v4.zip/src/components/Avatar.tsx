import React, { useEffect, useState } from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';
import { useTheme } from '@/src/theme';
import { resolveImageUrl } from '@/src/utils/media';

type Props = {
  uri?: string | null;
  name?: string | null;
  size?: number;
  /** 'tile' (default): the squircle used for every profile picture; 'circle' only if ever needed. */
  shape?: 'circle' | 'tile';
};

// Single leading initial only — matches the Flutter reference app's
// AppAvatar placeholder exactly.
function getInitials(name?: string | null): string {
  if (!name || !name.trim()) return '?';
  return name.trim()[0].toUpperCase();
}

export function Avatar({ uri, name, size = 48, shape = 'tile' }: Props) {
  const { colors, typography } = useTheme();
  const [failed, setFailed] = useState(false);
  // Rounded-square ("squircle"): corner radius is ~32% of the tile size,
  // not a full circle.
  const dimensionStyle = { width: size, height: size, borderRadius: shape === 'circle' ? size * 0.5 : Math.round(size * 0.29) };
  const resolvedUri = resolveImageUrl(uri);

  // A previous load failure must not stick to a *new* image: without this,
  // once one URL failed the tile stayed on the initials fallback even after
  // the person's photo_url changed.
  useEffect(() => {
    setFailed(false);
  }, [resolvedUri]);

  if (resolvedUri && !failed) {
    return (
      <Image
        source={{ uri: resolvedUri }}
        style={[styles.image, dimensionStyle]}
        onError={() => setFailed(true)}
      />
    );
  }

  const letterSize = Math.max(12, size * 0.375);
  return (
    <View style={[styles.fallback, dimensionStyle, { backgroundColor: colors.primaryContainer }]}>
      <Text
        style={[
          typography.titleSmall,
          {
            color: colors.primaryDark,
            fontSize: letterSize,
            // titleSmall's fixed 20px line height is sized for 15px text;
            // once the letter scales up with the tile it clipped the glyph.
            // Scale the line box with the letter so all of it is visible.
            lineHeight: Math.round(letterSize * 1.4),
            textAlign: 'center',
            textAlignVertical: 'center',
            includeFontPadding: false,
          },
        ]}
      >
        {getInitials(name)}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  image: {
    resizeMode: 'cover',
  },
  fallback: {
    alignItems: 'center',
    justifyContent: 'center',
  },
});
