import React from 'react';
import { Ionicons } from '@expo/vector-icons';
import { StyleSheet, Text, View } from 'react-native';
import { useTheme } from '@/src/theme';
import { Button } from './Button';

type Props = {
  icon?: keyof typeof Ionicons.glyphMap;
  title: string;
  subtitle?: string;
  ctaLabel?: string;
  onPressCta?: () => void;
};

export function EmptyState({ icon = 'file-tray-outline', title, subtitle, ctaLabel, onPressCta }: Props) {
  const { colors, typography, spacing } = useTheme();
  return (
    <View style={[styles.container, { paddingVertical: spacing.xxxl, paddingHorizontal: spacing.xl }]}>
      <View style={[styles.tile, { backgroundColor: colors.primaryContainer }]}>
        <Ionicons name={icon} size={30} color={colors.primaryDark} />
      </View>
      <Text style={[typography.h2, { color: colors.textPrimary, textAlign: 'center', marginTop: spacing.lg }]}>{title}</Text>
      {subtitle ? (
        <Text style={[typography.body, { color: colors.textSecondary, textAlign: 'center', marginTop: spacing.xs, marginBottom: ctaLabel ? spacing.xl : 0 }]}>{subtitle}</Text>
      ) : null}
      {ctaLabel && onPressCta ? <Button label={ctaLabel} onPress={onPressCta} style={{ maxWidth: 240 }} /> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { alignItems: 'center', justifyContent: 'center' },
  tile: { width: 64, height: 64, borderRadius: 32, alignItems: 'center', justifyContent: 'center' },
});
