import React from 'react';
import { Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/src/theme';

type Props = { onPress?: () => void; /** Icon colour override (e.g. white on a hero band). */ color?: string };

/** Plain 44 dp back arrow, same as the Customer app. Defaults to router.back(). */
export function BackButton({ onPress, color }: Props) {
  const router = useRouter();
  const { colors } = useTheme();

  return (
    <Pressable
      onPress={onPress ?? (() => router.back())}
      hitSlop={4}
      accessibilityRole="button"
      accessibilityLabel="Go back"
      style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center' }}
    >
      <Ionicons name="arrow-back" size={24} color={color ?? colors.textPrimary} />
    </Pressable>
  );
}
