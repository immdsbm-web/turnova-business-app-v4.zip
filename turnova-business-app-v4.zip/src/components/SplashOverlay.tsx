import React, { useEffect, useRef } from 'react';
import { Animated, Dimensions, Image, StyleSheet, View } from 'react-native';
import { useTheme } from '@/src/theme';

type Props = {
  /** Called once this view has actually laid out/painted a frame. */
  onReady?: () => void;
};

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const LOGO_WIDTH = Math.min(SCREEN_WIDTH * 0.62, 320);
// Source asset is 3264x600.
const LOGO_ASPECT_RATIO = 1632 / 400;

function Dot({ color, delay }: { color: string; delay: number }) {
  const opacity = useRef(new Animated.Value(0.3)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.delay(delay),
        Animated.timing(opacity, { toValue: 1, duration: 450, useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 0.3, duration: 450, useNativeDriver: true }),
        Animated.delay(300),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [opacity, delay]);

  return <Animated.View style={[styles.dot, { backgroundColor: color, opacity }]} />;
}

/**
 * Renders immediately in place of the plain native splash (a solid color
 * fill only — native splash screens can't be animated) so there's real
 * branded content on screen for however long session bootstrap + font
 * loading takes, rather than a blank rectangle (§12). Doesn't depend on
 * the branded Inter fonts finishing load — it's logo image + a
 * couple of animated dots, no text — so it can render the very first
 * frame after the JS bundle starts, before anything else is ready.
 */
export function SplashOverlay({ onReady }: Props) {
  const { colors } = useTheme();

  return (
    <View
      style={[styles.container, { backgroundColor: colors.background }]}
      onLayout={() => onReady?.()}
    >
      <Image
        source={require('@/src/assets/logo-wordmark.png')} /* same logo in light and dark mode */
        style={{ width: LOGO_WIDTH, height: LOGO_WIDTH / LOGO_ASPECT_RATIO }}
        resizeMode="contain"
      />
      <View style={styles.dotsRow}>
        <Dot color={colors.primary} delay={0} />
        <Dot color={colors.primary} delay={150} />
        <Dot color={colors.primary} delay={300} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  dotsRow: {
    flexDirection: 'row',
    marginTop: 28,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginHorizontal: 5,
  },
});
