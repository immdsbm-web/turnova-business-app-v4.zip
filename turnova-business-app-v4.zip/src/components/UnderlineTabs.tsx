import React from 'react';
import { Pressable, Text, View } from 'react-native';
import { useTheme } from '@/src/theme';

/** Plain text tabs with a 2 dp emerald underline on the active one and an optional count. */
export function UnderlineTabs<T extends string>({ value, onChange, items }: { value: T | null; onChange: (v: T) => void; items: Array<{ value: T; label: string; count?: number }> }) {
  const { colors, typography } = useTheme();
  return (
    <View style={{ flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: colors.border }}>
      {items.map((it) => {
        const on = it.value === value;
        return (
          <Pressable
            key={it.value}
            onPress={() => onChange(it.value)}
            accessibilityRole="tab"
            accessibilityState={{ selected: on }}
            style={{ flex: 1, minHeight: 44, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 6, borderBottomWidth: 2, borderBottomColor: on ? colors.primary : 'transparent', marginBottom: -1 }}
          >
            <Text style={[on ? typography.tabActive : typography.tab, { color: on ? colors.primary : colors.textSecondary }]}>{it.label}</Text>
            {it.count != null ? <Text style={[typography.caption, { color: on ? colors.primary : colors.textMuted }]}>{it.count}</Text> : null}
          </Pressable>
        );
      })}
    </View>
  );
}
