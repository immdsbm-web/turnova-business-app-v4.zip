import React from 'react';
import { StyleSheet, View, ViewProps } from 'react-native';
import { useTheme } from '@/src/theme';

type Props = ViewProps & {
  padded?: boolean;
  /** Draw a coloured stripe down the left edge (status at a glance). */
  accent?: string;
};

/** Flat bordered surface, same as the Customer app: hairline border, no shadow. */
export function Card({ style, padded = true, accent, children, ...rest }: Props) {
  const { colors, radii, spacing } = useTheme();
  return (
    <View
      {...rest}
      style={[
        styles.base,
        {
          backgroundColor: colors.surface,
          borderColor: colors.border,
          borderRadius: radii.card,
          padding: padded ? spacing.lg : 0,
          overflow: 'hidden',
        },
        style,
      ]}
    >
      {accent ? <View style={[styles.accent, { backgroundColor: accent }]} /> : null}
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  base: {
    borderWidth: 1,
  },
  accent: { position: 'absolute', left: 0, top: 0, bottom: 0, width: 4 },
});
