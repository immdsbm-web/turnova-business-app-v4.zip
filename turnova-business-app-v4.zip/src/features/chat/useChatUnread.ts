import { useQuery } from '@tanstack/react-query';
import { useIsFocused } from '@react-navigation/native';
import { fetchChatUnread } from '@/src/api/business';

/** Unread messages for THIS person (owner / staff each have their own count). */
export function useChatUnread() {
  const focused = useIsFocused();
  return useQuery({
    queryKey: ['chat-unread'],
    queryFn: fetchChatUnread,
    refetchInterval: focused ? 15000 : false,
    staleTime: 5000,
  });
}
