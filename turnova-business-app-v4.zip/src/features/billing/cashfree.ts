import { PayOrder } from '@/src/api/types';

export type UpiResult = { outcome: 'returned' | 'error'; message?: string };

/**
 * Opens the phone's UPI apps (GPay, PhonePe, Paytm ...) through Cashfree's native
 * SDK and resolves when the person comes back to the app.
 *
 * The result of the SDK is NOT trusted for anything important: whatever the
 * outcome, the caller asks the server (which asks Cashfree) whether the order is
 * really paid before activating the plan.
 *
 * The SDK is native code, so it only exists in a development / release build --
 * not in Expo Go. It is loaded lazily so the rest of the app still runs there.
 */
export function payWithUpi(order: PayOrder): Promise<UpiResult> {
  return new Promise((resolve) => {
    let sdk: any;
    let contract: any;
    try {
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      sdk = require('react-native-cashfree-pg-sdk');
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      contract = require('cashfree-pg-api-contract');
    } catch {
      resolve({ outcome: 'error', message: 'UPI payment needs the installed Turnova Business app (it does not work inside Expo Go).' });
      return;
    }

    const { CFPaymentGatewayService } = sdk;
    const { CFEnvironment, CFSession, CFUPIIntentCheckoutPayment, CFThemeBuilder } = contract;

    try {
      CFPaymentGatewayService.setCallback({
        onVerify(_orderId: string) {
          CFPaymentGatewayService.removeCallback();
          resolve({ outcome: 'returned' });
        },
        onError(error: any, _orderId: string) {
          CFPaymentGatewayService.removeCallback();
          const message = typeof error?.getMessage === 'function' ? error.getMessage() : error?.message;
          resolve({ outcome: 'error', message: message || 'The payment was not completed.' });
        },
      });

      const environment = order.environment === 'PRODUCTION' ? CFEnvironment.PRODUCTION : CFEnvironment.SANDBOX;
      const session = new CFSession(order.payment_session_id, order.order_id, environment);
      const theme = new CFThemeBuilder()
        .setNavigationBarBackgroundColor('#075E4B')
        .setNavigationBarTextColor('#FFFFFF')
        .setButtonBackgroundColor('#075E4B')
        .setButtonTextColor('#FFFFFF')
        .setPrimaryTextColor('#14252B')
        .setSecondaryTextColor('#718096')
        .build();

      // UPI intent: goes straight to the UPI app list, no card/netbanking screens.
      const payment = new CFUPIIntentCheckoutPayment(session, theme);
      CFPaymentGatewayService.doUPIPayment(payment);
    } catch (e: any) {
      try { CFPaymentGatewayService.removeCallback(); } catch { /* ignore */ }
      resolve({ outcome: 'error', message: e?.message || 'Could not start the UPI payment.' });
    }
  });
}
