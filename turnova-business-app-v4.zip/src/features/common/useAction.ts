import { useCallback, useState } from 'react';
import { useToast } from '@/src/components/Toast';
import { ApiError } from '@/src/api/types';

/**
 * Runs an API action with a busy flag and a toast for the result.
 * `run(fn, successMessage?)` resolves to true when it worked.
 */
export function useAction() {
  const toast = useToast();
  const [busy, setBusy] = useState(false);

  const run = useCallback(
    async (fn: () => Promise<{ message?: string } | void>, successMessage?: string): Promise<boolean> => {
      setBusy(true);
      try {
        const res = await fn();
        const msg = successMessage ?? (res && typeof res === 'object' ? res.message : undefined);
        if (msg) toast.show(msg, 'success');
        return true;
      } catch (e) {
        toast.show(e instanceof ApiError ? e.message : 'Something went wrong. Please try again.', 'error');
        return false;
      } finally {
        setBusy(false);
      }
    },
    [toast]
  );

  return { busy, run };
}
