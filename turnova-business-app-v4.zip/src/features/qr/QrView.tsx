import React, { useState } from 'react';
import { Text, View } from 'react-native';
import { useQuery } from '@tanstack/react-query';
import QRCode from 'react-native-qrcode-svg';
import { Card } from '@/src/components/Card';
import { ChipRow } from '@/src/components/ChipRow';
import { EmptyState } from '@/src/components/EmptyState';
import { ErrorState } from '@/src/components/ErrorState';
import { LoadingState } from '@/src/components/LoadingState';
import { Screen } from '@/src/components/Screen';
import { useTheme } from '@/src/theme';
import { fetchQr } from '@/src/api/business';
import { useSession } from '@/src/auth/session';

/**
 * A staff member's verification QR. The customer app scans it to prove the
 * customer is really at the counter when they are called. Staff see their
 * own; the owner can switch between staff.
 */
export function QrView({ tabs, back }: { tabs?: boolean; back?: boolean }) {
  const { colors, typography, spacing } = useTheme();
  const isOwner = useSession((s) => s.me?.account.role === 'owner');
  const [staffId, setStaffId] = useState<number | null>(null);

  const query = useQuery({ queryKey: ['qr', staffId], queryFn: () => fetchQr(staffId) });
  const d = query.data;
  const active = d?.active_staff_id ?? staffId;

  return (
    <Screen title="Verification QR" subtitle="Customers scan this to check in." tabs={tabs} back={back} refreshing={query.isRefetching} onRefresh={() => query.refetch()}>
      {query.isLoading ? <LoadingState /> : null}
      {query.isError && !d ? <ErrorState message="Couldn't load the QR code." onRetry={() => query.refetch()} /> : null}

      {isOwner && d && d.staff_list.length > 1 ? (
        <ChipRow items={d.staff_list.map((s) => ({ value: s.id, label: s.name }))} selected={active ?? 0} onSelect={setStaffId} />
      ) : null}

      {d && !d.staff_member ? <EmptyState icon="qr-code-outline" title="No staff member yet" subtitle="Add a staff member to get a verification QR." /> : null}

      {d?.staff_member ? (
        <Card style={{ alignItems: 'center', gap: spacing.md, paddingVertical: spacing.xxl }}>
          <Text style={[typography.h2, { color: colors.textPrimary }]}>{d.staff_member.name}</Text>
          <Text style={[typography.caption, { color: colors.textSecondary }]}>{d.business.name}</Text>
          <View style={{ backgroundColor: '#FFFFFF', padding: 16, borderRadius: 16 }}>
            <QRCode value={d.staff_member.qr_token} size={220} />
          </View>
          <Text style={[typography.caption, { color: colors.textSecondary, textAlign: 'center' }]}>
            Show it on screen or print it.
          </Text>
        </Card>
      ) : null}
    </Screen>
  );
}
