import { MessagesButton } from '@/src/components/MessagesButton';
import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useIsFocused } from '@react-navigation/native';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/src/components/Button';
import { ListRow } from '@/src/components/ListRow';
import { UnderlineTabs } from '@/src/components/UnderlineTabs';
import { ChipRow } from '@/src/components/ChipRow';
import { EmptyState } from '@/src/components/EmptyState';
import { ErrorState } from '@/src/components/ErrorState';
import { LoadingState } from '@/src/components/LoadingState';
import { Screen } from '@/src/components/Screen';
import { Notice } from '@/src/components/Ui';
import { useTheme, TAB_BAR_HEIGHT } from '@/src/theme';
import { callNext, fetchQueue, queueAction } from '@/src/api/business';
import { Appointment } from '@/src/api/types';
import { useSession } from '@/src/auth/session';
import { useAction } from '@/src/features/common/useAction';

const POLL_MS = 3000;

function formatTime(t: string | null): string {
  if (!t) return '';
  const [h, m] = t.split(':').map(Number);
  if (Number.isNaN(h)) return t;
  const hour12 = h % 12 === 0 ? 12 : h % 12;
  return `${hour12}:${String(m ?? 0).padStart(2, '0')} ${h >= 12 ? 'PM' : 'AM'}`;
}

function formatRange(start: string | null, end: string | null): string {
  if (!start) return 'No time';
  return end ? `${formatTime(start)} – ${formatTime(end)}` : formatTime(start);
}

const OPEN = ['upcoming', 'waiting', 'called'];

/**
 * Today's appointments for one staff member, in time order. Owners can switch
 * staff; staff always see their own. Refreshes every 3 seconds while open.
 *
 *   Call Next Customer -> marks the next upcoming appointment "Called" and sends that
 *                         customer "It's your turn."
 *   Complete / No-show -> only on a Called appointment (call first); no notification for Complete.
 */
export function QueueView({ tabs }: { tabs?: boolean }) {
  const { colors, typography, spacing } = useTheme();
  const role = useSession((s) => s.me?.account.role);
  const isOwner = role === 'owner';
  const focused = useIsFocused();
  const qc = useQueryClient();
  const { busy, run } = useAction();

  const [staffId, setStaffId] = useState<number | null>(null);

  const query = useQuery({
    queryKey: ['queue', staffId],
    queryFn: () => fetchQueue(staffId),
    refetchInterval: focused ? POLL_MS : false,
    enabled: focused,
  });

  const data = query.data;
  useEffect(() => {
    // Adopt the staff member the server picked (first alphabetically) so the chips show the right one.
    if (isOwner && staffId === null && data?.active_staff_id) setStaffId(data.active_staff_id);
  }, [isOwner, staffId, data?.active_staff_id]);

  const refresh = async () => {
    await qc.invalidateQueries({ queryKey: ['queue'] });
    useSession.getState().refreshMe().catch(() => undefined); // updates the tab badge
  };
  const activeStaff = data?.active_staff_id ?? staffId;

  const doAction = (action: 'complete' | 'no-show', id: number) =>
    run(() => queueAction(action, id, isOwner ? activeStaff : null)).then(refresh);

  const appointments = data?.appointments ?? [];
  const called = appointments.filter((a) => a.status === 'called');
  const upcoming = appointments.filter((a) => a.status === 'upcoming' || a.status === 'waiting');
  const finished = appointments.filter((a) => !OPEN.includes(a.status));
  const [tab, setTab] = useState<'wait' | 'now' | 'done'>('wait');
  const insets = useSafeAreaInsets();

  const today = new Date();
  const todayLabel = today.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'short' });
  const nextUp = upcoming[0];
  const canCall = !!activeStaff && !!nextUp && called.length === 0;
  const tabs3: Array<{ key: 'wait' | 'now' | 'done'; label: string; n: number }> = [
    { key: 'wait', label: 'Waiting', n: upcoming.length },
    { key: 'now', label: 'Now', n: called.length },
    { key: 'done', label: 'Done', n: finished.length },
  ];

  return (
    <View style={{ flex: 1 }}>
    <Screen title={isOwner ? 'Appointments' : 'My appointments'} subtitle={`Today · ${todayLabel}`} right={<MessagesButton />} tabs refreshing={query.isRefetching} onRefresh={() => query.refetch()} contentStyle={{ paddingBottom: (tabs ? TAB_BAR_HEIGHT : 0) + insets.bottom + 96 }}>
      {isOwner && data && data.staff_list.length > 1 ? (
        <ChipRow
          items={data.staff_list.map((s) => ({ value: s.id, label: s.name }))}
          selected={activeStaff ?? 0}
          onSelect={(id) => setStaffId(id)}
        />
      ) : null}

      {query.isLoading ? <LoadingState /> : null}
      {query.isError && !data ? <ErrorState message="Couldn't load the appointments." onRetry={() => query.refetch()} /> : null}

      {data ? (
        <>
          <UnderlineTabs value={tab} onChange={setTab} items={tabs3.map((t) => ({ value: t.key, label: t.label, count: t.n }))} />

          {!activeStaff ? <Notice tone="primary">{isOwner ? 'Add a staff member to see appointments.' : 'No schedule found for your account.'}</Notice> : null}

          {tab === 'wait' ? (
            upcoming.length === 0 ? (
              <EmptyState icon="calendar-outline" title="Nothing waiting" subtitle="Today's bookings appear here." />
            ) : (
              <View>
                {upcoming.map((a, i) => <OpenRow key={a.booking_id} a={a} busy={busy} last={i === upcoming.length - 1} onAction={doAction} />)}
              </View>
            )
          ) : null}

          {tab === 'now' ? (
            called.length === 0 ? (
              <EmptyState icon="play-outline" title="No one is being served" subtitle="Tap Call next below." />
            ) : (
              <View>
                {called.map((a, i) => <OpenRow canAct key={a.booking_id} a={a} busy={busy} last={i === called.length - 1} onAction={doAction} />)}
              </View>
            )
          ) : null}

          {tab === 'done' ? (
            finished.length === 0 ? (
              <EmptyState icon="checkmark-done-outline" title="Nothing finished yet" subtitle="Finished appointments appear here." />
            ) : (
              <View>
                {finished.map((a, i) => (
                  <ListRow
                    key={a.booking_id}
                    uri={a.customer_photo_url}
                    name={a.customer_name}
                    title={a.customer_name}
                    status={a.status}
                    lines={[formatRange(a.booking_time, a.end_time), a.service_names]}
                    last={i === finished.length - 1}
                  />
                ))}
              </View>
            )
          ) : null}
        </>
      ) : null}

    </Screen>

    {/* Pinned "Call next" bar */}
    {data && activeStaff ? (
      <View style={{ position: 'absolute', left: 0, right: 0, bottom: (tabs ? TAB_BAR_HEIGHT : 0) + insets.bottom, paddingHorizontal: spacing.lg, paddingTop: spacing.md, paddingBottom: spacing.md, backgroundColor: colors.surface, borderTopWidth: 1, borderTopColor: colors.border }}>
        <Button
          label={nextUp ? `Call next · ${nextUp.customer_name.split(' ')[0]}, ${formatTime(nextUp.booking_time)}` : 'Call next'}
          icon="megaphone-outline"
          loading={busy}
          disabled={!canCall && !busy}
          onPress={() => run(() => callNext(isOwner ? activeStaff : null)).then(refresh)}
        />
      </View>
    ) : null}
    </View>
  );
}

/** An open appointment (waiting or called): inline Complete and No-show, same actions as before; the row itself does not open anything. */
function OpenRow({ a, busy, last, onAction, canAct }: {
  a: Appointment; busy: boolean; last: boolean; canAct?: boolean;
  onAction: (act: 'complete' | 'no-show', id: number) => void;
}) {
  const { spacing } = useTheme();
  return (
    <ListRow
      uri={a.customer_photo_url}
      name={a.customer_name}
      title={a.customer_name}
      status={a.status}
      lines={[formatRange(a.booking_time, a.end_time), a.service_names, a.customer_verified_at ? 'Arrived (QR scanned)' : null]}
      last={last}
      footer={
        !canAct ? undefined : <View style={{ flexDirection: 'row', gap: spacing.sm, marginTop: spacing.sm }}>
          <Button label="Complete" size="sm" style={{ flex: 1 }} disabled={busy} onPress={() => onAction('complete', a.booking_id)} />
          <Button label="No-show" size="sm" variant="destructive-outline" style={{ flex: 1 }} disabled={busy} onPress={() => onAction('no-show', a.booking_id)} />
        </View>
      }
    />
  );
}
