import type { ExpoConfig } from 'expo/config';

/**
 * Turnova Business -- the app for business owners and their staff.
 *
 * Talks to the same backend as the website's Business Panel:
 *   <origin>/api/v1/business/...
 * Change `API_ORIGIN` below (or set EXPO_PUBLIC_API_ORIGIN in eas.json /
 * your shell) when the server address changes.
 */
const API_ORIGIN = process.env.EXPO_PUBLIC_API_ORIGIN ?? 'https://eaglecode.a1h.in';

const config: ExpoConfig = {
  name: 'Turnova Business',
  slug: 'turnova-business',
  owner: 'smartqueue01', // DUMMY: replace with your expo.dev account username
  scheme: 'turnovabusiness',
  version: '1.0.0',
  orientation: 'portrait',
  icon: './src/assets/icon.png',
  userInterfaceStyle: 'automatic',
  // Cashfree's native payment SDK has not been tested on React Native's New Architecture,
  // and this app does not need it, so it stays off to be safe.
  newArchEnabled: false,
  assetBundlePatterns: ['**/*'],
  ios: {
    supportsTablet: false,
    bundleIdentifier: 'com.turnova.business',
    infoPlist: {
      NSLocationWhenInUseUsageDescription:
        'Turnova Business uses your location to set where your business is, so customers can find you nearby.',
      NSPhotoLibraryUsageDescription:
        'Turnova Business needs access to your photos so you can set a business logo or staff photo.',
      // Lets the payment screen detect and open UPI apps (GPay, PhonePe, Paytm ...).
      LSApplicationQueriesSchemes: [
        'upi', 'gpay', 'tez', 'phonepe', 'paytmmp', 'paytm', 'credpay', 'bhim', 'amazonpay', 'mobikwik', 'whatsapp',
      ],
    },
  },
  android: {
    package: 'com.turnova.business',
    permissions: ['ACCESS_COARSE_LOCATION', 'ACCESS_FINE_LOCATION'],
    adaptiveIcon: {
      foregroundImage: './src/assets/adaptive-icon.png',
      monochromeImage: './src/assets/adaptive-icon-monochrome.png',
      backgroundColor: '#FFFFFF',
    },
  },
  plugins: [
    'expo-router',
    'expo-secure-store',
    // Android 11+ must declare which apps it may talk to: this lets the UPI
    // payment screen see and open the phone's UPI apps.
    './plugins/withUpiQueries',
    [
      'expo-splash-screen',
      {
        // Same colour as the in-app splash (colors.background) and a matching
        // solid square, so there is no green flash or white box before the
        // wordmark splash. #101A1A is darkColors.background.
        image: './src/assets/splash.png',
        resizeMode: 'cover',
        backgroundColor: '#F8FAF9',
        dark: {
          image: './src/assets/splash-dark.png',
          resizeMode: 'cover',
          backgroundColor: '#101A1A',
        },
      },
    ],
    [
      'expo-location',
      {
        locationWhenInUsePermission:
          'Turnova Business uses your location to set where your business is, so customers can find you nearby.',
      },
    ],
    [
      'expo-image-picker',
      {
        photosPermission:
          'Turnova Business needs access to your photos so you can set a business logo, staff photos, gallery photos or a banner.',
        cameraPermission:
          'Turnova Business needs the camera so you can take a photo for your business logo, staff photo, gallery or banner.',
      },
    ],
  ],
  extra: {
    apiBaseUrl: `${API_ORIGIN}/api/v1/business`,
    eas: {
      projectId: 'be4ec435-4130-4cbb-aa5e-1ba2985b5870', // DUMMY: replace with your expo.dev project ID
    },
  },
};

export default config;
